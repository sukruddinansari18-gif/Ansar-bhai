# Firebase Security Specification & Audit Rules

This document outlines the security architecture, strict data invariants, and the test payload scenarios to defend the Coal-Belt Logistics B2B platform.

## 1. Core Data Invariants

- **Read Isolation**: PII and corporate credentials (such as GST registers, driving licenses, and facial Match percentage logs) are strictly isolated. Only the business owner (matching their phone number or user ID) or heavy safety administrator accounts can fetch these documents. No blanket reading is allowed.
- **Identity Integrity**: All writes (`bookings`, `fuelLogs`, `drivers`, `businesses`) must ensure the `ownerId` or `phone` references matching the authenticated user. Setting another operator's identity is strictly forbidden.
- **Status Progression Locking**: Operations that are completed or terminal (such as a booking status of `completed` or `cancelled`, or a driver verification set to `Verified`/`Rejected`/`Suspended`) cannot be updated or altered by standard clients once finalized.
- **Strict Size Enforcements**: String size, array length, and numeric tonnage fields have strict boundaries to prevent Denial of Wallet resource attacks.

---

## 2. The "Dirty Dozen" Threat Payloads

The following payloads represent malicious state manipulation vectors. The security rules are configured to reject them.

1. **Identity Hijacking**: Authenticated user `UID-8822` attempting to create a booking under `customerPhone: "9000000000"` when their authenticated phone number/profile doesn't match.
2. **Privilege Escalation**: A driver or customer updating their own database profiles to set `"status": "Verified"` or `"docsApproved": true` bypassing manual admin vetting.
3. **Ghost Field Injection**: Submitting a booking or business registration with a hidden `"ghost_administrative_override_flag": true` to gain admin status (blocked via strict `hasOnly` schema matching).
4. **Terminal State Mutation**: Attempting to set an already `completed` or `cancelled` booking back to a status of `accepted` to restart or modify billing metrics.
5. **GPS Geofence Spoofing**: Attempting to write a security log with suspicious coordinates (`Lat: 0.0, Lng: 0.0` or empty values) with a severity under-reported as `"low"` to hide spoofing.
6. **Denial of Wallet Payload**: Attempting to upload highly bloated text fields (such as a 10MB file-name string or an array containing 10,000 sub-elements in the booking notes) to cause massive database index sizes.
7. **Orphaned Writes**: Attempting to create a booking referencing a non-existent corporate trader or vehicle ID (blocked via synchronous validation).
8. **Monsoon Surge Poisoning**: A customer writing a direct configuration patch to reduce `surgeMultiplier` to `0.5x` during monsoon hours to save fees.
9. **Fake Out-of-Bound Fueling**: Logging a fuel log with a negative volume of liters (`-100L`) or massive price per liter (`₹9,999/L`) to inflate company expense audits.
10. **Aadhaar Spoof Verification**: Submitting custom `faceMatchPercent: 100` on a driver verification form without undergoing OCR analysis.
11. **Client Listing Query Scraping**: Attempting a collection-wide download of all heavy fuel logs or secret security session histories without specific ownership queries.
12. **Monsoon Override Bypass**: Modifying global config with an unverified email address or non-admin user status.

---

## 3. Test Runner Design Specifications

All rules will be evaluated and verified using the `firestore.rules` compiler and ESLint plugin for Firebase security rules. Any failure to validate types, sizes, or identity matches results in instant permissions failure.

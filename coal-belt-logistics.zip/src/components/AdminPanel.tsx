import React, { useState, useEffect } from 'react';
import { 
  Building, ShieldAlert, Users, Truck, IndianRupee, Settings, 
  Map, Bell, TrendingUp, Check, X, AlertTriangle, Play, Flame, Filter,
  LogOut, Shield, Eye, RefreshCw, UserCheck, Activity, Fingerprint, FileText, Camera, CheckCircle2
} from 'lucide-react';
import { AppState, Booking, Driver } from '../types';
import { VEHICLE_SPECS, INDUSTRIAL_HUBS } from '../data';

interface AdminPanelProps {
  state: AppState;
  onUpdateConfig: (configPayload: any) => Promise<void>;
  onApproveDriver: (driverId: string, approve: boolean) => Promise<void>;
  language: 'en' | 'hi';
  currentUser?: any;
  onLogout?: () => void;
}

export default function AdminPanel({
  state,
  onUpdateConfig,
  onApproveDriver,
  language,
  currentUser,
  onLogout
}: AdminPanelProps) {

  const [activeTab, setActiveTab] = useState<'dashboard' | 'drivers' | 'bookings' | 'settings' | 'securities'>('dashboard');
  const [filterCounty, setFilterCounty] = useState<string>('All');

  // B2B Securities & KYC administration database state
  const [businessesDb, setBusinessesDb] = useState<any[]>([]);
  const [driversDb, setDriversDb] = useState<any[]>([]);
  const [securityLogs, setSecurityLogs] = useState<any[]>([]);
  const [loadingSec, setLoadingSec] = useState<boolean>(true);
  const [selectedKycDoc, setSelectedKycDoc] = useState<any | null>(null);

  const fetchSecurityRecords = async () => {
    try {
      const res = await fetch('/api/security/records');
      if (res.ok) {
        const data = await res.json();
        setBusinessesDb(data.businesses || []);
        setDriversDb(data.drivers || []);
        setSecurityLogs(data.logs || []);
      }
    } catch (e) {
      console.warn("Failed fetching secure credential records", e);
    } finally {
      setLoadingSec(false);
    }
  };

  useEffect(() => {
    fetchSecurityRecords();
    const interval = setInterval(fetchSecurityRecords, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleAdminSecurityAction = async (id: string, type: 'business' | 'driver', action: 'Approve' | 'Reject' | 'Suspend') => {
    try {
      const res = await fetch('/api/security/admin/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, type, action })
      });
      if (res.ok) {
        await fetchSecurityRecords();
        if (selectedKycDoc && selectedKycDoc.id === id) {
          setSelectedKycDoc((prev: any) => ({ ...prev, status: action === 'Approve' ? 'Verified' : action === 'Reject' ? 'Rejected' : 'Suspended' }));
        }
      } else {
        const errText = await res.text();
        alert(`Failed taking administration action: ${errText}`);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Helper to project coordinates dynamically and responsively
  const getResponsiveCoords = (countyName: string) => {
    const normCounty = countyName.toLowerCase().trim();
    const hub = INDUSTRIAL_HUBS.find(h => h.county.toLowerCase() === normCounty);
    if (!hub) {
      return { left: '50%', top: '50%', x: 50, y: 50 };
    }
    // Convert longitude (85.3 min to 87.1 max) to 10% - 90% space
    const leftPercent = 10 + ((hub.lng - 85.3) / (87.1 - 85.3)) * 80;
    // Convert latitude (23.60 min to 23.83 max) to 15% - 85% space (inverted for CSS top)
    const topPercent = 85 - ((hub.lat - 23.60) / (23.83 - 23.60)) * 70;
    return {
      left: `${leftPercent}%`,
      top: `${topPercent}%`,
      x: leftPercent,
      y: topPercent
    };
  };

  const getDriverResponsiveCoords = (drv: Driver) => {
    const leftPercent = 10 + ((drv.currentLng - 85.3) / (87.1 - 85.3)) * 80;
    const topPercent = 85 - ((drv.currentLat - 23.60) / (23.83 - 23.60)) * 70;
    return {
      left: `${leftPercent}%`,
      top: `${topPercent}%`,
    };
  };

  // Compute key counters for B2B operator overview
  const totalBookingsCount = state.bookings.length;
  const activeBookingsCount = state.bookings.filter(b => b.status !== 'completed' && b.status !== 'cancelled').length;
  const totalDriversCount = state.drivers.length;
  const onlineDriversCount = state.drivers.filter(d => d.online).length;
  const unapprovedDriversCount = state.drivers.filter(d => !d.docsApproved).length;

  // Calculate platform financial logs
  const totalRevenueBooked = state.bookings
    .filter(b => b.paymentStatus === 'paid' || b.status === 'completed')
    .reduce((sum, b) => sum + b.costEstimate, 0);

  const platformCommissions = Math.round(totalRevenueBooked * (state.config.commissionPercent / 100));

  // Heatmap statistics based on regions
  const countyBookings = state.bookings.reduce((acc, b) => {
    acc[b.pickupCounty] = (acc[b.pickupCounty] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div id="admin-hq-panel" className="bg-coal-black min-h-screen text-zinc-100 rounded-3xl p-4 md:p-6 border border-steel-gray shadow-2xl">
      
      {/* Admin HQ Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-steel-gray pb-4 mb-6 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="bg-hazard-orange text-white p-1 rounded font-black font-mono text-[10px] tracking-widest animate-pulse">
              COMMAND SECTOR
            </div>
            <h1 className="text-xl md:text-2xl font-black font-display uppercase tracking-tight text-white flex items-center gap-2">
              COAL-BELT HQ <span className="text-hazard-yellow">CONTROL PANEL</span>
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            {language === 'en' 
              ? 'Real-Time B2B Dispatching, Miner Credentials Verification and Geofence Overwatch'
              : 'कोयला साइडिंग प्रेषण, ड्राइवर सत्यापन और जीपीएस जियोफेंस प्रबंधन केंद्र'}
          </p>
        </div>

        {/* Live Status Summary Pills */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="bg-mine-gray px-3 py-1.5 rounded-xl border border-steel-gray flex items-center gap-1.5 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span className="font-mono text-zinc-300">SERVER SECURE: 3000</span>
          </div>
          <div className="bg-mine-gray px-3 py-1.5 rounded-xl border border-steel-gray flex items-center gap-1.5 text-xs text-hazard-yellow">
            <Bell className="w-3.5 h-3.5 animate-bounce" />
            <span className="font-mono">{state.alerts.length} ALERTS ACTIVE</span>
          </div>
          {onLogout && (
            <button
              onClick={onLogout}
              className="bg-red-950/45 border border-red-900/40 hover:bg-red-950/70 text-red-400 hover:text-red-300 font-bold font-mono text-xs px-3 py-1.5 rounded-xl cursor-pointer flex items-center gap-1.5"
            >
              <LogOut className="w-3 h-3 text-red-400" />
              <span>TERMINATE HQ</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid Bento Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* SIDE BAR BUTTON NAVIGATION */}
        <div className="lg:col-span-1 space-y-2">
          
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-gradient-to-r from-hazard-yellow to-amber-500 text-coal-black'
                : 'bg-mine-gray text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <span>📊 OVERVIEW & MAP</span>
            <span className="font-mono bg-coal-black/20 text-[10px] px-1.5 rounded">{activeBookingsCount} active</span>
          </button>

          <button
            onClick={() => setActiveTab('drivers')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'drivers'
                ? 'bg-gradient-to-r from-hazard-yellow to-amber-500 text-coal-black'
                : 'bg-mine-gray text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <span>🚚 VERIFY DRIVERS</span>
            {unapprovedDriversCount > 0 ? (
              <span className="font-mono bg-red-600 text-white text-[10px] px-1.5 rounded animate-pulse">
                {unapprovedDriversCount} Alert
              </span>
            ) : (
              <span className="font-mono text-zinc-500">{totalDriversCount} registered</span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'bookings'
                ? 'bg-gradient-to-r from-hazard-yellow to-amber-500 text-coal-black'
                : 'bg-mine-gray text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <span>📋 BOOKING LEDGER</span>
            <span className="font-mono text-zinc-500">{totalBookingsCount} entries</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-gradient-to-r from-hazard-yellow to-amber-500 text-coal-black'
                : 'bg-mine-gray text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <span>⚙ SURGE & RATES</span>
            <span className="text-[10px] text-zinc-500 font-mono">Mult: {state.config.surgeMultiplier}x</span>
          </button>

          <button
            onClick={() => setActiveTab('securities')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
              activeTab === 'securities'
                ? 'bg-gradient-to-r from-hazard-yellow to-amber-500 text-coal-black'
                : 'bg-mine-gray text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <span>🛡 B2B SECURITY & KYC</span>
            <span className="font-mono bg-amber-600/20 text-hazard-yellow text-[10px] px-1.5 rounded border border-amber-950/40">
              AUDIT ACTIVE
            </span>
          </button>

          {/* DYNAMIC REGIONAL HEATMAP ACCENT */}
          <div className="bg-mine-gray p-4 rounded-2xl border border-steel-gray space-y-3 pt-3">
            <h4 className="text-[10px] font-bold font-mono tracking-widest text-zinc-400 uppercase">
              COAL SIDE OUTPOST FREQUENCY
            </h4>
            <div className="space-y-2">
              {Object.entries(countyBookings).map(([cty, count]) => (
                <div key={cty} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-zinc-300">{cty} Pit</span>
                    <span className="font-mono font-bold text-hazard-yellow">{count} loads</span>
                  </div>
                  <div className="w-full bg-stone-900 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-hazard-yellow h-full rounded-full"
                      style={{ width: `${Math.min(100, (count / (totalBookingsCount || 1)) * 100)}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* ---------------- ACTIVE WINDOW SWITCH CENTER ---------------- */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* ---------------- TAB 1: OVERVIEW & LIVE MONITORING MAP ---------------- */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              
              {/* Analytics Bento Cards Row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                
                <div className="bg-mine-gray p-3.5 rounded-2xl border border-steel-gray space-y-1">
                  <div className="flex justify-between items-center text-zinc-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">Total Commission</span>
                    <IndianRupee className="w-4 h-4 text-emerald-400 shrink-0" />
                  </div>
                  <p className="text-xl font-bold font-mono text-emerald-400">₹{platformCommissions}</p>
                  <p className="text-[9px] text-zinc-500 font-mono">At {state.config.commissionPercent}% platform cut</p>
                </div>

                <div className="bg-mine-gray p-3.5 rounded-2xl border border-steel-gray space-y-1">
                  <div className="flex justify-between items-center text-zinc-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">Active Bookings</span>
                    <Truck className="w-4 h-4 text-hazard-yellow shrink-0" />
                  </div>
                  <p className="text-xl font-bold font-mono text-white">{activeBookingsCount}</p>
                  <p className="text-[9px] text-zinc-500 font-mono">Mined cargo currently en-route</p>
                </div>

                <div className="bg-mine-gray p-3.5 rounded-2xl border border-steel-gray space-y-1">
                  <div className="flex justify-between items-center text-zinc-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">Fleets Online</span>
                    <Users className="w-4 h-4 text-zinc-300" />
                  </div>
                  <p className="text-xl font-bold font-mono text-white">{onlineDriversCount}/{totalDriversCount}</p>
                  <p className="text-[9px] text-zinc-500 font-mono">Drivers logged into siding duty</p>
                </div>

                <div className="bg-mine-gray p-3.5 rounded-2xl border border-steel-gray space-y-1">
                  <div className="flex justify-between items-center text-zinc-400">
                    <span className="text-[10px] font-bold uppercase tracking-wider">General Diesel</span>
                    <Flame className="w-4 h-4 text-hazard-orange" />
                  </div>
                  <p className="text-xl font-bold font-mono text-white">₹{state.config.baseDieselPrice}/L</p>
                  <p className="text-[9px] text-zinc-500 font-mono">Local State Jharkhand rate</p>
                </div>

              </div>

              {/* Live Overload & Safety Threat Warnings Center */}
              {state.alerts.length > 0 && (
                <div className="bg-red-950/20 border border-red-900 rounded-2xl p-4 space-y-2.5">
                  <h3 className="text-xs font-bold text-red-400 font-display uppercase tracking-widest flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-red-500 animate-pulse" />
                    <span>Active System Alerts / Geofence Security Overrides</span>
                  </h3>
                  
                  <div className="max-h-24 overflow-y-auto space-y-1.5 divide-y divide-red-900/30">
                    {state.alerts.map(al => (
                      <div key={al.id} className="pt-1.5 flex items-start gap-2 justify-between text-xs text-red-300">
                        <div className="flex items-start gap-1.5">
                          <AlertTriangle className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${al.severity === 'high' ? 'text-red-500' : 'text-amber-500'}`} />
                          <p className="leading-tight">
                            {language === 'en' ? al.messageEn : al.messageHi}
                          </p>
                        </div>
                        <span className="text-[9px] font-mono text-zinc-500 shrink-0">
                          {new Date(al.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Comprehensive Siding GPS Interactive Simulation Map */}
              <div className="bg-mine-gray p-4 rounded-2xl border border-steel-gray space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold font-display uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                    <Map className="w-4 h-4 text-hazard-yellow" />
                    <span>Dhanbad-Ramgarh-Asansol Siding Dispatch Heatmap Coordinates</span>
                  </h3>
                  <span className="text-[10px] font-mono text-zinc-400 uppercase bg-stone-900 px-2 py-0.5 rounded border border-steel-gray animate-pulse">
                    Live Telemetry Frame
                  </span>
                </div>

                <div className="w-full h-80 bg-stone-950 rounded-xl relative border border-zinc-800 overflow-hidden">
                  <div className="absolute inset-0 opacity-5 bg-hazard-stripes"></div>
                  
                  {/* Dynamic network connection paths */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
                    {(() => {
                      const paths = [
                        { from: 'Dhanbad', to: 'Asansol' },
                        { from: 'Dhanbad', to: 'Ramgarh' },
                        { from: 'Dhanbad', to: 'Jharia' },
                        { from: 'Jharia', to: 'Ramgarh' },
                        { from: 'Ramgarh', to: 'Asansol' },
                        { from: 'Bokaro', to: 'Dhanbad' },
                        { from: 'Bokaro', to: 'Ramgarh' },
                      ];
                      return paths.map((path, idx) => {
                        const fromCoord = getResponsiveCoords(path.from);
                        const toCoord = getResponsiveCoords(path.to);
                        return (
                          <line
                            key={idx}
                            x1={`${fromCoord.x}%`}
                            y1={`${fromCoord.y}%`}
                            x2={`${toCoord.x}%`}
                            y2={`${toCoord.y}%`}
                            stroke="#eab308"
                            strokeWidth="1.5"
                            strokeDasharray="4 2"
                          />
                        );
                      });
                    })()}
                  </svg>

                  {/* Visual Siding Nodes & coordinates drawn inside canvas */}
                  {INDUSTRIAL_HUBS.map((hub) => {
                    const coord = getResponsiveCoords(hub.county);
                    return (
                      <div 
                        key={hub.id} 
                        className="absolute -translate-x-1/2 -translate-y-1/2 bg-mine-gray border border-steel-gray p-2 px-2.5 rounded-lg flex flex-col shadow-xl z-10 hover:border-hazard-yellow transition-all cursor-pointer"
                        style={{
                          left: coord.left,
                          top: coord.top
                        }}
                      >
                        <div className="flex items-center gap-1.5">
                          <div className="w-2 h-2 rounded-full bg-hazard-yellow animate-pulse shrink-0" />
                          <span className="text-[10px] font-bold text-white leading-none truncate max-w-[80px]">
                            {language === 'en' ? hub.nameEn.split(' ')[0] : hub.nameHi.split(' ')[0]}
                          </span>
                        </div>
                        <span className="text-[7.5px] font-mono text-zinc-500 block mt-0.5 uppercase text-left truncate leading-tight w-24">
                          {hub.zones[0]}
                        </span>
                      </div>
                    );
                  })}

                  {/* Draw online drivers on the map */}
                  {state.drivers.filter(d => d.online).map((drv) => {
                    const coord = getDriverResponsiveCoords(drv);
                    return (
                      <div
                        key={drv.id}
                        className="absolute -translate-x-1/2 -translate-y-1/2 bg-coal-black text-amber-400 p-1.5 rounded-full border border-hazard-yellow shadow-md hover:scale-125 transition-transform z-20 text-xs cursor-pointer flex items-center justify-center"
                        title={`${drv.name} : ${drv.vehicleNumber}`}
                        style={{
                          left: coord.left,
                          top: coord.top,
                        }}
                      >
                        <Truck className="w-3.5 h-3.5 animate-bounce" />
                      </div>
                    );
                  })}

                  <div className="absolute bottom-3 left-3 bg-coal-black/90 p-2.5 rounded border border-steel-gray text-[9px] font-mono space-y-0.5 max-w-xs text-zinc-400 z-20">
                    <p className="font-bold text-white uppercase tracking-wider mb-1">Interactive Legend</p>
                    <p className="flex items-center gap-1">
                      <span className="w-2 h-2 bg-hazard-yellow rounded-full inline-block"></span>
                      <span>Industrial Washing Siding Node</span>
                    </p>
                    <p className="flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-amber-400 inline-block shrink-0" />
                      <span>Online Heavy Active Fleet Tracker</span>
                    </p>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ---------------- TAB 2: VERIFY DRIVER CREDENTIALS ---------------- */}
          {activeTab === 'drivers' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold font-display uppercase tracking-wider text-zinc-300">
                Onboarding KYC Drivers verification desk
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {state.drivers.map((drv) => (
                  <div key={drv.id} className="bg-mine-gray border border-steel-gray rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between border-b border-steel-gray pb-2">
                      <div>
                        <h4 className="text-xs font-bold text-white">{drv.name}</h4>
                        <p className="text-[10px] font-mono text-zinc-400 uppercase">
                          No: {drv.vehicleNumber} ({drv.vehicleType.replace('_', ' ')})
                        </p>
                      </div>
                      
                      {/* Document Verified Ribbon status */}
                      <span className={`text-[9.5px] px-2 py-0.5 rounded font-black font-mono tracking-wider ${
                        drv.docsApproved 
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-red-950 text-red-400 border border-red-900 animate-pulse'
                      }`}>
                        {drv.docsApproved ? 'APPROVED' : 'ACTION REQUIRED'}
                      </span>
                    </div>

                    {/* Driver credentials dump list */}
                    <div className="space-y-1 text-xs text-zinc-400 font-mono">
                      <p className="flex justify-between"><span>Aadhaar num:</span> <span className="text-zinc-200 font-bold">{drv.aadhaarNum}</span></p>
                      <p className="flex justify-between"><span>License code:</span> <span className="text-zinc-200 font-bold uppercase">{drv.licenseNum}</span></p>
                      <p className="flex justify-between"><span>Vehicle RC:</span> <span className="text-zinc-200 font-bold uppercase">{drv.rcNum}</span></p>
                      <p className="flex justify-between"><span>Phone index:</span> <span className="text-zinc-200 font-bold">{drv.phone}</span></p>
                    </div>

                    {/* Administration approval action state switcher */}
                    <div className="flex items-center gap-2 pt-2 border-t border-zinc-850">
                      {!drv.docsApproved ? (
                        <button
                          onClick={async () => {
                            await onApproveDriver(drv.id, true);
                            alert(`✓ Authenticated driver ${drv.name} for active transit orders!`);
                          }}
                          className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-coal-black font-bold uppercase text-[11px] py-2 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Check className="w-4 h-4" /> Approve Crew KYC
                        </button>
                      ) : (
                        <button
                          onClick={async () => {
                            await onApproveDriver(drv.id, false);
                            alert(`⚠ Revoked system credentials for driver ${drv.name}.`);
                          }}
                          className="flex-1 bg-zinc-850 hover:bg-zinc-800 text-red-400 font-semibold uppercase text-[10px] py-1.5 rounded-xl flex items-center justify-center gap-1 cursor-pointer border border-red-950"
                        >
                          <X className="w-3.5 h-3.5 text-red-500" /> Revoke System Access
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* ---------------- TAB 3: BOOKING TRANSACTIONS TABLE LEDGER ---------------- */}
          {activeTab === 'bookings' && (
            <div className="space-y-4">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 bg-mine-gray p-3 rounded-xl border border-steel-gray">
                <div>
                  <h3 className="text-xs font-bold font-display uppercase tracking-wider text-zinc-300">
                    B2B Active Shippers Invoice Ledger
                  </h3>
                  <p className="text-[10px] text-zinc-500">Audit-ready transport manifests and RTO tax statuses</p>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <Filter className="w-3.5 h-3.5 text-zinc-400" />
                  <select
                    value={filterCounty}
                    onChange={(e) => setFilterCounty(e.target.value)}
                    className="bg-stone-950 text-xs text-white border border-steel-gray rounded py-1 px-2 focus:outline-none"
                  >
                    <option value="All">All Regions</option>
                    <option value="Dhanbad">Dhanbad</option>
                    <option value="Ramgarh">Ramgarh</option>
                    <option value="Asansol">Asansol</option>
                    <option value="Jharia">Jharia</option>
                  </select>
                </div>
              </div>

              {/* Responsive Table layout */}
              <div className="overflow-x-auto bg-mine-gray rounded-2xl border border-steel-gray">
                <table className="w-full text-xs text-left border-collapse">
                  <thead>
                    <tr className="bg-stone-900 border-b border-steel-gray text-[10px] text-zinc-400 font-mono tracking-widest uppercase">
                      <th className="p-3">Order Code</th>
                      <th className="p-3">Client Firm</th>
                      <th className="p-3">Route range</th>
                      <th className="p-3">Tonnage</th>
                      <th className="p-3">Challan / Pass</th>
                      <th className="p-3">Rent / Fees</th>
                      < th className="p-3 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-steel-gray/50 font-mono">
                    {state.bookings
                      .filter(b => filterCounty === 'All' || b.pickupCounty === filterCounty || b.dropCounty === filterCounty)
                      .map((book) => (
                        <tr key={book.id} className="hover:bg-steel-gray/30">
                          <td className="p-3 whitespace-nowrap font-bold text-white">{book.id}</td>
                          <td className="p-3 whitespace-nowrap text-zinc-300 font-sans">{book.customerName}</td>
                          <td className="p-3 whitespace-nowrap text-zinc-400">
                            {book.pickupCounty} ➜ {book.dropCounty}
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <span className={book.isOverloaded ? 'text-rose-400 font-bold' : 'text-zinc-300'}>
                              {book.weightTons} Tons
                            </span>
                          </td>
                          <td className="p-3 whitespace-nowrap text-[10px] text-zinc-500">
                            {book.challanNumber}
                          </td>
                          <td className="p-3 whitespace-nowrap text-emerald-400 font-bold font-mono">
                            ₹{book.costEstimate + book.tollTaxEstimate + book.finesEstimate}
                          </td>
                          <td className="p-3 whitespace-nowrap text-right">
                            <span className={`text-[8px] px-1.5 py-0.5 rounded font-bold uppercase inline-block ${
                              book.status === 'completed' ? 'bg-emerald-950 text-emerald-400' :
                              book.status === 'cancelled' ? 'bg-zinc-800 text-zinc-400' :
                              book.status === 'pending' ? 'bg-stone-950 text-hazard-yellow' :
                              'bg-amber-950 text-amber-400'
                            }`}>
                              {book.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* ---------------- TAB 4: SYSTEM PRICING & SURGE MULTIPLIERS ---------------- */}
          {activeTab === 'settings' && (
            <div className="bg-mine-gray p-4 rounded-2xl border border-steel-gray space-y-6">
              
              <div>
                <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow">
                  Regional Pricing Multipliers & Siding Outpost Settings
                </h3>
                <p className="text-[10px] text-zinc-500 mt-1">
                  Fine-tune automatic dispatch margins and fuel surcharge thresholds for coal transit
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Dynamic surge multiplier adjustment */}
                <div className="space-y-2 bg-stone-950 p-4 rounded-xl border border-steel-gray">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold text-zinc-300 block uppercase">Surge Pricing Adjuster</label>
                    <span className="text-xs font-mono font-bold text-hazard-yellow bg-mine-gray px-2 py-0.5 rounded border border-steel-gray">
                      {state.config.surgeMultiplier}x
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-500">Applies dynamic pricing factor to base freight estimates across Ranchi, Dhanbad and Patratu.</p>
                  <input
                    type="range"
                    min="1.0"
                    max="2.5"
                    step="0.05"
                    value={state.config.surgeMultiplier}
                    onChange={async (e) => {
                      await onUpdateConfig({ surgeMultiplier: Number(e.target.value) });
                    }}
                    className="w-full accent-hazard-yellow h-1 bg-stone-800 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                {/* Local diesel price controls */}
                <div className="space-y-2 bg-stone-950 p-4 rounded-xl border border-steel-gray">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold text-zinc-350 block uppercase">Base Diesel Price (JH/WB)</label>
                    <span className="text-xs font-mono font-bold text-orange-400 bg-mine-gray px-2 py-0.5 rounded border border-steel-gray">
                      ₹{state.config.baseDieselPrice}/L
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-500">Syncs base fuel calculations for driver efficiency ratios and weekly earnings.</p>
                  <input
                    type="range"
                    min="85.0"
                    max="110.0"
                    step="0.10"
                    value={state.config.baseDieselPrice}
                    onChange={async (e) => {
                      await onUpdateConfig({ baseDieselPrice: Number(e.target.value) });
                    }}
                    className="w-full accent-hazard-orange h-1 bg-stone-800 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                <div className="space-y-2 bg-stone-950 p-4 rounded-xl border border-steel-gray">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold text-zinc-300 block uppercase">Platform Commission %</label>
                    <span className="text-xs font-mono font-bold text-white bg-mine-gray px-2 py-0.5 rounded border border-steel-gray">
                      {state.config.commissionPercent}%
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-500">Pre-allocated platform share automatically cut from driver earnings on completed delivery.</p>
                  <input
                    type="range"
                    min="5"
                    max="30"
                    step="1"
                    value={state.config.commissionPercent}
                    onChange={async (e) => {
                      await onUpdateConfig({ commissionPercent: Number(e.target.value) });
                    }}
                    className="w-full accent-white h-1 bg-stone-800 rounded-lg appearance-none cursor-pointer"
                  />
                </div>

                {/* Siding Weather and Geofence options togglers */}
                <div className="bg-stone-950 p-4 rounded-xl border border-steel-gray flex flex-col justify-between">
                  <span className="text-[11px] font-bold text-zinc-300 block uppercase mb-1">Geofence and Weather status</span>
                  
                  <div className="space-y-2 pt-1">
                    <label className="flex items-center gap-2 text-xs text-zinc-400 select-none">
                      <input
                        type="checkbox"
                        checked={state.config.isMonsoonActive}
                        onChange={async (e) => {
                          await onUpdateConfig({ isMonsoonActive: e.target.checked });
                        }}
                        className="rounded border-steel-gray text-hazard-yellow focus:ring-0 focus:ring-offset-0 bg-stone-900 w-4 h-4"
                      />
                      <span>Enable Monsoon Weather Peak (10% extra freight charge)</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs text-zinc-400 select-none">
                      <input
                        type="checkbox"
                        checked={state.config.geofenceEnabled}
                        onChange={async (e) => {
                          await onUpdateConfig({ geofenceEnabled: e.target.checked });
                        }}
                        className="rounded border-steel-gray text-hazard-yellow focus:ring-0 focus:ring-offset-0 bg-stone-900 w-4 h-4"
                      />
                      <span>Enforce Safety Geofencing Alerts for Coal Pits</span>
                    </label>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ---------------- TAB 5: B2B SECURITIES & KYC COMPLIANCE HQ ---------------- */}
          {activeTab === 'securities' && (
            <div className="space-y-6">
              
              {/* Top Analytical Badging Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gradient-to-br from-mine-gray to-stone-900 p-4 rounded-xl border border-steel-gray flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-zinc-500 block">Verified Corporates</span>
                    <span className="text-xl font-bold font-mono text-emerald-400">
                      {businessesDb.filter(b => b.status === 'Verified').length} Accounts
                    </span>
                  </div>
                  <Building className="w-8 h-8 text-emerald-500/30" />
                </div>

                <div className="bg-gradient-to-br from-mine-gray to-stone-900 p-4 rounded-xl border border-steel-gray flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-zinc-500 block">Pending Audits</span>
                    <span className="text-xl font-bold font-mono text-hazard-yellow animate-pulse">
                      {businessesDb.filter(b => b.status === 'Pending').length + driversDb.filter(d => d.status === 'Pending').length} Queue
                    </span>
                  </div>
                  <ShieldAlert className="w-8 h-8 text-hazard-yellow/30" />
                </div>

                <div className="bg-gradient-to-br from-mine-gray to-stone-900 p-4 rounded-xl border border-steel-gray flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-zinc-500 block">Anti-Spoof Triggers</span>
                    <span className="text-xl font-bold font-mono text-red-500">
                      {securityLogs.filter(l => l.eventType === 'FRAUD_ALERT' || l.eventType === 'LOCKOUT').length} Alarms
                    </span>
                  </div>
                  <Fingerprint className="w-8 h-8 text-red-500/30" />
                </div>

                <div className="bg-gradient-to-br from-mine-gray to-stone-900 p-4 rounded-xl border border-steel-gray flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-zinc-500 block">Live Guard System</span>
                    <span className="text-xl font-bold font-mono text-white">
                      AES-256 ACTIVE
                    </span>
                  </div>
                  <Shield className="w-8 h-8 text-blue-500/30" />
                </div>
              </div>

              {/* Main Auditing Table Panels */}
              <div className="bg-mine-gray p-4 rounded-2xl border border-steel-gray space-y-4">
                
                {/* Section Header */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-steel-gray pb-3">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-hazard-yellow flex items-center gap-1.5">
                      <Shield className="w-4 h-4 text-hazard-yellow" />
                      <span>Corporate Siding KYC Clearance & Fraud Audits</span>
                    </h3>
                    <p className="text-[10px] text-zinc-400 mt-1">Verify business licenses, Aadhaar records, and monitor suspicious miner device patterns</p>
                  </div>
                  <button 
                    onClick={fetchSecurityRecords}
                    className="bg-stone-950 p-2 rounded-lg border border-steel-gray text-[10px] font-mono hover:bg-stone-900 cursor-pointer flex items-center gap-1 text-zinc-405 hover:text-white"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>REFRESH LEDGER</span>
                  </button>
                </div>

                {/* Sub-grid: 2 Columns */}
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                  
                  {/* Column 1: Business KYC Queue (Takes 2 span on Excel grids) */}
                  <div className="xl:col-span-2 space-y-4">
                    
                    {/* Part A: Businesses */}
                    <div className="space-y-2">
                      <h4 className="text-[10px] font-bold font-mono tracking-widest text-zinc-400 uppercase flex items-center gap-1">
                        <Building className="w-3.5 h-3.5" />
                        <span>🏢 Coal Traders & Factory Owners Verified Signups ({businessesDb.length})</span>
                      </h4>

                      <div className="overflow-x-auto bg-stone-950 rounded-xl border border-steel-gray animate-fade-in">
                        <table className="w-full text-left text-xs text-zinc-300 font-sans">
                          <thead className="bg-stone-900 uppercase font-mono text-[9px] text-zinc-500 border-b border-steel-gray">
                            <tr>
                              <th className="p-3">Company Details</th>
                              <th className="p-3">Trader Identity</th>
                              <th className="p-3">Documents Checklist</th>
                              <th className="p-3">Status</th>
                              <th className="p-3 text-right">Clearance Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-steel-gray/60">
                            {businessesDb.length === 0 ? (
                              <tr>
                                <td colSpan={5} className="p-8 text-center text-zinc-500 font-mono text-[10px]">No corporate traders logged yet. Run simulations on client terminal!</td>
                              </tr>
                            ) : (
                              businessesDb.map(b => (
                                <tr key={b.id} className="hover:bg-mine-gray/60 transition-colors">
                                  <td className="p-3">
                                    <div className="font-bold text-white">{b.companyName}</div>
                                    <div className="text-[10px] text-zinc-500 font-mono">GST: {b.gstNumber}</div>
                                  </td>
                                  <td className="p-3">
                                    <div className="text-zinc-200">{b.ownerName}</div>
                                    <div className="text-[10px] text-zinc-500 font-mono">{b.mobile}</div>
                                  </td>
                                  <td className="p-3">
                                    <div className="flex flex-wrap gap-1">
                                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-zinc-905 border border-steel-gray text-zinc-400">GST Extract ✓</span>
                                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-zinc-905 border border-steel-gray text-zinc-400">PAN Card ✓</span>
                                      {b.coalPermit && <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-950/40 border border-amber-900/30 text-amber-400">Permit ✓</span>}
                                    </div>
                                  </td>
                                  <td className="p-3">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                                      b.status === 'Verified' ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900' :
                                      b.status === 'Suspended' ? 'bg-red-950/60 text-red-500 border border-red-900' :
                                      b.status === 'Rejected' ? 'bg-orange-950/60 text-orange-400 border border-orange-900' :
                                      'bg-amber-950/60 text-amber-300 border border-amber-900 animate-pulse'
                                    }`}>
                                      {b.status}
                                    </span>
                                  </td>
                                  <td className="p-3 text-right">
                                    <div className="flex items-center justify-end gap-1.5">
                                      <button
                                        onClick={() => setSelectedKycDoc({ ...b, type: 'business' })}
                                        className="bg-steel-gray hover:bg-zinc-700 text-white p-1.5 rounded text-[10px] font-mono flex items-center justify-center cursor-pointer"
                                        title="Inspect Documents"
                                      >
                                        <Eye className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleAdminSecurityAction(b.id, 'business', 'Approve')}
                                        className="bg-emerald-955 text-emerald-400 border border-emerald-900 hover:bg-emerald-900 hover:text-white p-1.5 rounded cursor-pointer"
                                        title="Approve immediately"
                                      >
                                        <Check className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleAdminSecurityAction(b.id, 'business', 'Suspend')}
                                        className="bg-red-955 text-red-400 border border-red-900 hover:bg-red-900 hover:text-white p-1.5 rounded cursor-pointer"
                                        title="Suspend Immediately"
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Part B: Drivers */}
                    <div className="space-y-2 pt-2">
                      <h4 className="text-[10px] font-bold font-mono tracking-widest text-zinc-400 uppercase flex items-center gap-1">
                        <Truck className="w-3.5 h-3.5" />
                        <span>🪪 Heavy Driver Biometrics & Permit Signups ({driversDb.length})</span>
                      </h4>

                      <div className="overflow-x-auto bg-stone-950 rounded-xl border border-steel-gray">
                        <table className="w-full text-left text-xs text-zinc-300 font-sans">
                          <thead className="bg-stone-900 uppercase font-mono text-[9px] text-zinc-500 border-b border-steel-gray">
                            <tr>
                              <th className="p-3">Driver Profile</th>
                              <th className="p-3">Vehicle / Permit Details</th>
                              <th className="p-3">Biometrics / Expiry Checks</th>
                              <th className="p-3">Status</th>
                              <th className="p-3 text-right">Verification</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-steel-gray/60 font-sans">
                            {driversDb.length === 0 ? (
                              <tr>
                                <td colSpan={5} className="p-8 text-center text-zinc-500 font-mono text-[10px]">No coal trucker profiles logged yet. Run simulation on driver terminal!</td>
                              </tr>
                            ) : (
                              driversDb.map(d => (
                                <tr key={d.id} className="hover:bg-mine-gray/60 transition-colors">
                                  <td className="p-3">
                                    <div className="font-bold text-white flex items-center gap-1.5">
                                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                      {d.driverName}
                                    </div>
                                    <div className="text-[10px] text-zinc-500 font-mono">{d.mobile}</div>
                                  </td>
                                  <td className="p-3">
                                    <div className="font-bold text-zinc-200">{d.vehicleNum}</div>
                                    <div className="text-[10px] text-zinc-500 font-mono uppercase">{d.vehicleType} Pit Pass</div>
                                  </td>
                                  <td className="p-3">
                                    <div className="space-y-1">
                                      <div className="flex items-center gap-1 font-mono text-[9.5px]">
                                        <Fingerprint className="w-3 h-3 text-cyan-400 font-bold" />
                                        <span className="text-cyan-400 font-bold">FaceMatch: {d.faceMatchConfidence}%</span>
                                      </div>
                                      <div className="text-[8.5px] text-zinc-500 uppercase leading-none font-mono">
                                        DL Expiry: {d.dlExpiry} (Active)
                                      </div>
                                    </div>
                                  </td>
                                  <td className="p-3">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                                      d.status === 'Verified' ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900' :
                                      d.status === 'Suspended' ? 'bg-red-950/60 text-red-500 border border-red-900' :
                                      d.status === 'Rejected' ? 'bg-orange-950/60 text-orange-400 border border-orange-900' :
                                      'bg-amber-950/60 text-amber-300 border border-amber-900 animate-pulse'
                                    }`}>
                                      {d.status}
                                    </span>
                                  </td>
                                  <td className="p-3 text-right">
                                    <div className="flex items-center justify-end gap-1.5">
                                      <button
                                        onClick={() => setSelectedKycDoc({ ...d, type: 'driver' })}
                                        className="bg-steel-gray hover:bg-zinc-700 text-white p-1.5 rounded text-[10px] font-mono cursor-pointer"
                                        title="Inspect Selfie & RC papers"
                                      >
                                        <Eye className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleAdminSecurityAction(d.id, 'driver', 'Approve')}
                                        className="bg-emerald-955 text-emerald-400 border border-emerald-900 hover:bg-emerald-900 hover:text-white p-1.5 rounded cursor-pointer"
                                        title="Mark verified immediately"
                                      >
                                        <Check className="w-3.5 h-3.5" />
                                      </button>
                                      <button
                                        onClick={() => handleAdminSecurityAction(d.id, 'driver', 'Suspend')}
                                        className="bg-red-955 text-red-400 border border-red-900 hover:bg-red-900 hover:text-white p-1.5 rounded cursor-pointer"
                                        title="Suspend Siding Pass"
                                      >
                                        <X className="w-3.5 h-3.5" />
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>

                  </div>

                  {/* Column 2: Anti-Spoof Logs & Fraud Alerts (Takes 1 span) */}
                  <div className="xl:col-span-1 space-y-4">
                    <h4 className="text-[10px] font-bold font-mono tracking-widest text-zinc-400 uppercase flex items-center gap-1">
                      <ShieldAlert className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                      <span>🛡 Security Intrusion Logs & Audits</span>
                    </h4>

                    <div className="bg-stone-950 rounded-xl p-3.5 border border-steel-gray space-y-3.5 max-h-[620px] overflow-y-auto font-mono text-[10.5px]">
                      
                      {securityLogs.length === 0 ? (
                        <div className="text-center py-10 text-zinc-600">No intrusion security alerts triggered yet.</div>
                      ) : (
                        securityLogs.map((log) => (
                          <div 
                            key={log.id} 
                            className={`p-3 rounded-lg border text-left space-y-2 relative overflow-hidden ${
                              log.eventType === 'FRAUD_ALERT' ? 'bg-red-950/20 border-red-900/40 text-red-200' :
                              log.eventType === 'LOCKOUT' ? 'bg-orange-950/20 border-orange-900/30 text-orange-300' :
                              log.eventType === 'AUTH_OTP_FAIL' ? 'bg-zinc-900 border-steel-gray text-zinc-300' :
                              'bg-emerald-950/10 border-emerald-900/30 text-emerald-300'
                            }`}
                          >
                            {/* Decorative visual shield warning background */}
                            <div className="absolute right-2 bottom-1 opacity-5">
                              <Shield className="w-16 h-16" />
                            </div>

                            <div className="flex items-center justify-between font-bold border-b border-steel-gray/40 pb-1.5">
                              <span className="uppercase text-[9px] tracking-wider bg-black/40 px-1.5 py-0.5 rounded">
                                Event: {log.eventType}
                              </span>
                              <span className="text-[8.5px] text-zinc-500">
                                {new Date(log.timestamp).toLocaleTimeString()}
                              </span>
                            </div>

                            <p className="text-[10.5px] leading-relaxed text-zinc-350">{log.message}</p>

                            <div className="text-[9px] text-zinc-500 space-y-0.5 bg-black/20 p-1.5 rounded leading-tight">
                              <div>IP: <span className="text-zinc-400">{log.ipAddress}</span></div>
                              <div>Device Flag: <span className="text-zinc-400 uppercase">{log.deviceFingerprint.substring(0, 15)}...</span></div>
                              {log.gpsRestrictions && (
                                <div className="text-red-400 font-bold">Location Integrity Gap Triggered</div>
                              )}
                            </div>
                          </div>
                        ))
                      )}

                    </div>
                  </div>

                </div>

              </div>

              {/* Siding KYC Inspector Modal (Glassmorphism Overlay Popup) */}
              {selectedKycDoc && (
                <div className="fixed inset-0 bg-stone-950/95 backdrop-blur-md z-50 flex items-center justify-center p-4">
                  <div className="max-w-xl w-full bg-mine-gray border border-steel-gray rounded-[2rem] shadow-2xl overflow-hidden text-left flex flex-col max-h-[90vh]">
                    
                    {/* Modal Title */}
                    <div className="bg-stone-950 p-5 border-b border-steel-gray flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Fingerprint className="text-hazard-yellow w-5 h-5" />
                        <div>
                          <h3 className="font-bold text-white uppercase text-xs font-mono">B2B Security Verification Console</h3>
                          <p className="text-[10px] text-zinc-500">OCR Parsing Confidence & Physical Documents Checklist</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => setSelectedKycDoc(null)}
                        className="text-zinc-400 hover:text-white font-black text-sm p-1.5 hover:bg-stone-900 rounded-lg cursor-pointer"
                      >
                        ✕ CLOSE
                      </button>
                    </div>

                    {/* Scrollable Contents */}
                    <div className="p-6 space-y-6 overflow-y-auto text-xs font-sans">
                      
                      {/* Document Details Block */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        
                        <div>
                          <label className="text-[10px] text-zinc-500 uppercase font-mono block font-bold">Target Operator Name</label>
                          <div className="text-sm font-bold text-white mt-1">
                            {selectedKycDoc.type === 'business' ? selectedKycDoc.ownerName : selectedKycDoc.driverName}
                          </div>
                          <div className="text-zinc-400 text-[11px] font-mono">{selectedKycDoc.mobile}</div>
                        </div>

                        <div>
                          <label className="text-[10px] text-zinc-500 uppercase font-mono block font-bold">Authorized Entity Name</label>
                          <div className="text-sm font-bold text-white mt-1">
                            {selectedKycDoc.type === 'business' ? selectedKycDoc.companyName : `Trucker Pass (${selectedKycDoc.vehicleType.toUpperCase()})`}
                          </div>
                          <div className="text-zinc-400 text-[11px] font-mono">
                            {selectedKycDoc.type === 'business' ? `GST: ${selectedKycDoc.gstNumber}` : `Plate: ${selectedKycDoc.vehicleNum}`}
                          </div>
                        </div>

                      </div>

                      {/* Document Viewer Photo Blocks */}
                      <div className="bg-stone-950 p-4 rounded-2xl border border-steel-gray space-y-4">
                        <span className="text-[10px] text-zinc-500 font-mono uppercase block font-bold border-b border-steel-gray/55 pb-1">Uploaded Document Artifact & Face Verification Biometrics</span>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                          
                          {/* Face matching for driver, or license for business */}
                          {selectedKycDoc.type === 'business' ? (
                            <>
                              <div className="p-4 bg-mine-gray rounded-xl border border-steel-gray">
                                <FileText className="w-8 h-8 text-hazard-yellow mx-auto mb-2" />
                                <div className="font-mono text-[9px] text-zinc-400">CORPORATE TRADE LICENSE</div>
                                <div className="text-emerald-450 font-bold mt-1 text-[11px] font-mono">OCR Match: 98% Confirmed</div>
                                <div className="text-[8.5px] text-zinc-500 mt-1 leading-none">ID: JH-TD-2026/89410</div>
                              </div>

                              <div className="p-4 bg-mine-gray rounded-xl border border-steel-gray">
                                <Fingerprint className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                                <div className="font-mono text-[9px] text-zinc-400 font-bold">AADHAAR / PAN GSTR KYC CARD</div>
                                <div className="text-emerald-450 font-bold mt-1 text-[11px] font-mono">NID Decrypted ✓</div>
                                <div className="text-[8.5px] text-zinc-500 mt-1 leading-none">NID Hash: {selectedKycDoc.gstNumber}</div>
                              </div>
                            </>
                          ) : (
                            <>
                              {/* Driver Photos & Selfie verification result */}
                              <div className="p-4 bg-mine-gray rounded-xl border border-steel-gray flex flex-col justify-center items-center">
                                <div className="w-12 h-12 rounded-full bg-zinc-800 border-2 border-dashed border-hazard-yellow flex items-center justify-center text-zinc-500 overflow-hidden mb-2 relative">
                                  {/* Face Silhouette */}
                                  <Camera className="w-5 h-5 text-hazard-yellow animate-pulse" />
                                </div>
                                <div className="font-mono text-[9px] text-zinc-400 uppercase">Live Selfie Scan</div>
                                <div className="text-cyan-400 text-[10px] font-bold font-mono mt-1">Biometrics Captured ✓</div>
                              </div>

                              <div className="p-4 bg-mine-gray rounded-xl border border-steel-gray flex flex-col justify-center items-center">
                                <div className="p-2 bg-stone-950 rounded-lg border border-steel-gray font-mono text-[11.5px] text-emerald-450 font-extrabold mb-1">
                                  {selectedKycDoc.faceMatchConfidence}% Matching Confidence
                                </div>
                                <div className="font-mono text-[9px] text-zinc-400 uppercase">Aadhaar Bio Validation</div>
                                <div className="text-[8px] text-zinc-500 mt-1 uppercase text-center leading-tight">Live face coordinates matched with State Aadhaar database.</div>
                              </div>
                            </>
                          )}

                        </div>

                        {/* OCR Verification checklist info lines */}
                        <div className="p-3 bg-zinc-950 rounded-xl border border-steel-gray text-[10px] font-mono text-zinc-400 space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                            <span>Aadhaar ID Card matches verified full name.</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                            <span>Taxation profile matches corporate registry status.</span>
                          </div>
                          <div className="flex items-center gap-1.5 py-0.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                            <span className="text-cyan-400 font-bold">Siding Gate access geofence permissions allowed.</span>
                          </div>
                        </div>

                      </div>

                      {/* Verification Audit Controls */}
                      <div className="space-y-2 border-t border-steel-gray/60 pt-4">
                        <label className="text-[10px] text-zinc-500 uppercase font-mono block font-bold mb-1.5">KYC Compliance Administration Action</label>
                        
                        <div className="grid grid-cols-3 gap-3">
                          <button
                            onClick={() => handleAdminSecurityAction(selectedKycDoc.id, selectedKycDoc.type, 'Approve')}
                            className="bg-emerald-700 hover:bg-emerald-600 text-white font-bold py-2 rounded-xl border border-emerald-900/40 text-center cursor-pointer flex items-center justify-center gap-1 text-[10px]"
                          >
                            <Check className="w-4 h-4" />
                            <span>APPROVE & VERIFY</span>
                          </button>

                          <button
                            onClick={() => handleAdminSecurityAction(selectedKycDoc.id, selectedKycDoc.type, 'Reject')}
                            className="bg-amber-650 hover:bg-amber-600 text-white font-bold py-2 rounded-xl border border-amber-900/40 text-center cursor-pointer flex items-center justify-center gap-1 text-[10px]"
                          >
                            <AlertTriangle className="w-4 h-4" />
                            <span>REJECT DOCUMENT</span>
                          </button>

                          <button
                            onClick={() => handleAdminSecurityAction(selectedKycDoc.id, selectedKycDoc.type, 'Suspend')}
                            className="bg-red-700 hover:bg-red-600 text-white font-bold py-2 rounded-xl border border-red-900/40 text-center cursor-pointer flex items-center justify-center gap-1 text-[10px]"
                          >
                            <X className="w-4 h-4" />
                            <span>SUSPEND & LOCK</span>
                          </button>
                        </div>
                      </div>

                    </div>

                  </div>
                </div>
              )}

            </div>
          )}

        </div>

      </div>

    </div>
  );
}

import React from 'react';
import { User, ShieldAlert, Truck, Wifi, WifiOff, Globe } from 'lucide-react';

interface RoleSelectorProps {
  currentRole: 'customer' | 'driver' | 'admin';
  onChangeRole: (role: 'customer' | 'driver' | 'admin') => void;
  language: 'en' | 'hi';
  onChangeLanguage: (lang: 'en' | 'hi') => void;
  isOffline: boolean;
  onToggleOffline: () => void;
}

export default function RoleSelector({
  currentRole,
  onChangeRole,
  language,
  onChangeLanguage,
  isOffline,
  onToggleOffline
}: RoleSelectorProps) {

  return (
    <div id="role-selector-container-id" className="bg-coal-black border-b border-steel-gray text-white p-3 md:p-4 sticky top-0 z-50 shadow-2xl">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-3 items-center justify-between">
        
        {/* Toggle Panel Title */}
        <div className="flex items-center gap-2">
          <div className="bg-hazard-stripes-subtle w-3 h-8 rounded shrink-0"></div>
          <div>
            <h2 className="text-sm font-bold font-display tracking-wide uppercase text-zinc-300">
              {language === 'en' ? 'Simulator Terminal Control' : 'सिम्युलेटर टर्मिनल कण्ट्रोल'}
            </h2>
            <p className="text-[10px] font-mono text-zinc-500">
              {language === 'en' ? 'Select device environment' : 'डिवाइस मोड बदलें'}
            </p>
          </div>
        </div>

        {/* Roles Toggles */}
        <div className="flex flex-wrap items-center gap-1.5 bg-mine-gray rounded-xl p-1 border border-steel-gray">
          <button
            id="role-btn-customer"
            onClick={() => onChangeRole('customer')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all cursor-pointer ${
              currentRole === 'customer'
                ? 'bg-hazard-yellow text-coal-black font-bold shadow-md shadow-amber-500/10'
                : 'text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <User className="w-4 h-4" />
            <span>{language === 'en' ? 'Customer App' : 'ग्राहक ऐप'}</span>
          </button>

          <button
            id="role-btn-driver"
            onClick={() => onChangeRole('driver')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all cursor-pointer ${
              currentRole === 'driver'
                ? 'bg-hazard-yellow text-coal-black font-bold shadow-md shadow-amber-500/10'
                : 'text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>{language === 'en' ? 'Driver App' : 'ड्राइवर ऐप'}</span>
          </button>

          <button
            id="role-btn-admin"
            onClick={() => onChangeRole('admin')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all cursor-pointer ${
              currentRole === 'admin'
                ? 'bg-hazard-orange text-white font-bold shadow-md shadow-amber-500/10'
                : 'text-zinc-400 hover:text-white hover:bg-steel-gray'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>{language === 'en' ? 'Admin Panel' : 'प्रशासक पोर्टल'}</span>
          </button>
        </div>

        {/* System Settings & Languages/Offline */}
        <div className="flex items-center gap-3">
          
          {/* Language Toggle */}
          <button
            id="lang-toggle-btn"
            onClick={() => onChangeLanguage(language === 'en' ? 'hi' : 'en')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-mine-gray border border-steel-gray hover:border-zinc-500 text-xs text-zinc-300 font-semibold cursor-pointer"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-hazard-yellow" />
            <span className="font-mono">{language === 'en' ? 'English' : 'हिंदी'}</span>
          </button>

          {/* Low Network Simulator */}
          <button
            id="offline-simulate-btn"
            onClick={onToggleOffline}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold font-mono tracking-wider transition-all cursor-pointer ${
              isOffline
                ? 'bg-red-950/80 text-red-400 border-red-700 animate-pulse'
                : 'bg-zinc-900 text-zinc-300 border-steel-gray hover:border-zinc-700'
            }`}
            title={language === 'en' ? 'Test offline database caching in mining valleys' : 'नेटवर्क कटौती सिम्युलेट करें'}
          >
            {isOffline ? (
              <>
                <WifiOff className="w-4 h-4 text-red-500" />
                <span>OFFLINE MODE</span>
              </>
            ) : (
              <>
                <Wifi className="w-4 h-4 text-emerald-500 animate-pulse" />
                <span>LOW-NET OK</span>
              </>
            )}
          </button>
          
        </div>

      </div>
    </div>
  );
}

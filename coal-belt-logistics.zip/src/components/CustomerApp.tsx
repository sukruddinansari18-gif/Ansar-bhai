import React, { useState, useEffect } from 'react';
import SidingQRScanner from './SidingQRScanner';
import { 
  Building, MapPin, Truck, HelpCircle, FileText, Upload, 
  Map, CreditCard, ChevronRight, CheckCircle2, History,
  Compass, AlertTriangle, IndianRupee, Shield, RefreshCw,
  Lock, Smartphone, QrCode, UserCheck, LogOut, Key, Timer,
  Check, X, Camera
} from 'lucide-react';
import { Booking, VehicleType, AppState } from '../types';
import { VEHICLE_SPECS, INDUSTRIAL_HUBS, TRANSLATIONS, GEOCONTEXT_GEOPATHS } from '../data';

interface CustomerAppProps {
  state: AppState;
  isOffline: boolean;
  onNewBooking: (bookingData: any) => Promise<void>;
  onTriggerAction: (bookingId: string, action: string, extra?: any) => Promise<void>;
  language: 'en' | 'hi';
  currentUser?: any;
  onLogout?: () => void;
}

export default function CustomerApp({
  state,
  isOffline,
  onNewBooking,
  onTriggerAction,
  language,
  currentUser,
  onLogout
}: CustomerAppProps) {
  const t = TRANSLATIONS[language];

  // Helper to project coordinates dynamically and responsively
  const getResponsiveCoords = (countyName: string) => {
    const normCounty = countyName.toLowerCase().trim();
    const hub = INDUSTRIAL_HUBS.find(h => h.county.toLowerCase() === normCounty);
    if (!hub) {
      return { left: '50%', top: '50%', x: 50, y: 50 };
    }
    // Convert longitude (85.3 min to 87.1 max) to 10% - 90% space
    const leftPercent = 10 + ((hub.lng - 85.3) / (87.1 - 85.3)) * 80;
    // Convert latitude (23.60 min to 23.83 max) to 15% - 85% space (inverted for CSS top)
    const topPercent = 85 - ((hub.lat - 23.60) / (23.83 - 23.60)) * 70;
    return {
      left: `${leftPercent}%`,
      top: `${topPercent}%`,
      x: leftPercent,
      y: topPercent
    };
  };

  // Mobile navigation
  const [activeTab, setActiveTab] = useState<'book' | 'history' | 'tracking'>('book');

  // Customer Login Session State
  const [isCustomerLoggedIn, setIsCustomerLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('customer_logged_in') === 'true';
  });
  const [loginPhone, setLoginPhone] = useState('9833454412');
  const [loginFirmName, setLoginFirmName] = useState('Hindustan Coke Traders');
  const [verificationCode, setVerificationCode] = useState('');
  const [simulatedCode, setSimulatedCode] = useState<string | null>(null);
  const [loginStep, setLoginStep] = useState<'phone' | 'otp'>('phone');
  const [otpErrorMsg, setOtpErrorMsg] = useState('');
  const [otpTimer, setOtpTimer] = useState(0);

  // Synchronize with currentUser prop from B2B security system
  useEffect(() => {
    if (currentUser) {
      setIsCustomerLoggedIn(true);
      setCustomerPhone(currentUser.mobile || currentUser.phone || '9833454412');
      setCustomerName(currentUser.companyName || currentUser.ownerName || 'Hindustan Coke Traders');
    }
  }, [currentUser]);

  // UPI Payment gateway states
  const [paymentGatewayMode, setPaymentGatewayMode] = useState<'modes' | 'upi_qr' | 'upi_id' | 'siding_camera_scan' | 'processing' | 'success'>('modes');
  const [upiIdInput, setUpiIdInput] = useState('coke_trader@okaxis');
  const [payCountdown, setPayCountdown] = useState(180); // 3 minutes tracker

  // Form State
  const [pickupHub, setPickupHub] = useState('dhanbad');
  const [dropHub, setDropHub] = useState('ramgarh');
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>('tata_407');
  const [weightTons, setWeightTons] = useState<number>(3.5);
  const [challanNumber, setChallanNumber] = useState('');
  const [coalPassId, setCoalPassId] = useState('');
  const [coalPassFile, setCoalPassFile] = useState<string | null>(null);
  const [customerPhone, setCustomerPhone] = useState(() => {
    return localStorage.getItem('customer_phone') || '9833454412';
  });
  const [customerName, setCustomerName] = useState(() => {
    return localStorage.getItem('customer_name') || 'Hindustan Coke Traders';
  });
  
  // Payment Simulator Dialog
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [pendingBookingId, setPendingBookingId] = useState<string | null>(null);
  const [pendingCost, setPendingCost] = useState(0);

  // Scanned QR settlements history log state
  const [scannedInvoices, setScannedInvoices] = useState<any[]>(() => {
    try {
      const stored = localStorage.getItem('scanned_invoices');
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn(e);
    }
    // Return mock initial scan records for audit reference to look polished immediately
    return [
      {
        id: "SCN-784102",
        bookingId: "BK-8831",
        sidingId: "DHN-SIDING-04",
        vpa: "dhn_siding_4@coalcentral",
        amount: 14500,
        scannedAt: "2026-06-01T14:22:15.000Z",
        status: "SETTLED"
      },
      {
        id: "SCN-342019",
        bookingId: "BK-7612",
        sidingId: "RMG-WEIGHT-02",
        vpa: "ramgarh_wb_2@coalcentral",
        amount: 22800,
        scannedAt: "2026-05-28T09:12:44.000Z",
        status: "SETTLED"
      }
    ];
  });
  const [selectedAuditInvoice, setSelectedAuditInvoice] = useState<any | null>(null);

  // Offline Queued bookings
  const [offlineQueue, setOfflineQueue] = useState<any[]>([]);

  // Load calculation
  const spec = VEHICLE_SPECS[selectedVehicle];
  const isOverloaded = weightTons > spec.capacityMaxTons;

  // Find routing specs
  const pickupObj = INDUSTRIAL_HUBS.find(h => h.id === pickupHub);
  const dropObj = INDUSTRIAL_HUBS.find(h => h.id === dropHub);
  
  const geoPath = GEOCONTEXT_GEOPATHS.find(
    p => (p.from === pickupObj?.county && p.to === dropObj?.county) ||
         (p.from === dropObj?.county && p.to === pickupObj?.county)
  ) || { distance: 15, baseTolls: 40, dangerIndex: 'Low (Local Siding)' };

  const calculatedBasePrice = spec.baseFare + (spec.perKmRate * geoPath.distance);
  const finalPrice = Math.round(calculatedBasePrice * state.config.surgeMultiplier * (state.config.isMonsoonActive ? 1.1 : 1.0));
  const overloadFine = isOverloaded ? Math.ceil((weightTons - spec.capacityMaxTons) * 1200) : 0;
  const dispatchTotalCost = finalPrice + geoPath.baseTolls + overloadFine;

  // Active en-route booking for live tracking
  const activeBooking = state.bookings.find(b => b.status !== 'completed' && b.status !== 'cancelled' && b.customerPhone === customerPhone) || state.bookings[0];

  // Map representation state
  const [mapAnimatedProgress, setMapAnimatedProgress] = useState(0);

  useEffect(() => {
    // Reset or update progress if active booking en-route
    if (activeBooking && activeBooking.status === 'en_route') {
      const interval = setInterval(() => {
        setMapAnimatedProgress(prev => (prev >= 100 ? 5 : prev + 5));
      }, 3000);
      return () => clearInterval(interval);
    } else {
      setMapAnimatedProgress(100);
    }
  }, [activeBooking]);

  // OTP Countdown Timer
  useEffect(() => {
    if (otpTimer > 0) {
      const timer = setTimeout(() => setOtpTimer(prev => prev - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [otpTimer]);

  // UPI checkout automatic expiry countdown
  useEffect(() => {
    if (showPaymentModal && payCountdown > 0) {
      const timer = setTimeout(() => setPayCountdown(prev => prev - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [showPaymentModal, payCountdown]);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginPhone || loginPhone.replace(/\D/g, '').length < 10) {
      setOtpErrorMsg(language === 'en' ? 'Please enter a valid 10-digit number.' : 'कृपया 10 अंकों का मान्य नंबर दर्ज करें।');
      return;
    }
    setOtpErrorMsg('');
    const randomCode = Math.floor(1000 + Math.random() * 9000).toString();
    setSimulatedCode(randomCode);
    setOtpTimer(45);
    setLoginStep('otp');
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    // Support either generated simulatedCode or standard '1234' for rapid evaluation testing
    if (verificationCode === simulatedCode || verificationCode === '1234') {
      localStorage.setItem('customer_logged_in', 'true');
      localStorage.setItem('customer_phone', loginPhone);
      localStorage.setItem('customer_name', loginFirmName);
      
      setIsCustomerLoggedIn(true);
      setCustomerPhone(loginPhone);
      setCustomerName(loginFirmName);
      setOtpErrorMsg('');
      setVerificationCode('');
      setSimulatedCode(null);
    } else {
      setOtpErrorMsg(language === 'en' ? 'Invalid OTP code. Try master code 1234.' : 'गलत ओटीपी। मास्टर कोड 1234 का उपयोग करें।');
    }
  };

  const handleCustomerLogout = () => {
    localStorage.removeItem('customer_logged_in');
    localStorage.removeItem('customer_phone');
    localStorage.removeItem('customer_name');
    setIsCustomerLoggedIn(false);
    setLoginStep('phone');
    if (onLogout) {
      onLogout();
    }
  };

  // Handle fake file drag/upload
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDropFile = (e: React.DragEvent) => {
    e.preventDefault();
    setCoalPassFile("coal_permit_official_signed.pdf");
    setCoalPassId("PASS-" + Math.floor(1000 + Math.random() * 9000));
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const bookingPayload = {
      customerName,
      customerPhone,
      pickupName: `${pickupObj?.nameEn} (${pickupObj?.zones[0]})`,
      dropName: `${dropObj?.nameEn} (${dropObj?.zones[0]})`,
      pickupCounty: pickupObj?.county,
      dropCounty: dropObj?.county,
      vehicleType: selectedVehicle,
      weightTons,
      challanNumber: challanNumber || `CH-M-${Math.floor(100000 + Math.random() * 900000)}`,
      coalPassId: coalPassId || `PASS-${Math.floor(1000 + Math.random() * 9000)}`,
      coalPassDocName: coalPassFile || "coal_siding_permit_digital_copy.pdf",
      paymentMethod: 'wallet',
      distanceKm: geoPath.distance
    };

    if (isOffline) {
      // Store in offline simulation stack
      const mockOfflineBooking: Booking = {
        id: `BK-OFF-${Math.floor(1000 + Math.random() * 9000)}`,
        ...bookingPayload as any,
        pickupCounty: pickupObj?.county as any,
        dropCounty: dropObj?.county as any,
        status: 'pending',
        isOverloaded,
        costEstimate: dispatchTotalCost,
        tollTaxEstimate: geoPath.baseTolls,
        finesEstimate: overloadFine,
        etaMinutes: 25,
        paymentStatus: 'pending',
        timestamp: new Date().toISOString(),
        isOfflineCreated: true
      };
      setOfflineQueue(prev => [mockOfflineBooking, ...prev]);
      alert(language === 'en' 
        ? "⚠️ App is OFFLINE. Booking saved locally in low-network siding cache. It will sync automatically as soon as low-net is disabled." 
        : "⚠️ ऐप इंटरनेट स्तर पर ऑफलाइन है! ट्रिप विवरण लोकल डिवाइस कैचे में सुरक्षित है। नेटवर्क लौटते ही सिंक हो जाएगा।"
      );
      return;
    }

    try {
      await onNewBooking(bookingPayload);
      const newlyCreated = state.bookings[0]; // best approximation 
      setPendingBookingId(newlyCreated?.id || `BK-${Math.floor(1000 + Math.random() * 9000)}`);
      setPendingCost(dispatchTotalCost);
      setShowPaymentModal(true);
      setActiveTab('history');
    } catch (err) {
      console.error(err);
    }
  };

  // Sync offline stack
  const syncOfflineBookings = async () => {
    if (isOffline) return;
    for (const b of offlineQueue) {
      await onNewBooking(b);
    }
    setOfflineQueue([]);
    alert(language === 'en' ? "✓ Local cached bookings successfully pushed to Coal-Belt servers!" : "✓ लोकल कैश बुकिंग को सर्वर पर सफलतापूर्वक सिंक कर दिया गया है!");
  };

  return (
    <div id="customer-phone-view-frame" className="max-w-md mx-auto bg-stone-950 border-4 border-zinc-800 rounded-[3rem] shadow-2xl relative overflow-hidden flex flex-col my-4 min-h-[750px] text-white">
      
      {/* Mobile Top Speaker and Camera Bar */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-5 bg-zinc-800 rounded-b-xl z-50 flex items-center justify-center">
        <span className="w-2 h-2 rounded-full bg-zinc-950 block"></span>
        <span className="w-10 h-1 bg-zinc-900 rounded-full block mx-2"></span>
      </div>

      {/* Screen Header */}
      <div className="bg-coal-black pt-8 pb-3 px-5 border-b border-steel-gray">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-sans">
            <div className="w-2.5 h-2.5 rounded-full bg-hazard-yellow animate-ping"></div>
            <div className="text-sm font-bold font-display uppercase tracking-wide">
              {t.appName}
            </div>
          </div>
          <div className="flex items-center gap-1.5 font-mono text-[10px]">
            {isCustomerLoggedIn ? (
              <>
                <span className="text-zinc-300 font-bold truncate max-w-[100px]" title={customerName}>
                  👤 {customerName.split(' ')[0]}
                </span>
                <button
                  onClick={handleCustomerLogout}
                  className="text-red-400 hover:text-red-300 bg-red-950/40 border border-red-900/30 px-1.5 py-0.5 rounded flex items-center gap-0.5 cursor-pointer"
                  title="Logout"
                >
                  <LogOut className="w-3 h-3 text-red-400" />
                  <span>OUT</span>
                </button>
              </>
            ) : (
              <span className="text-zinc-400 bg-mine-gray px-2 py-0.5 rounded border border-steel-gray">
                B2B CLIENT MOBILE
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Main Reactive Screen Content */}
      {!isCustomerLoggedIn ? (
        <div className="flex-1 flex flex-col justify-between p-5 space-y-6 overflow-y-auto">
          <div className="space-y-4 my-auto">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-hazard-yellow/10 border-2 border-dashed border-hazard-yellow rounded-full flex items-center justify-center mx-auto text-hazard-yellow">
                <Lock className="w-8 h-8" />
              </div>
              <h2 className="text-sm font-bold font-display uppercase tracking-wider text-white">
                {language === 'en' ? 'B2B Trader Verification' : 'व्यापारी डिजिटल और ओटीपी लॉगिन'}
              </h2>
              <p className="text-xs text-zinc-400">
                {language === 'en' 
                  ? 'Access secure coal loading siding logistics and fleet quotes for Dhanbad, Ramgarh, and Asansol.' 
                  : 'धनबाद, रामगढ़ और आसनसोल के लिए सुरक्षित कोयला बुकिंग तक पहुंचें।'}
              </p>
            </div>

            {/* Form step 1: Phone */}
            {loginStep === 'phone' ? (
              <form onSubmit={handleSendOtp} className="space-y-3 bg-mine-gray p-4 rounded-xl border border-steel-gray">
                <div>
                  <label className="text-[10px] text-zinc-400 uppercase font-mono block mb-1">
                    {language === 'en' ? 'B2B Trader Registered Firm' : 'पंजीकृत फर्म नाम'}
                  </label>
                  <input
                    type="text"
                    required
                    value={loginFirmName}
                    onChange={(e) => setLoginFirmName(e.target.value)}
                    placeholder="e.g., Coal Trader Corp"
                    className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-2.5 focus:border-hazard-yellow outline-none text-white font-bold animate-none"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 uppercase font-mono block mb-1">
                    {language === 'en' ? 'Indian Mobile Number' : 'भारतीय मोबाइल नंबर'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-zinc-500 font-mono font-bold">+91</span>
                    <input
                      type="tel"
                      required
                      placeholder="9833454412"
                      value={loginPhone}
                      onChange={(e) => setLoginPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-2.5 pl-12 focus:border-hazard-yellow outline-none text-white font-mono font-bold"
                    />
                  </div>
                </div>

                {otpErrorMsg && (
                  <p className="text-[10px] text-red-400 font-semibold">{otpErrorMsg}</p>
                )}

                <button
                  type="submit"
                  className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{language === 'en' ? 'Request OTP' : 'ओटीपी प्राप्त करें'}</span>
                </button>
              </form>
            ) : (
              /* Form step 2: OTP Entry */
              <form onSubmit={handleVerifyOtp} className="space-y-4 bg-mine-gray p-4 rounded-xl border border-steel-gray">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span>{language === 'en' ? 'Sent OTP code to' : 'ओटीपी भेजा गया:'} +91 {loginPhone}</span>
                    <button 
                      type="button" 
                      onClick={() => setLoginStep('phone')} 
                      className="text-hazard-yellow hover:underline"
                    >
                      {language === 'en' ? 'Change' : 'बदलें'}
                    </button>
                  </div>

                  {simulatedCode && (
                    <div className="bg-amber-950/70 border border-amber-800 p-2 rounded text-center text-xs">
                      <p className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
                        💬 SIMULATED SECURE SMS GATEWAY
                      </p>
                      <p className="text-xs text-white mt-1">
                        Your verification code is: <span className="font-mono font-black text-amber-300 tracking-widest text-sm">{simulatedCode}</span>
                      </p>
                      <button
                        type="button"
                        onClick={() => setVerificationCode(simulatedCode)}
                        className="text-[9px] mt-1.5 bg-hazard-yellow text-coal-black px-2 py-0.5 rounded font-bold uppercase hover:bg-white cursor-pointer"
                      >
                        Autofill Code
                      </button>
                    </div>
                  )}

                  <div className="mt-3">
                    <label className="text-[10px] text-zinc-400 uppercase font-mono block mb-1">
                      {language === 'en' ? 'Enter 4-Digit Code' : '४ अंकों का कोड दर्ज करें'}
                    </label>
                    <input
                      type="text"
                      maxLength={4}
                      required
                      placeholder="e.g. 1234"
                      value={verificationCode}
                      onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                      className="w-full bg-stone-950 border border-steel-gray text-center tracking-widest text-lg rounded py-2 focus:border-hazard-yellow outline-none text-white font-mono font-bold"
                    />
                  </div>
                </div>

                {otpErrorMsg && (
                  <p className="text-[10px] text-red-400 font-semibold">{otpErrorMsg}</p>
                )}

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setLoginStep('phone');
                      setOtpErrorMsg('');
                    }}
                    className="w-1/3 bg-zinc-800 text-zinc-400 hover:bg-zinc-700 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider"
                  >
                    {language === 'en' ? 'Back' : 'पीछे'}
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 bg-emerald-500 text-coal-black hover:bg-emerald-400 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider font-display flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>{language === 'en' ? 'Verify & Enter' : 'सत्यापित करें'}</span>
                  </button>
                </div>

                {/* Simulated default test credentials note */}
                <p className="text-[9px] text-zinc-500 text-center font-mono">
                  Master bypass security testing code: <span className="text-zinc-300 font-bold">1234</span>
                </p>
              </form>
            )}
          </div>

          <div className="text-center text-[10px] text-zinc-500 font-mono py-2">
            🔒 AES-256 Sessional Encryption • Coal-Belt 
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
          
          {/* Offline cache card alert */}
        {offlineQueue.length > 0 && (
          <div className="bg-amber-900/40 border border-amber-700/60 p-3 rounded-xl flex items-center justify-between">
            <div className="space-y-0.5">
              <p className="text-xs font-bold text-amber-400 font-display">
                {offlineQueue.length} Siding Bookings Cached Locally
              </p>
              <p className="text-[10px] text-zinc-300">
                Created offline during mine outage.
              </p>
            </div>
            {!isOffline ? (
              <button 
                onClick={syncOfflineBookings} 
                className="bg-hazard-yellow text-coal-black px-2.5 py-1 text-[11px] font-bold rounded hover:bg-yellow-400 flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                Sync
              </button>
            ) : (
              <span className="text-[10px] text-orange-400 italic">Offline</span>
            )}
          </div>
        )}

        {/* Dynamic Navigation Tabs */}
        <div className="grid grid-cols-3 bg-mine-gray/90 rounded-xl p-1 border border-steel-gray">
          <button
            onClick={() => setActiveTab('book')}
            className={`py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
              activeTab === 'book' ? 'bg-hazard-yellow text-stone-950 font-bold' : 'text-zinc-400'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>{language === 'en' ? 'Book' : 'बुक करें'}</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
              activeTab === 'history' ? 'bg-hazard-yellow text-stone-950 font-bold' : 'text-zinc-400'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>{language === 'en' ? 'History' : 'इतिहास'}</span>
          </button>
          <button
            onClick={() => setActiveTab('tracking')}
            className={`py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
              activeTab === 'tracking' ? 'bg-hazard-yellow text-stone-950 font-bold' : 'text-zinc-400'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>{language === 'en' ? 'Tracking' : 'जीपीएस'}</span>
          </button>
        </div>

        {/* B2B Secure Verification Badge & Info Alert Banner */}
        {currentUser && (
          <div className={`mt-3 p-3 text-left rounded-xl border flex items-start gap-2.5 backdrop-blur-md font-sans text-xs ${
            currentUser.status === 'Verified' ? 'bg-emerald-950/20 border-emerald-900/40 text-emerald-300' :
            currentUser.status === 'Suspended' ? 'bg-red-950/20 border-red-900/40 text-red-300' :
            currentUser.status === 'Rejected' ? 'bg-orange-950/20 border-orange-900/40 text-orange-400' :
            'bg-amber-950/20 border-amber-900/40 text-amber-300 animate-pulse'
          }`}>
            <Shield className={`w-5 h-5 shrink-0 ${
              currentUser.status === 'Verified' ? 'text-emerald-500' :
              currentUser.status === 'Suspended' ? 'text-red-500 animate-pulse' :
              currentUser.status === 'Rejected' ? 'text-orange-500' :
              'text-amber-500'
            }`} />
            <div>
              <div className="flex items-center gap-1.5 font-black uppercase text-[9px] tracking-wider leading-none font-mono">
                <span>Account Check: {currentUser.status || 'Pending Review'}</span>
                {currentUser.status === 'Verified' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 font-bold" />}
              </div>
              <p className="text-[9.5px] mt-1 text-zinc-350 leading-tight">
                {currentUser.status === 'Verified' && (language === 'en' 
                  ? '✓ Verified Coal Transit Credentials Active. Unlimited siding clearing privileges granted.' 
                  : '✓ आपका खाता प्रमाणित है। कोयला लोडिंग आर्डर और परिवहन अधिकार स्वीकृत हैं।')}
                {currentUser.status === 'Pending' && (language === 'en' 
                  ? '⚡ Awaiting supervisor physical clearance of trade license and GST certificate.' 
                  : '⚡ एडमिन सत्यापन की प्रतीक्षा है। आप ड्राफ्ट तैयार कर सकते हैं, परिवहन अनलॉकिंग बाकी है।')}
                {currentUser.status === 'Suspended' && (language === 'en' 
                  ? '☠️ Suspended by Haldia security. Blocked due to multiple registration device triggers.' 
                  : '☠️ सुरक्षा कारणों से यह खाता निलंबित है। कृपया आरटीओ ऑफिस में संपर्क करें।')}
                {currentUser.status === 'Rejected' && (language === 'en' 
                  ? '⚠️ Documents check failed (Expired Permits). Re-upload valid trade papers.' 
                  : '⚠️ आपके दस्तावेज ख़ारिज कर दिए गए हैं। वैध व्यापार परमिट पुनः अपलोड करें।')}
              </p>
            </div>
          </div>
        )}

        {/* ----------------- TAB 1: BOOKING INSTANTLY ----------------- */}
        {activeTab === 'book' && (
          <form onSubmit={handleBookingSubmit} className="space-y-4">
            
            {/* Siding Pickup & Siding Delivery Selector */}
            <div className="bg-mine-gray p-3.5 rounded-xl border border-steel-gray space-y-3">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow flex items-center gap-1">
                <Map className="w-3 h-3 text-hazard-yellow" />
                <span>1. Siding Locations (कोल फील्ड)</span>
              </h3>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2 bg-stone-950 p-2 rounded-lg border border-steel-gray">
                  <MapPin className="w-4 h-4 text-emerald-500 shrink-0" />
                  <div className="flex-1">
                    <label className="text-[9px] text-zinc-500 uppercase block font-mono font-bold leading-none">FROM (PICKUP PIT)</label>
                    <select
                      value={pickupHub}
                      onChange={(e) => setPickupHub(e.target.value)}
                      className="bg-transparent text-xs text-white font-semibold focus:outline-none w-full"
                    >
                      {INDUSTRIAL_HUBS.map(hub => (
                        <option key={hub.id} value={hub.id} className="bg-stone-900 text-white">
                          {language === 'en' ? hub.nameEn : hub.nameHi}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-stone-950 p-2 rounded-lg border border-steel-gray">
                  <MapPin className="w-4 h-4 text-red-500 shrink-0" />
                  <div className="flex-1">
                    <label className="text-[9px] text-zinc-500 uppercase block font-mono font-bold leading-none">TO (DESTINATION SIDING)</label>
                    <select
                      value={dropHub}
                      onChange={(e) => setDropHub(e.target.value)}
                      className="bg-transparent text-xs text-white font-semibold focus:outline-none w-full"
                    >
                      {INDUSTRIAL_HUBS.map(hub => (
                        <option key={hub.id} value={hub.id} className="bg-stone-900 text-white">
                          {language === 'en' ? hub.nameEn : hub.nameHi}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Display routing specifics */}
              <div className="bg-steel-gray/50 p-2 rounded text-[10px] font-mono text-zinc-300 flex items-center justify-between">
                <div>Distance: <span className="text-white font-bold">{geoPath.distance} km</span></div>
                <div>Coal Tolls: <span className="text-white font-bold">₹{geoPath.baseTolls}</span></div>
                <div className="text-hazard-yellow">Hills: {geoPath.dangerIndex}</div>
              </div>
            </div>

            {/* B2B Customer Identity */}
            <div className="bg-mine-gray p-3.5 rounded-xl border border-steel-gray space-y-2">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-hazard-yellow" />
                <span>B2B Trader Profile</span>
              </h3>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-zinc-400 block uppercase">Firm Name</label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-1.5 focus:border-zinc-500 outline-none text-white font-bold"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-zinc-400 block uppercase font-mono">Mobile (OTP Key)</label>
                  <input
                    type="text"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-1.5 focus:border-zinc-500 outline-none text-white font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Select heavy / mini vehicle type & visual capacity */}
            <div className="bg-mine-gray p-3 rounded-xl border border-steel-gray space-y-3">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-hazard-yellow" />
                <span>2. Select Vehicle Cargo (वाहन वर्ग)</span>
              </h3>

              <div className="grid grid-cols-2 gap-2 text-left">
                {Object.values(VEHICLE_SPECS).map((car) => (
                  <button
                    key={car.id}
                    type="button"
                    onClick={() => {
                      setSelectedVehicle(car.id);
                      setWeightTons(car.capacityMaxTons); // match default max payload
                    }}
                    className={`p-2 rounded-xl text-left border-2 transition-all cursor-pointer flex flex-col justify-between h-24 ${
                      selectedVehicle === car.id
                        ? 'bg-hazard-yellow/10 border-hazard-yellow text-white'
                        : 'bg-stone-900 border-steel-gray hover:border-zinc-700'
                    }`}
                  >
                    <div>
                      <p className="text-[11px] font-bold truncate leading-tight">
                        {language === 'en' ? car.nameEn : car.nameHi}
                      </p>
                      <p className="text-[8px] text-zinc-400 font-mono mt-0.5">
                        Max Payload: {car.capacityMaxTons} Tons
                      </p>
                    </div>
                    <div className="flex items-end justify-between w-full mt-2">
                      <span className="text-[10px] font-mono text-zinc-400 font-bold">
                        ₹{car.perKmRate}/km
                      </span>
                      <span className={`text-[8px] px-1 py-0.2 uppercase rounded font-bold ${
                        car.capacityMaxTons >= 10 ? 'bg-orange-950 text-orange-400' : 'bg-zinc-800 text-zinc-300'
                      }`}>
                        {car.capacityMaxTons >= 10 ? 'HEAVY MINE' : 'MINI TRUCK'}
                      </span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Tonnage loader slider */}
              <div className="bg-stone-950 p-2.5 rounded-lg border border-steel-gray space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-300 font-display font-semibold">Tonnage Slider:</span>
                  <span className="text-xs font-mono font-bold text-hazard-yellow">
                    {weightTons.toFixed(1)} {language === 'en' ? 'Metric Tons' : 'मीट्रिक टन'}
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="50"
                  step="0.5"
                  value={weightTons}
                  onChange={(e) => setWeightTons(Number(e.target.value))}
                  className="w-full accent-hazard-yellow h-1 bg-stone-800 rounded-lg appearance-none"
                />
                
                {/* Real-time Overload warning RTO */}
                {isOverloaded ? (
                  <div className="bg-amber-950/80 border border-amber-700 px-2 py-1.5 rounded flex items-start gap-1.5 text-[10px] text-amber-300">
                    <AlertTriangle className="w-4 h-4 text-hazard-yellow shrink-0" />
                    <div>
                      <span className="font-bold uppercase tracking-wider">{t.overloadWarning}</span>
                      <p className="text-[9px] text-zinc-400">
                        Mahindra/Tata payload capacity surpassed: +{(weightTons - spec.capacityMaxTons).toFixed(1)} Tons. Simulated penalty ₹1200 per extra ton.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-emerald-950/20 border border-emerald-900 px-2 py-1.5 rounded flex items-center gap-1.5 text-[10px] text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    <span>Safe load weight complies with transport authority rules</span>
                  </div>
                )}
              </div>
            </div>

            {/* Industrial Documents, Passes & Challans */}
            <div className="bg-mine-gray p-3 rounded-xl border border-steel-gray space-y-3">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow flex items-center gap-1">
                <FileText className="w-4 h-4 text-hazard-yellow" />
                <span>3. Siding & Coal Board Passes</span>
              </h3>

              <div className="space-y-1.5">
                <div>
                  <label className="text-[9px] text-zinc-400 uppercase font-mono block">Mining Authority Challan Number</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., CH-DND-228941"
                    value={challanNumber}
                    onChange={(e) => setChallanNumber(e.target.value)}
                    className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-2 focus:border-zinc-500 outline-none text-white font-mono"
                  />
                </div>

                {/* Siding Coal Permit Simulation Drag and Drop */}
                <div 
                  onDragOver={handleDragOver}
                  onDrop={handleDropFile}
                  onClick={() => {
                    setCoalPassFile("coal_permit_official_signed.pdf");
                    setCoalPassId("PASS-" + Math.floor(1000 + Math.random() * 9000));
                  }}
                  className="border-2 border-dashed border-steel-gray hover:border-zinc-500 rounded-lg p-3 bg-stone-950 flex flex-col items-center justify-center text-center cursor-pointer transition-colors"
                >
                  <Upload className="w-6 h-6 text-zinc-500 mb-1" />
                  <p className="text-[10px] font-semibold text-zinc-300">
                    {coalPassFile ? `✓ ${coalPassFile}` : 'Drag & Drop Coal Transport Permit (OR CLICK)'}
                  </p>
                  <p className="text-[8px] text-zinc-500 mt-0.5">PDF or PNG up to 10MB formats accepted</p>
                </div>
              </div>
            </div>

            {/* Interactive Quote and Confirm Summary */}
            <div className="bg-gradient-to-br from-mine-gray to-stone-950 p-3.5 rounded-xl border border-zinc-700 space-y-2">
              <div className="flex items-center justify-between text-xs border-b border-steel-gray pb-1.5 mb-1 text-zinc-400">
                <span>Distance Quote:</span>
                <span className="font-mono text-white">{geoPath.distance} km</span>
              </div>
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span>Vehicle Base Rent:</span>
                <span className="font-mono text-white">₹{finalPrice}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span>Siding Outpost Toll:</span>
                <span className="font-mono text-white">₹{geoPath.baseTolls}</span>
              </div>
              {isOverloaded && (
                <div className="flex items-center justify-between text-xs text-amber-400 font-bold">
                  <span>Overload Fine Fine:</span>
                  <span className="font-mono">+₹{overloadFine}</span>
                </div>
              )}
              {state.config.surgeMultiplier > 1.0 && (
                <div className="text-[9px] bg-amber-950 text-amber-400 rounded px-1.5 py-0.5 inline-block font-mono font-bold">
                  Surge active {state.config.surgeMultiplier}x
                </div>
              )}

              <div className="flex items-center justify-between text-sm font-bold pt-2 border-t border-zinc-800">
                <span className="text-zinc-200">Total Price Estimate:</span>
                <span className="text-emerald-500 font-mono text-lg flex items-center">
                  <IndianRupee className="w-4 h-4 text-emerald-500" />
                  {dispatchTotalCost}
                </span>
              </div>

              <button
                id="place-order-button"
                type="submit"
                className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all mt-2 cursor-pointer shadow-lg shadow-amber-500/10 flex items-center justify-center gap-1.5"
              >
                <Shield className="w-4 h-4" />
                <span>{t.placeOrder}</span>
              </button>
            </div>

          </form>
        )}

        {/* ----------------- TAB 2: BOOKING HISTORY & INVOICES ----------------- */}
        {activeTab === 'history' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-zinc-300">
                {language === 'en' ? 'Active & Past Bookings' : 'सभी पुराने आर्डर्स'}
              </h3>
              <span className="text-[10px] bg-mine-gray px-1.5 py-0.5 rounded font-mono text-zinc-400">
                {state.bookings.length} elements
              </span>
            </div>

            {state.bookings.length === 0 ? (
              <div className="text-center py-10 bg-mine-gray rounded-xl border border-steel-gray">
                <HelpCircle className="w-8 h-8 mx-auto text-zinc-600 mb-2" />
                <p className="text-xs text-zinc-500">{t.noBookings}</p>
              </div>
            ) : (
              state.bookings.map((booking) => (
                <div 
                  key={booking.id} 
                  className={`bg-mine-gray p-3.5 rounded-xl border transition-all ${
                    booking.status === 'en_route' || booking.status === 'loading'
                      ? 'border-hazard-yellow shadow-md shadow-amber-500/5'
                      : 'border-steel-gray'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-steel-gray pb-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-black text-white bg-stone-900 border border-steel-gray px-1.5 py-0.5 rounded">
                        {booking.id}
                      </span>
                      {booking.isOfflineCreated && (
                        <span className="bg-red-950 text-red-400 border border-red-900 text-[8px] font-bold px-1 rounded">
                          OFFLINE DATA
                        </span>
                      )}
                    </div>
                    
                    {/* Visual Status Pills */}
                    <span className={`text-[9px] px-2 py-0.5 rounded uppercase font-bold ${
                      booking.status === 'completed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                      booking.status === 'cancelled' ? 'bg-zinc-800 text-zinc-400' :
                      booking.status === 'pending' ? 'bg-stone-900 text-hazard-yellow animate-pulse border border-hazard-yellow/40' :
                      'bg-amber-950 text-amber-400 border border-amber-600 animate-pulse'
                    }`}>
                      {booking.status}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs text-zinc-400">
                    <p className="flex items-center justify-between text-zinc-300">
                      <span>Vehicle:</span>
                      <span className="font-semibold text-white uppercase">{booking.vehicleType.replace('_', ' ')}</span>
                    </p>
                    <p className="flex items-center justify-between">
                      <span>Weight:</span>
                      <span className="text-white font-semibold font-mono">{booking.weightTons} Metric Tons</span>
                    </p>
                    <p className="truncate">
                      From: <span className="text-zinc-200">{booking.pickupName}</span>
                    </p>
                    <p className="truncate">
                      To: <span className="text-zinc-200">{booking.dropName}</span>
                    </p>
                    <p className="flex items-center justify-between text-[11px] pt-1.5 text-zinc-500">
                      <span>Challan:</span>
                      <span className="font-mono text-zinc-300 text-[10px]">{booking.challanNumber}</span>
                    </p>
                  </div>

                  {/* Active Driver Assignment */}
                  {booking.driverName ? (
                    <div className="mt-2.5 bg-zinc-950 p-2 rounded border border-steel-gray flex items-center justify-between text-[11px]">
                      <div>
                        <p className="text-zinc-300 font-bold">{booking.driverName}</p>
                        <p className="text-zinc-500 text-[10px] font-mono">{booking.driverVehicleNumber}</p>
                      </div>
                      <span className="text-[10px] text-hazard-yellow bg-mine-gray px-1.5 rounded">
                        ★ {state.drivers.find(d => d.id === booking.driverId)?.rating || 4.7}
                      </span>
                    </div>
                  ) : booking.status === 'pending' ? (
                    <p className="text-[10px] text-amber-500 italic mt-2 animate-pulse">
                      Waiting for nearest heavy siding driver acceptance ...
                    </p>
                  ) : null}

                  {/* Pricing and Action trigger */}
                  <div className="mt-3 pt-2.5 border-t border-steel-gray flex items-center justify-between">
                    <div>
                      <p className="text-[10px] text-zinc-500">Invoice Sum</p>
                      <p className="text-emerald-400 font-mono font-black text-sm">
                        ₹{booking.costEstimate + booking.tollTaxEstimate + booking.finesEstimate}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {booking.paymentStatus === 'pending' && booking.status === 'completed' && (
                        <button
                          onClick={() => {
                            setPendingBookingId(booking.id);
                            setPendingCost(booking.costEstimate + booking.tollTaxEstimate + booking.finesEstimate);
                            setShowPaymentModal(true);
                          }}
                          className="bg-emerald-500 text-coal-black px-2.5 py-1 rounded text-[11px] font-bold uppercase cursor-pointer"
                        >
                          Settle Invoice
                        </button>
                      )}
                      
                      {booking.paymentStatus === 'paid' && (
                        <span className="text-[9px] bg-emerald-950/40 text-emerald-400 px-2 py-0.5 rounded border border-emerald-900 font-bold">
                          PAID & CLEARED
                        </span>
                      )}

                      {/* Simulated progress triggers for debug inside simulator */}
                      {booking.status !== 'completed' && booking.status !== 'cancelled' && (
                        <span className="text-[9px] text-zinc-500 bg-zinc-950 px-1.5 py-0.5 rounded italic">
                          Manage in Driver Tab 🚚
                        </span>
                      )}
                    </div>
                  </div>

                </div>
              ))
            )}

            {/* Scanned QR settlements log section */}
            <div className="pt-4 border-t border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <QrCode className="w-4 h-4 text-hazard-yellow" />
                  <h4 className="text-[11px] font-bold font-display uppercase tracking-wider text-zinc-300">
                    {language === 'en' ? 'Siding QR Scanned Invoices' : 'स्कैन किए गए इनवॉइस ऑडिट'}
                  </h4>
                </div>
                <span className="text-[9px] bg-emerald-950 text-emerald-400 font-mono px-2 py-0.5 rounded border border-emerald-800">
                  {scannedInvoices.length} {language === 'en' ? 'SCANS' : 'सत्यापित'}
                </span>
              </div>

              {scannedInvoices.length === 0 ? (
                <div className="text-center py-6 bg-zinc-950/40 rounded-xl border border-dashed border-zinc-800">
                  <p className="text-[10px] text-zinc-500">
                    {language === 'en' 
                      ? 'No physical QR code scans performed yet.' 
                      : 'अभी तक कोई भौतिक क्यूआर स्कैन नहीं किया गया है।'}
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {scannedInvoices.map((scan) => (
                    <div 
                      key={scan.id} 
                      onClick={() => setSelectedAuditInvoice(scan)}
                      className="bg-zinc-950 hover:bg-stone-900 border border-zinc-850 hover:border-hazard-yellow/50 p-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-2 max-w-[70%]">
                        <div className="w-8 h-8 rounded-lg bg-emerald-950/60 border border-emerald-900 flex items-center justify-center text-emerald-400">
                          <Check className="w-4 h-4" />
                        </div>
                        <div className="truncate text-left">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[11px] font-bold text-white group-hover:text-amber-400 transition-colors">
                              {scan.id}
                            </span>
                            <span className="text-[8px] bg-zinc-900 text-zinc-500 font-mono px-1 rounded truncate max-w-[66px]">
                              {scan.bookingId}
                            </span>
                          </div>
                          <p className="text-[9px] text-zinc-400 truncate leading-tight mt-0.5">
                            Siding: <span className="font-mono text-zinc-300 font-semibold">{scan.sidingId}</span>
                          </p>
                          <p className="text-[8px] text-zinc-500 font-mono truncate">
                            {new Date(scan.scannedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(scan.scannedAt).toLocaleDateString([], { day: '2-digit', month: 'short' })}
                          </p>
                        </div>
                      </div>

                      <div className="text-right flex flex-col items-end gap-1">
                        <span className="text-emerald-400 font-mono font-bold text-[12.5px] leading-none">
                          ₹{scan.amount}
                        </span>
                        <span className="text-[8px] text-zinc-500 underline uppercase tracking-wider group-hover:text-zinc-300">
                          {language === 'en' ? 'Audit Slip' : 'रसीद देखें'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

        {/* ----------------- TAB 3: LIVE GPS TRANSPORT TRACKING ----------------- */}
        {activeTab === 'tracking' && (
          <div className="space-y-4">
            
            {/* Live Visual Map Simulator */}
            <div className="bg-mine-gray p-3.5 rounded-xl border border-steel-gray space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow flex items-center gap-1.5">
                  <Compass className="w-4 h-4 text-hazard-yellow animate-spin" />
                  <span>Coal Board Live Dispatch</span>
                </h3>
                <span className="text-[10px] bg-emerald-950 text-emerald-400 px-1.5 rounded animate-pulse font-mono uppercase">
                  GPS Track On
                </span>
              </div>

              {activeBooking ? (
                <div className="space-y-3">
                  
                  {/* Map Visual Art Simulation */}
                  <div className="w-full h-56 bg-stone-950 rounded-lg border border-steel-gray relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5 bg-hazard-stripes"></div>
                    
                    {/* Dynamic network connection paths */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20 z-0">
                      {GEOCONTEXT_GEOPATHS.map((path, idx) => {
                        const fromCoord = getResponsiveCoords(path.from);
                        const toCoord = getResponsiveCoords(path.to);
                        return (
                          <line
                            key={idx}
                            x1={`${fromCoord.x}%`}
                            y1={`${fromCoord.y}%`}
                            x2={`${toCoord.x}%`}
                            y2={`${toCoord.y}%`}
                            stroke="#71717a"
                            strokeWidth="1"
                            strokeDasharray="2 2"
                          />
                        );
                      })}
                    </svg>

                    {/* Highlighting the active booking dispatch route in pulsing amber */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
                      {(() => {
                        const fromCoord = getResponsiveCoords(activeBooking.pickupCounty);
                        const toCoord = getResponsiveCoords(activeBooking.dropCounty);
                        return (
                          <line
                            x1={`${fromCoord.x}%`}
                            y1={`${fromCoord.y}%`}
                            x2={`${toCoord.x}%`}
                            y2={`${toCoord.y}%`}
                            stroke="#eab308"
                            strokeWidth="2.5"
                            strokeDasharray="4 2"
                            className="opacity-90 animate-pulse"
                          />
                        );
                      })()}
                    </svg>

                    {/* All industrial hub nodes as background context */}
                    {INDUSTRIAL_HUBS.map(hub => {
                      const coords = getResponsiveCoords(hub.county);
                      const isPickup = hub.county.toLowerCase() === activeBooking.pickupCounty.toLowerCase();
                      const isDrop = hub.county.toLowerCase() === activeBooking.dropCounty.toLowerCase();
                      return (
                        <div
                          key={hub.id}
                          className="absolute z-10 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center"
                          style={{ left: coords.left, top: coords.top }}
                        >
                          <div className={`w-2.5 h-2.5 rounded-full border border-[1.5px] border-black transition-all duration-300 ${
                            isPickup 
                              ? 'bg-emerald-400 ring-4 ring-emerald-500/20 scale-110' 
                              : isDrop 
                                ? 'bg-red-500 ring-4 ring-red-500/20 scale-110' 
                                : 'bg-zinc-700'
                          }`} />
                          <span className={`text-[8px] font-mono whitespace-nowrap mt-1 leading-none px-1 py-0.5 rounded ${
                            isPickup
                              ? 'bg-emerald-950/80 text-emerald-400 font-bold border border-emerald-500/10'
                              : isDrop
                                ? 'bg-red-950/80 text-red-400 font-bold border border-red-500/10'
                                : 'bg-zinc-900/60 text-zinc-500'
                          }`}>
                            {language === 'en' ? hub.nameEn.split(' ')[0] : hub.nameHi.split(' ')[0]}
                          </span>
                        </div>
                      );
                    })}

                    {/* Simulating truck dynamic GPS placement along active route */}
                    {(() => {
                      const fromCoord = getResponsiveCoords(activeBooking.pickupCounty);
                      const toCoord = getResponsiveCoords(activeBooking.dropCounty);
                      const ratio = activeBooking.status === 'en_route' ? mapAnimatedProgress / 100 : 
                                    (activeBooking.status === 'unloading' || activeBooking.status === 'completed' ? 1.0 : 0.0);
                      const tLeft = fromCoord.x + (toCoord.x - fromCoord.x) * ratio;
                      const tTop = fromCoord.y + (toCoord.y - fromCoord.y) * ratio;

                      return (
                        <div 
                          className="absolute bg-coal-black border-2 border-hazard-yellow text-hazard-yellow p-1.5 rounded-full shadow-lg z-20 -translate-x-1/2 -translate-y-1/2 transition-all duration-300 transform scale-110"
                          style={{
                            left: `${tLeft}%`,
                            top: `${tTop}%`,
                          }}
                        >
                          <Truck className="w-3.5 h-3.5 animate-pulse" />
                        </div>
                      );
                    })()}

                    <div className="absolute bottom-2 left-2 bg-coal-black/90 px-2 py-0.5 rounded text-[9px] font-mono border border-steel-gray text-zinc-300 z-20">
                      Mined Corridor: {activeBooking.pickupCounty} ➜ {activeBooking.dropCounty} ({activeBooking.distanceKm} KM)
                    </div>
                  </div>

                  {/* Trip Details Grid */}
                  <div className="bg-stone-950 p-3 rounded-lg border border-steel-gray space-y-1.5 text-xs">
                    <p className="flex justify-between font-bold">
                      <span className="text-zinc-400">Order ID:</span>
                      <span className="font-mono text-white">{activeBooking.id}</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-zinc-400">Dispatch Status:</span>
                      <span className="text-hazard-yellow font-bold uppercase">{activeBooking.status}</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-zinc-400">ETA Estimate:</span>
                      <span className="font-mono text-white text-right font-bold">{activeBooking.etaMinutes} minutes</span>
                    </p>
                    {activeBooking.driverVehicleNumber && (
                      <p className="flex justify-between">
                        <span className="text-zinc-400">Siding Driver:</span>
                        <span className="text-white font-bold">{activeBooking.driverName} ({activeBooking.driverVehicleNumber})</span>
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-zinc-500 text-xs">
                  No active logistics route currently initialized. Start a load booking to initiate live GPS mapping.
                </div>
              )}

            </div>
          </div>
        )}

      </div>
      )}

      {/* UPI / Wallet Simulated Payment Modal */}
      {showPaymentModal && (
        <div className="absolute inset-0 bg-coal-black/98 z-[60] flex flex-col justify-center p-4 overflow-y-auto">
          <div className="bg-zinc-900 border border-steel-gray rounded-2xl p-5 space-y-4 text-center max-w-sm mx-auto w-full">
            
            {/* Header with live ticking countdown */}
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <span className="text-[10px] bg-amber-500/10 text-hazard-yellow border border-hazard-yellow/20 px-2 py-0.5 rounded font-mono font-bold flex items-center gap-1">
                <Timer className="w-3 h-3 animate-pulse" />
                <span>
                  {Math.floor(payCountdown / 60)}:{(payCountdown % 60).toString().padStart(2, '0')}
                </span>
              </span>
              <span className="text-[10px] font-mono font-bold text-zinc-400">
                GATEWAY: COAL-PAY v3
              </span>
              <button 
                onClick={() => {
                  setShowPaymentModal(false);
                  setPaymentGatewayMode('modes');
                }}
                className="text-zinc-500 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Step-by-Step Payment Interface */}
            {paymentGatewayMode === 'modes' && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <h2 className="text-sm font-bold font-display uppercase tracking-wider text-white">
                    Settle Siding Invoice
                  </h2>
                  <p className="text-[11px] text-zinc-400">
                    Secure B2B Clearance for load <span className="font-mono text-white font-bold">{pendingBookingId}</span>
                  </p>
                </div>

                <div className="bg-stone-950 p-3 rounded-xl border border-steel-gray">
                  <p className="text-[10px] text-zinc-500 text-left font-mono">PAYABLE INVOICE AMOUNT</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-[10px] text-zinc-400">Basic + Tolls + RTO Toll-Overload</span>
                    <span className="text-emerald-400 font-mono font-black text-xl flex items-center">
                      <IndianRupee className="w-4 h-4 text-emerald-400" />
                      {pendingCost}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-[10px] text-zinc-400 text-left uppercase font-mono tracking-wider">Choose Instant API Option</p>
                  
                  {/* Camera-based physical QR code scan at the siding */}
                  <button
                    onClick={() => setPaymentGatewayMode('siding_camera_scan')}
                    className="w-full bg-amber-500/10 hover:bg-amber-500/15 border border-dashed border-hazard-yellow rounded-xl p-3 flex items-center justify-between text-left transition-all cursor-pointer shadow-[0_0_12px_rgba(234,179,8,0.05)] hover:border-solid hover:scale-[1.01]"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative w-8 h-8 rounded-lg bg-amber-500/20 border border-hazard-yellow/40 flex items-center justify-center text-hazard-yellow">
                        <Camera className="w-5 h-5" />
                        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full animate-ping"></span>
                        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white flex items-center gap-1.5 leading-none">
                          <span>Scan Physical Siding QR</span>
                          <span className="text-[8px] bg-hazard-yellow text-black px-1 rounded-sm uppercase font-mono font-black animate-pulse">Live Cam</span>
                        </p>
                        <p className="text-[9px] text-zinc-400 mt-1">Scan board at siding for direct clearance & gatepass</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-zinc-500" />
                  </button>

                  {/* UPI QR Option Button */}
                  <button
                    onClick={() => setPaymentGatewayMode('upi_qr')}
                    className="w-full bg-stone-950 hover:bg-zinc-800 border border-zinc-700 hover:border-hazard-yellow rounded-xl p-3 flex items-center justify-between text-left transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-hazard-yellow/20 flex items-center justify-center text-hazard-yellow">
                        <QrCode className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white">Scan UPI QR Code</p>
                        <p className="text-[9px] text-zinc-400">Instant Bhim, GPay, Paytm, PhonePe</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-zinc-500" />
                  </button>

                  {/* UPI ID / VPA Option Button */}
                  <button
                    onClick={() => setPaymentGatewayMode('upi_id')}
                    className="w-full bg-stone-950 hover:bg-zinc-800 border border-zinc-700 hover:border-hazard-yellow rounded-xl p-3 flex items-center justify-between text-left transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-950 flex items-center justify-center text-emerald-400">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white">Enter UPI ID / VPA</p>
                        <p className="text-[9px] text-zinc-400">Direct collect request on smart device</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-zinc-500" />
                  </button>
                </div>

                <button
                  onClick={() => {
                    setShowPaymentModal(false);
                  }}
                  className="w-full bg-zinc-800 text-zinc-400 uppercase text-[10px] py-2 rounded-xl text-center font-bold hover:bg-zinc-700 cursor-pointer"
                >
                  Pay Manually later in Office
                </button>
              </div>
            )}

            {/* PHYSICAL SIDING CAMERA SCAN MODE */}
            {paymentGatewayMode === 'siding_camera_scan' && (
              <SidingQRScanner
                language={language}
                pendingCost={pendingCost}
                pendingBookingId={pendingBookingId}
                onClose={() => setPaymentGatewayMode('modes')}
                onScanSuccess={(data) => {
                  setPaymentGatewayMode('processing');
                  
                  // Parse QR data stream
                  let parsedSiding = "General Siding";
                  let parsedVpa = "coal_siding@upi";
                  try {
                    const parts = data.split('|');
                    const vpaPart = parts.find(p => p.startsWith('SIDING_PAYMENT_VPA:'));
                    const gatePart = parts.find(p => p.startsWith('GATE:'));
                    if (vpaPart) parsedVpa = vpaPart.replace('SIDING_PAYMENT_VPA:', '');
                    if (gatePart) parsedSiding = gatePart.replace('GATE:', '');
                  } catch (e) {
                    console.warn(e);
                  }

                  const newRecord = {
                    id: `SCN-${Math.floor(100000 + Math.random() * 900000)}`,
                    bookingId: pendingBookingId || 'Ad-Hoc Clear',
                    sidingId: parsedSiding,
                    vpa: parsedVpa,
                    amount: pendingCost,
                    scannedAt: new Date().toISOString(),
                    status: 'SETTLED'
                  };

                  setScannedInvoices(prev => {
                    const updated = [newRecord, ...prev];
                    try {
                      localStorage.setItem('scanned_invoices', JSON.stringify(updated));
                    } catch (e) {
                      console.warn(e);
                    }
                    return updated;
                  });

                  setTimeout(() => {
                    setPaymentGatewayMode('success');
                    if (pendingBookingId) {
                      onTriggerAction(pendingBookingId, "pay");
                    }
                  }, 1200);
                }}
              />
            )}

            {/* APP QR MODE */}
            {paymentGatewayMode === 'upi_qr' && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                    Coal Board Logistics UPI QR Code
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    Valid for this sessional invoice request only
                  </p>
                </div>

                {/* Simulated Polished Dynamic B2B QR Code */}
                <div className="bg-white p-3 rounded-xl max-w-[170px] mx-auto border-4 border-hazard-yellow shadow-inner relative flex flex-col items-center">
                  <div className="w-36 h-36 relative flex items-center justify-center bg-zinc-550">
                    {/* SVG representing a highly authentic QR pattern */}
                    <svg viewBox="0 0 100 100" className="w-full h-full text-zinc-950">
                      <rect width="25" height="25" fill="currentColor" />
                      <rect x="5" y="5" width="15" height="15" fill="white" />
                      <rect x="8" y="8" width="9" height="9" fill="currentColor" />

                      <rect x="75" width="25" height="25" fill="currentColor" />
                      <rect x="80" y="5" width="15" height="15" fill="white" />
                      <rect x="83" y="8" width="9" height="9" fill="currentColor" />

                      <rect y="75" width="25" height="25" fill="currentColor" />
                      <rect x="5" y="80" width="15" height="15" fill="white" />
                      <rect x="8" y="83" width="9" height="9" fill="currentColor" />

                      <rect x="35" y="35" width="30" height="30" fill="currentColor" />
                      <rect x="40" y="40" width="20" height="20" fill="white" />
                      <rect x="45" y="45" width="10" height="10" fill="currentColor" />
                      
                      {/* Random dot clusters */}
                      <rect x="30" y="10" width="10" height="5" fill="currentColor" />
                      <rect x="50" y="5" width="5" height="10" fill="currentColor" />
                      <rect x="15" y="35" width="5" height="20" fill="currentColor" />
                      <rect x="70" y="45" width="15" height="5" fill="currentColor" />
                      <rect x="45" y="70" width="8" height="15" fill="currentColor" />
                      <rect x="80" y="60" width="10" height="10" fill="currentColor" />
                    </svg>
                    {/* Center Coal Belt Logo Overlay */}
                    <div className="absolute w-8 h-8 bg-black border-2 border-zinc-800 rounded flex items-center justify-center font-mono font-black text-[7px] text-hazard-yellow tracking-tighter shadow-lg">
                      COAL
                    </div>
                  </div>
                  <span className="text-[8px] font-bold text-zinc-600 mt-2 tracking-wide font-mono uppercase">
                    Ref: {pendingBookingId}
                  </span>
                </div>

                <div className="bg-stone-950 p-2.5 rounded border border-steel-gray flex items-center justify-between text-xs font-mono">
                  <span className="text-zinc-500">Amount due:</span>
                  <span className="text-emerald-400 font-bold">₹{pendingCost}</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setPaymentGatewayMode('modes')}
                    className="bg-zinc-800 text-zinc-400 font-bold text-[10px] py-2 rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => {
                      setPaymentGatewayMode('processing');
                      // Trigger simulating banking nodes callback
                      let p = 0;
                      const iv = setInterval(() => {
                        p += 20;
                        if (p >= 100) {
                          clearInterval(iv);
                          setPaymentGatewayMode('success');
                          if (pendingBookingId) {
                            onTriggerAction(pendingBookingId, "pay");
                          }
                        }
                      }, 400);
                    }}
                    className="bg-hazard-yellow text-coal-black font-bold text-[10px] py-2 rounded-xl flex items-center justify-center gap-1 hover:bg-yellow-400 cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Confirm Paid</span>
                  </button>
                </div>
              </div>
            )}

            {/* UPI ID ENTRY */}
            {paymentGatewayMode === 'upi_id' && (
              <div className="space-y-4 text-left">
                <div className="space-y-1 text-center">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                    Secure UPI VPA Collect
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    A collect request will be sent to your UPI address
                  </p>
                </div>

                <div className="space-y-2 bg-stone-950 p-3 rounded-xl border border-steel-gray">
                  <div>
                    <label className="text-[9px] text-zinc-500 uppercase font-mono block mb-1">
                      ENTER UPI ID / VPA ADDRESS
                    </label>
                    <input
                      type="text"
                      value={upiIdInput}
                      onChange={(e) => setUpiIdInput(e.target.value)}
                      placeholder="e.g. logistics@ybl, trader@paytm"
                      className="w-full bg-zinc-900 border border-zinc-700 text-xs rounded p-2 focus:border-hazard-yellow outline-none text-white font-semibold font-mono"
                    />
                  </div>

                  <div className="flex justify-between items-center text-[10px] pt-1">
                    <span className="text-zinc-500 font-mono">Invoice Sum:</span>
                    <span className="text-emerald-400 font-mono font-bold">₹{pendingCost}</span>
                  </div>
                </div>

                {/* Rapid test recommendations */}
                <div>
                  <span className="text-[8px] text-zinc-500 block uppercase font-mono mb-1">Select fast-vpa sandbox:</span>
                  <div className="flex flex-wrap gap-1">
                    {['coke_trader@okaxis', 'coal_firm@paytm', 'siding_depot@ybl'].map(id => (
                      <button
                        key={id}
                        type="button"
                        onClick={() => setUpiIdInput(id)}
                        className="text-[9px] bg-zinc-800 text-zinc-300 hover:text-white px-2 py-0.5 rounded border border-steel-gray hover:border-zinc-500 cursor-pointer"
                      >
                        {id}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <button
                    onClick={() => setPaymentGatewayMode('modes')}
                    className="bg-zinc-800 text-zinc-400 font-bold text-xs py-2 rounded-xl text-center"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => {
                      if (!upiIdInput.includes('@')) {
                        alert("Please enter a valid format UPI ID (containing '@')");
                        return;
                      }
                      setPaymentGatewayMode('processing');
                      let p = 0;
                      const iv = setInterval(() => {
                        p += 20;
                        if (p >= 100) {
                          clearInterval(iv);
                          setPaymentGatewayMode('success');
                          if (pendingBookingId) {
                            onTriggerAction(pendingBookingId, "pay");
                          }
                        }
                      }, 500);
                    }}
                    className="bg-emerald-500 text-coal-black font-bold text-xs py-2 rounded-xl flex items-center justify-center gap-1 hover:bg-emerald-400 cursor-pointer uppercase tracking-wider"
                  >
                    <span>Request Fund</span>
                  </button>
                </div>
              </div>
            )}

            {/* PROCESSING SECURE TRANSACTION STATE */}
            {paymentGatewayMode === 'processing' && (
              <div className="space-y-4 py-6 text-center">
                <div className="w-12 h-12 border-4 border-t-hazard-yellow border-zinc-800 rounded-full animate-spin mx-auto"></div>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-white uppercase tracking-wider animate-pulse">
                    Authorizing Sandbox Settle Node
                  </p>
                  <p className="text-[10px] text-zinc-500 font-mono">
                    Querying secure banking database tokens ...
                  </p>
                </div>

                <div className="text-[9px] bg-stone-950 p-2.5 rounded border border-steel-gray space-y-1 text-left font-mono text-zinc-400">
                  <p>✔ Checking Siding Ledger limits...</p>
                  <p>✔ Sending Razorpay/UPI digital intent token...</p>
                  <p className="text-hazard-yellow">⏳ Awaiting secure customer dual authorization...</p>
                </div>
              </div>
            )}

            {/* SUCCESS STATE */}
            {paymentGatewayMode === 'success' && (
              <div className="space-y-4 py-4 text-center">
                <div className="w-14 h-14 bg-emerald-950 text-emerald-400 border-2 border-emerald-500 rounded-full flex items-center justify-center mx-auto text-3xl shadow-lg shadow-emerald-500/20">
                  ✓
                </div>

                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    Coal Board Cleared
                  </h3>
                  <p className="text-xs text-emerald-400 font-bold font-mono">
                    ₹{pendingCost} PAID SUCCESSFULLY
                  </p>
                  <p className="text-[9px] text-zinc-500 font-mono mt-1">
                    Ref ID: SEC-{pendingBookingId}-{Math.floor(1000 + Math.random() * 9000)}
                  </p>
                </div>

                <div className="bg-stone-950 p-2.5 rounded border border-steel-gray text-[10px] font-mono text-left space-y-0.5 text-zinc-400">
                  <p className="text-white font-bold">Logistics clearance logs updated.</p>
                  <p>Vehicle gate permit status released dynamically.</p>
                </div>

                <button
                  onClick={() => {
                    setShowPaymentModal(false);
                    setPaymentGatewayMode('modes');
                  }}
                  className="w-full bg-emerald-500 text-coal-black hover:bg-emerald-400 font-bold text-xs py-2.5 rounded-xl transition-all cursor-pointer shadow-lg tracking-wider"
                >
                  OK • BACK TO BOOKINGS
                </button>
              </div>
            )}

          </div>
        </div>
      )}

      {/* Detailed Scanned Invoice Audit Slip Modal */}
      {selectedAuditInvoice && (
        <div className="absolute inset-0 bg-coal-black/98 z-[60] flex flex-col justify-center p-4 overflow-y-auto">
          <div className="bg-zinc-900 border-2 border-dashed border-hazard-yellow rounded-2xl p-5 space-y-4 max-w-sm mx-auto w-full relative">
            <button 
              onClick={() => setSelectedAuditInvoice(null)} 
              className="absolute top-3 right-3 text-zinc-500 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="text-center space-y-1">
              <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-mono font-bold uppercase tracking-wider">
                ✓ SIDING PASSED & SETTLED
              </span>
              <h4 className="text-sm font-bold text-white uppercase font-display tracking-wide mt-2">
                COAL SIDING GATEPASS SUMMARY
              </h4>
              <p className="text-[9px] text-zinc-500 font-mono">ID: {selectedAuditInvoice.id}</p>
            </div>

            {/* Simulated Receipt Ticket view */}
            <div className="bg-stone-950 p-4 rounded-xl border border-steel-gray space-y-2.5 text-xs text-left font-mono text-zinc-300 relative overflow-hidden">
              <div className="absolute -right-6 top-2 rotate-45 bg-emerald-800 text-emerald-300 text-[6.5px] font-black px-6 py-0.5 uppercase tracking-widest leading-none">
                VERIFIED
              </div>

              <div className="border-b border-zinc-800 pb-2 space-y-1">
                <p className="flex justify-between">
                  <span className="text-zinc-500">Challan/Duty:</span>
                  <span className="text-white font-bold">{selectedAuditInvoice.bookingId}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-zinc-500">Target Siding:</span>
                  <span className="text-white font-bold">{selectedAuditInvoice.sidingId}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-zinc-500">Siding VPA:</span>
                  <span className="text-amber-400 text-[10.5px] truncate max-w-[150px]">{selectedAuditInvoice.vpa}</span>
                </p>
              </div>

              <div className="border-b border-zinc-800 pb-2 space-y-1">
                <p className="flex justify-between">
                  <span className="text-zinc-500">Settle Date:</span>
                  <span className="text-zinc-300">{new Date(selectedAuditInvoice.scannedAt).toLocaleString()}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-zinc-500">Settled Via:</span>
                  <span className="text-zinc-300 uppercase">Camera QR Reader</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-zinc-500">Encryption:</span>
                  <span className="text-zinc-500 text-[10px]">SHA-256 / AES-GCM</span>
                </p>
              </div>

              <div className="pt-1.5 flex justify-between items-center">
                <span className="text-[10px] text-zinc-500 font-bold uppercase">Total Settled:</span>
                <span className="text-base text-emerald-400 font-black">₹{selectedAuditInvoice.amount}</span>
              </div>
            </div>

            <div className="text-center space-y-2">
              <div className="text-[8.5px] text-zinc-550 flex items-center justify-center gap-1">
                <Shield className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                <span>Digitally Sealed & Authorized by Ramgarh-Dhanbad Siding</span>
              </div>
              <button
                onClick={() => setSelectedAuditInvoice(null)}
                className="w-full bg-hazard-yellow hover:bg-yellow-400 text-coal-black font-bold uppercase text-[11px] py-2 rounded-xl cursor-pointer"
              >
                Clear Reference
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Screen Base Bar */}
      <div className="bg-coal-black pb-4 pt-1 px-5 border-t border-steel-gray absolute bottom-0 left-0 right-0">
        <div className="flex justify-center">
          <div className="w-32 h-1 bg-zinc-700 rounded-full mt-1.5"></div>
        </div>
      </div>

    </div>
  );
}

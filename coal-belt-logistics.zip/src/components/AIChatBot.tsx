import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquare, Send, X, Mic, MicOff, RefreshCw, 
  Sparkles, Truck, MapPin, ClipboardCheck, ArrowRight 
} from 'lucide-react';
import { ChatMessage } from '../types';

interface AIChatBotProps {
  onAutoFillBooking: (parsedData: any) => void;
  language: 'en' | 'hi';
}

export default function AIChatBot({ onAutoFillBooking, language }: AIChatBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [inputVal, setInputVal] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "wel-01",
      sender: "ai",
      text: language === 'en' 
        ? "Welcome, Partner! I am your Coal-Belt AI Dispatching Assistant. Ask me about coal rates, routes, toll tax estimations, or say 'Book a Hyva from Dhanbad to Asansol weight 25 tons' to draft an order!"
        : "प्रणाम! मैं आपका कोयला-बेल्ट एआई सहायक हूँ। कोयला भाड़ा, सुरक्षित रूट, टोल टैक्स या 'धनबाद से रामगढ़ के लिए हाईवा बुक करें' कहें।",
      timestamp: new Date().toISOString()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [isVoiceRecording, setIsVoiceRecording] = useState(false);

  // Draft extracted values spotted in conversations
  const [spottedDraftBooking, setSpottedDraftBooking] = useState<any | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = async (customText?: string) => {
    const query = (customText || inputVal).trim();
    if (!query) return;

    if (!customText) setInputVal('');

    // Append customer message
    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: "user",
      text: query,
      timestamp: new Date().toISOString(),
      isVoice: isVoiceRecording
    };

    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);
    setSpottedDraftBooking(null); // Reset draft view

    try {
      const response = await fetch("/api/ai/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: query,
          chatHistory: messages.slice(-5).map(m => ({ sender: m.sender, text: m.text })),
          language
        })
      });

      if (!response.ok) throw new Error("Connection issue");
      const data = await response.json();
      
      const responseText = data.text || "I apologize, the siding servers are busy. Please try again.";

      // Parse custom [BOOK_DATA] drafts if spotted
      let cleanText = responseText;
      let draftedBooking: any = null;

      if (responseText.includes("[BOOK_DATA]")) {
        try {
          const parts = responseText.split("[BOOK_DATA]");
          const subParts = parts[1].split("[/BOOK_DATA]");
          const jsonString = subParts[0].trim();
          draftedBooking = JSON.parse(jsonString);
          
          // clean out visual formatting block
          cleanText = parts[0] + (parts[1].split("[/BOOK_DATA]")[1] || "");
        } catch (err) {
          console.error("Failed to parse extracted AI booking json:", err);
        }
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: "ai",
        text: cleanText.trim(),
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, aiMsg]);
      
      if (draftedBooking) {
        setSpottedDraftBooking(draftedBooking);
      }

    } catch (err) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          sender: "ai",
          text: language === 'en'
            ? "⚠ Siding control network timeout. Proceeding using simulated response maps..."
            : "⚠ साइडिंग नेटवर्क टाइमआउट। सिम्युलेटर मोड सक्रिय...",
          timestamp: new Date().toISOString()
        }
      ]);
    } finally {
      setIsTyping(false);
      setIsVoiceRecording(false);
    }
  };

  // Simulate Hindi / Eng Speech booking commands
  const startSimulatedVoiceBooking = () => {
    if (isVoiceRecording) {
      setIsVoiceRecording(false);
      return;
    }

    setIsVoiceRecording(true);
    
    const voicePhrases = language === 'en'
      ? "Siding dispatch dumper cargo order from Dhanbad washery gate to Ramgarh plant yards payload 18 tons Rungta steel."
      : "धनबाद माइनिंग मुख्यालय से रामगढ़ औद्योगिक क्षेत्र के लिए २५ टन कोयला डम्पर बुक करें चालान ९९८२१०";

    setTimeout(() => {
      setInputVal(voicePhrases);
      setIsVoiceRecording(false);
      handleSendMessage(voicePhrases);
    }, 2500); // 2.5 second animation
  };

  return (
    <div id="ai-chat-drawer-root" className="fixed bottom-6 right-6 z-[100] font-sans">
      
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button
          id="ai-control-widget-toggle"
          onClick={() => setIsOpen(true)}
          className="bg-coal-black border-2 border-hazard-yellow text-white p-3.5 rounded-full shadow-2xl hover:scale-110 transition-all flex items-center gap-2 cursor-pointer group"
        >
          <div className="relative">
            <span className="absolute -top-1 -right-1 bg-hazard-orange w-3 h-3 rounded-full animate-ping"></span>
            <MessageSquare className="w-6 h-6 text-hazard-yellow" />
          </div>
          <span className="text-xs font-bold font-display tracking-widest text-zinc-100 uppercase max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300">
            {language === 'en' ? 'AI DISPATCH' : 'कोयला-AI'}
          </span>
        </button>
      )}

      {/* Floating Chat Panel Box */}
      {isOpen && (
        <div 
          id="ai-panel-chat-box" 
          className="bg-stone-950 border-2 border-steel-gray rounded-2xl shadow-3xl w-80 md:w-96 h-[480px] flex flex-col overflow-hidden border-t-4 border-t-hazard-yellow"
        >
          
          {/* Header */}
          <div className="bg-coal-black p-3 border-b border-steel-gray flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-hazard-yellow animate-pulse" />
              <div>
                <h3 className="text-xs font-bold font-display uppercase tracking-wider text-white">
                  COAL-BELT DISPATCH AI
                </h3>
                <span className="text-[9px] text-zinc-500 font-mono">Gemini 3.5 Engine Secured</span>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="text-zinc-500 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Flow Area */}
          <div className="flex-grow p-3 overflow-y-auto space-y-3 scrollbar">
            {messages.map(msg => (
              <div 
                key={msg.id} 
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div 
                  className={`p-2.5 rounded-xl text-xs max-w-[85%] leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-hazard-yellow text-coal-black font-semibold rounded-tr-none'
                      : 'bg-mine-gray text-zinc-200 border border-steel-gray rounded-tl-none'
                  }`}
                >
                  <p>{msg.text}</p>
                  
                  {msg.isVoice && (
                    <span className="text-[8px] opacity-70 block text-right mt-1 font-mono italic">
                      🎙 Transcribed Speech
                    </span>
                  )}
                </div>
                <span className="text-[8px] text-zinc-500 mt-1 font-mono">
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-1.5 text-zinc-500 text-xs px-2 italic">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-hazard-yellow" />
                <span>AI drafting siding options...</span>
              </div>
            )}

            {/* AI Extracted Spelled Draft Found Card */}
            {spottedDraftBooking && (
              <div className="bg-amber-950/20 border-2 border-hazard-yellow rounded-xl p-3 space-y-2.5 animate-bounce">
                <div className="flex items-center gap-1.5 text-[10px] text-hazard-yellow font-bold uppercase font-display leading-none">
                  <Truck className="w-4 h-4 text-hazard-yellow animate-bounce" />
                  <span>Draft order parsed successfully!</span>
                </div>
                
                <div className="space-y-1 text-[11px] text-zinc-300 font-mono bg-stone-900 border border-steel-gray p-2 rounded">
                  <p className="flex justify-between">
                    <span>Origin:</span> <span className="text-white font-bold">{spottedDraftBooking.pickupCounty || 'Dhanbad'}</span>
                  </p>
                  <p className="flex justify-between">
                    <span>Drop Destination:</span> <span className="text-white font-bold">{spottedDraftBooking.dropCounty || 'Ramgarh'}</span>
                  </p>
                  <p className="flex justify-between">
                    <span>Vehicle Cargo:</span> <span className="text-white font-bold uppercase">{spottedDraftBooking.vehicleType || 'dumper'}</span>
                  </p>
                  <p className="flex justify-between">
                    <span>Declared Weight:</span> <span className="text-white font-bold">{spottedDraftBooking.weightTons || 10} Tons</span>
                  </p>
                </div>

                <button
                  onClick={() => {
                    onAutoFillBooking(spottedDraftBooking);
                    setSpottedDraftBooking(null);
                    setIsOpen(false);
                    alert("✓ Booking details imported! Swapped customer form parameters.");
                  }}
                  className="w-full bg-hazard-yellow hover:bg-yellow-400 text-coal-black text-[11px] font-bold uppercase py-2 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow"
                >
                  <ClipboardCheck className="w-3.5 h-3.5" />
                  <span>Auto-fill Booking Screen</span>
                </button>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Siding Voice Book simulated helper advice */}
          <div className="px-3 py-1.5 bg-stone-900/50 border-t border-zinc-900 text-center text-[9px] font-mono text-zinc-400 flex items-center justify-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-hazard-yellow animate-pulse shrink-0"></span>
            <span>Tip: Try clicking the microphone below for simulated speech!</span>
          </div>

          {/* Interactive Inputs Controller */}
          <div className="bg-coal-black p-2.5 border-t border-steel-gray flex items-center gap-2">
            
            {/* Speech mic toggle */}
            <button
              onClick={startSimulatedVoiceBooking}
              className={`p-2 rounded-xl border cursor-pointer transition-all ${
                isVoiceRecording
                  ? 'bg-red-950 text-red-500 border-red-700 animate-pulse'
                  : 'bg-mine-gray text-zinc-400 border-steel-gray hover:text-white'
              }`}
              title={language === 'en' ? 'Simulate Hindi speech input booking command' : 'हिन्दी वाइस बुक कमांड सिम्युलेट करें'}
            >
              {isVoiceRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-hazard-yellow" />}
            </button>

            <input
              type="text"
              placeholder={language === 'en' ? "Request freight advice..." : "भाड़ा या मार्ग की सलाह लें..."}
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-grow bg-mine-gray border border-steel-gray text-xs rounded-xl p-2.5 outline-none focus:border-zinc-500 text-white font-sans"
            />

            <button
              onClick={() => handleSendMessage()}
              className="bg-hazard-yellow hover:bg-yellow-400 p-2.5 rounded-xl text-coal-black cursor-pointer shadow shadow-amber-500/15"
            >
              <Send className="w-3.5 h-3.5" />
            </button>

          </div>

        </div>
      )}

    </div>
  );
}

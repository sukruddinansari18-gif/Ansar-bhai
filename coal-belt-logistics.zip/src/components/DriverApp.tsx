import React, { useState } from 'react';
import { 
  Truck, ShieldAlert, Check, X, MapPin, Map,
  FileSpreadsheet, ClipboardList, TrendingUp, Key,
  DollarSign, Shield, Info, HelpCircle, HardHat, Compass, AlertCircle,
  LogOut, Smartphone, Lock, RefreshCw, Terminal
} from 'lucide-react';
import { Booking, Driver, FuelLog, VehicleType, AppState } from '../types';
import { VEHICLE_SPECS, FIXED_REASONS } from '../data';

interface DriverAppProps {
  state: AppState;
  isOffline: boolean;
  onOfflineToggle: (driverId: string, online: boolean) => Promise<void>;
  onTriggerAction: (bookingId: string, action: string, extra?: any) => Promise<void>;
  onRegisterDriver: (driverPayload: any) => Promise<void>;
  onFuelEntry: (fuelPayload: any) => Promise<void>;
  language: 'en' | 'hi';
  currentUser?: any;
  onLogout?: () => void;
}

export default function DriverApp({
  state,
  isOffline,
  onOfflineToggle,
  onTriggerAction,
  onRegisterDriver,
  onFuelEntry,
  language,
  currentUser,
  onLogout
}: DriverAppProps) {
  
  // Choose which driver to simulate
  const [selectedDriverId, setSelectedDriverId] = useState<string>(() => {
    return localStorage.getItem('driver_active_id') || 'drv_01';
  });
  const [activeDriverTab, setActiveDriverTab] = useState<'runs' | 'stats' | 'fuel' | 'register'>('runs');

  // Driver Login Session States
  const [isDriverLoggedIn, setIsDriverLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('driver_logged_in') === 'true';
  });
  const [loginPhoneInput, setLoginPhoneInput] = useState('98734XXXXX');
  const [driverOtpInput, setDriverOtpInput] = useState('');
  const [driverOtpSimulated, setDriverOtpSimulated] = useState<string | null>(null);
  const [driverLoginStep, setDriverLoginStep] = useState<'phone' | 'otp'>('phone');
  const [driverLoginError, setDriverLoginError] = useState('');

  // Synchronize with currentUser prop from B2B security system
  React.useEffect(() => {
    if (currentUser) {
      setIsDriverLoggedIn(true);
      // Map security DB driver name or phone
      const matched = state.drivers.find(d => 
        d.name === currentUser.driverName || 
        d.phone.replace(/\D/g, '').endsWith(currentUser.mobile.replace(/\D/g, '').slice(-5))
      );
      if (matched) {
        setSelectedDriverId(matched.id);
        localStorage.setItem('driver_active_id', matched.id);
      }
    }
  }, [currentUser, state.drivers]);

  // Fuel form state
  const [fuelLiters, setFuelLiters] = useState<number>(45);
  const [fuelCost, setFuelCost] = useState<number>(state.config.baseDieselPrice);
  const [odometer, setOdometer] = useState<number>(55410);

  // Registration states
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regVehicleType, setRegVehicleType] = useState<VehicleType>('mini_truck');
  const [regVehicleNum, setRegVehicleNum] = useState('');
  const [regAadhaar, setRegAadhaar] = useState('');
  const [regDL, setRegDL] = useState('');
  const [regRC, setRegRC] = useState('');

  const currentDriver = state.drivers.find(d => d.id === selectedDriverId) || state.drivers[0];

  const handleDriverRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginPhoneInput || loginPhoneInput.length < 4) {
      setDriverLoginError(language === 'en' ? 'Please select or enter active crew phone number' : 'कृपया सक्रिय चालक नंबर दर्ज करें');
      return;
    }
    
    setDriverLoginError('');
    // Look for matching driver
    const matched = state.drivers.find(d => 
      d.phone === loginPhoneInput || 
      d.id === loginPhoneInput ||
      d.phone.replace(/X/g, '') === loginPhoneInput.replace(/X/g, '')
    );
    
    const randomCode = Math.floor(1000 + Math.random() * 9000).toString();
    setDriverOtpSimulated(randomCode);
    setDriverLoginStep('otp');
  };

  const handleDriverVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (driverOtpInput === driverOtpSimulated || driverOtpInput === '1234') {
      // Find driver info to bind
      const matched = state.drivers.find(d => 
        d.phone === loginPhoneInput || 
        d.id === loginPhoneInput ||
        d.phone.replace(/X/g, '') === loginPhoneInput.replace(/X/g, '')
      ) || state.drivers[0];

      localStorage.setItem('driver_logged_in', 'true');
      localStorage.setItem('driver_active_id', matched?.id || 'drv_01');
      
      setSelectedDriverId(matched?.id || 'drv_01');
      setIsDriverLoggedIn(true);
      setDriverLoginError('');
      setDriverOtpInput('');
      setDriverOtpSimulated(null);
    } else {
      setDriverLoginError(language === 'en' ? 'Incorrect OTP. Try 1234 test code.' : 'गलत ओटीपी। टेस्ट कोड 1234 आज़माएं।');
    }
  };

  const handleDriverLogout = () => {
    localStorage.removeItem('driver_logged_in');
    localStorage.removeItem('driver_active_id');
    setIsDriverLoggedIn(false);
    setDriverLoginStep('phone');
    if (onLogout) {
      onLogout();
    }
  };

  // Incoming bookings intended for this driver or pending bookings with same vehicle type
  const pendingRequests = state.bookings.filter(b => 
    b.status === 'pending' && 
    b.vehicleType === currentDriver?.vehicleType && 
    currentDriver?.online && 
    !currentDriver?.active &&
    currentDriver?.docsApproved
  );

  // Other open pending bookings from different vehicle types or online states for sandbox testing
  const otherPendingRequests = state.bookings.filter(b => 
    b.status === 'pending' && 
    (b.vehicleType !== currentDriver?.vehicleType || !currentDriver?.online)
  );

  // Active bookings currently driving
  const activeTrips = state.bookings.filter(b => 
    b.driverId === currentDriver?.id && 
    b.status !== 'completed' && 
    b.status !== 'cancelled'
  );

  // History for this driver
  const tripHistory = state.bookings.filter(b => 
    b.driverId === currentDriver?.id && 
    (b.status === 'completed' || b.status === 'cancelled')
  );

  const fuelLogsForDriver = state.fuelLogs.filter(f => f.driverId === currentDriver?.id);

  // Handle Driver Onboarding Registration
  const handleOnboarding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regPhone || !regVehicleNum) {
      alert("Missing required fields!");
      return;
    }

    const payload = {
      name: regName,
      phone: regPhone,
      vehicleType: regVehicleType,
      vehicleNumber: regVehicleNum,
      aadhaarNum: regAadhaar || "3389-9941-2093",
      licenseNum: regDL || "DL-JH10-22189",
      rcNum: regRC || "RC-JH-01-38491",
    };

    try {
      await onRegisterDriver(payload);
      alert(language === 'en' 
        ? "✓ Verification documents submitted to regional RTO Admin portal! Onboarding is pending admin validation." 
        : "✓ आपके दस्तावेज क्षेत्रीय पोर्टल पर भेजे गए हैं! प्रशासक की स्वीकृति के बाद आप ट्रिप्स स्वीकार कर सकते हैं।"
      );
      // Reset
      setRegName('');
      setRegPhone('');
      setRegVehicleNum('');
      setActiveDriverTab('runs');
      // Set to newly created driver once available
      const lastDrv = state.drivers[state.drivers.length - 1];
      if (lastDrv) setSelectedDriverId(lastDrv.id);
    } catch (err) {
      console.error(err);
    }
  };

  // Submit fuel entries
  const handleFuelSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      driverId: currentDriver?.id,
      liters: fuelLiters,
      costPerLiter: fuelCost,
      mileageOdometer: odometer
    };

    try {
      await onFuelEntry(payload);
      alert(language === 'en' ? "✓ Fuel cost details registered successfully!" : "✓ डीज़ल एंट्री दर्ज कर ली गई है!");
      setActiveDriverTab('stats');
    } catch (err) {
       console.error(err);
    }
  };

  // Switch availability
  const handleToggleOnline = async () => {
    if (!currentDriver?.docsApproved) {
      alert(language === 'en' 
        ? "❌ Access Denied: Your driver identity documents are pending verification. Admin must authorize your credentials before proceeding." 
        : "❌ पहुंच अस्वीकृत: आपके चालक दस्तावेज अभी क्षेत्रीय आरटीओ द्वारा स्वीकृत नहीं हैं।"
      );
      return;
    }
    await onOfflineToggle(currentDriver.id, !currentDriver.online);
  };

  // Emergency SOS Broadcast
  const handleSOSDanger = () => {
    alert(language === 'en'
      ? "🔴 SOS EMERGENCY BROADCAST: Coal Siding command center and road assistance alerts triggered! Direct coordination SMS sent with GPS Coordinates."
      : "🔴 आपातकालीन संदेश (SOS) प्रसारित किया गया! माइन कंट्रोल रूम और सड़क सुरक्षा दस्ते को आपकी जीपीएस स्थिति भेज दी गई है।"
    );
  };

  return (
    <div id="driver-app-simulation-id" className="max-w-md mx-auto bg-stone-950 border-4 border-zinc-800 rounded-[3rem] shadow-2xl relative overflow-hidden flex flex-col my-4 min-h-[750px] text-white">
      
      {/* Speaker and Camera notch */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-5 bg-zinc-800 rounded-b-xl z-50 flex items-center justify-center">
        <span className="w-2 h-2 rounded-full bg-zinc-950 block"></span>
        <span className="w-10 h-1 bg-zinc-900 rounded-full block mx-2"></span>
      </div>

      {/* Screen Header */}
      <div className="bg-coal-black pt-8 pb-3 px-5 border-b border-steel-gray flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Truck className="w-4 h-4 text-hazard-yellow animate-pulse" />
          <span className="text-[10px] uppercase font-black tracking-widest font-mono text-white">
            SIDING CREW TERMINAL
          </span>
        </div>
        
        {isDriverLoggedIn ? (
          <div className="flex items-center gap-1.5">
            <span className="text-[9px] bg-zinc-800 text-zinc-300 font-bold px-1.5 py-0.5 rounded font-mono">
              {VEHICLE_SPECS[currentDriver?.vehicleType]?.nameEn.split(' ')[0]}
            </span>
            <button
              onClick={handleDriverLogout}
              className="text-red-400 hover:text-red-300 bg-red-950/40 p-1 rounded border border-red-900/30 font-bold text-[8px] flex items-center gap-1 uppercase tracking-wider font-mono cursor-pointer"
            >
              <LogOut className="w-3 h-3 text-red-400" />
              <span>OUT</span>
            </button>
          </div>
        ) : (
          <span className="text-[9px] font-mono text-zinc-500 uppercase">OFFLINE GATEWAY</span>
        )}
      </div>

      {/* SECURE SEAMLESS OTP VERIFICATION ENVELEOP */}
      {!isDriverLoggedIn ? (
        <div className="flex-1 overflow-y-auto p-5 flex flex-col justify-between space-y-6">
          
          <div className="space-y-4">
            {/* Aesthetic branding of Coal Siding */}
            <div className="text-center space-y-2 py-2">
              <div className="w-12 h-12 bg-amber-500/10 border-2 border-hazard-yellow/50 rounded-2xl flex items-center justify-center text-hazard-yellow mx-auto">
                <Terminal className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h2 className="text-sm font-black font-display uppercase tracking-widest text-white">
                  {language === 'en' ? 'SIDING GATE CLEARANCE' : 'गैंगवे / साइडिंग लॉगिन'}
                </h2>
                <p className="text-[10px] text-zinc-400 tracking-wide">
                  {language === 'en' 
                    ? 'Enter 10-digit driver mobile to acquire digital coal siding permit' 
                    : 'कोयला खदान डिजिटल लोडिंग पास हेतु अपना मोबाइल दर्ज करें'}
                </p>
              </div>
            </div>

            {driverLoginError && (
              <div className="bg-red-950/80 border border-red-900 text-red-300 font-semibold p-2.5 rounded-xl text-center text-[10px] font-mono">
                {driverLoginError}
              </div>
            )}

            {driverLoginStep === 'phone' ? (
              <form onSubmit={handleDriverRequestOtp} className="space-y-3">
                <div>
                  <label className="text-[9px] text-zinc-500 uppercase font-mono block mb-1">
                    {language === 'en' ? 'REGISTERED DRIVER PHONE' : 'वाहन चालक मोबाइल नंबर'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-zinc-500 font-mono text-xs">+91</span>
                    <input
                      type="text"
                      maxLength={15}
                      required
                      placeholder="e.g. 98734XXXXX"
                      value={loginPhoneInput}
                      onChange={(e) => setLoginPhoneInput(e.target.value)}
                      className="w-full bg-stone-900 border border-steel-gray rounded-xl p-2.5 pl-12 text-xs focus:border-hazard-yellow outline-none text-white font-mono font-bold"
                    />
                  </div>
                </div>

                {/* Sessional crew helpful simulator bypass */}
                <div className="bg-zinc-950 p-3 rounded-xl border border-zinc-800 space-y-2">
                  <span className="text-[8px] text-zinc-500 uppercase font-mono block tracking-wider">
                    👉 FAST SIMULATION ON-BOARD CREW:
                  </span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {state.drivers.map((d) => (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => setLoginPhoneInput(d.phone)}
                        className={`p-1.5 rounded text-[9px] text-left border flex items-center gap-1 transition-colors ${
                          loginPhoneInput === d.phone 
                            ? 'bg-amber-500/10 text-hazard-yellow border-hazard-yellow font-bold' 
                            : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                        }`}
                      >
                        <HardHat className="w-3 h-3 text-zinc-500 shrink-0" />
                        <span className="truncate">{d.name.split(' ')[0]} ({d.vehicleNumber.slice(-4)})</span>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 font-display font-bold uppercase text-[11px] py-3 rounded-xl transition-all tracking-wider flex items-center justify-center gap-1.5 shadow-lg shadow-yellow-500/10 cursor-pointer"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>{language === 'en' ? 'REQUEST GATEPASS SMS OTP' : 'वेरिफिकेशन ओटीपी प्राप्त करें'}</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleDriverVerifyOtp} className="space-y-3">
                {/* Visual SIMULATED SMS Notification box */}
                <div className="bg-amber-500/10 border border-hazard-yellow/40 p-3 rounded-xl space-y-1 text-center animate-pulse">
                  <p className="text-[10px] text-amber-500 font-black font-mono">
                    💬 {language === 'en' ? '💬 SIMULATED ENROUTE SYSTEM SMS' : '💬 सिम्युलेटर एसएमएस गेटवे'}
                  </p>
                  <p className="text-[11px] text-zinc-300 font-sans leading-tight">
                    {language === 'en' 
                      ? `Coal Siding dispatch login key for driver is:`
                      : `ड्राइवर लॉगिन हेतु सुरक्षा पासकोड है:`}{' '}
                    <span className="font-mono text-white text-xs bg-black px-1.5 rounded font-black border border-amber-500/30">
                      {driverOtpSimulated}
                    </span>
                  </p>
                </div>

                <div>
                  <label className="text-[9px] text-zinc-500 uppercase font-mono block mb-1">
                    {language === 'en' ? 'ENTER 4-DIGIT PASS KEY' : '४-अंकों का ओटीपी कोड डालें'}
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    placeholder="e.g. 1234 or SMS code"
                    value={driverOtpInput}
                    onChange={(e) => setDriverOtpInput(e.target.value)}
                    className="w-full bg-stone-900 border border-steel-gray rounded-xl p-2.5 text-center text-sm focus:border-hazard-yellow outline-none text-white font-mono tracking-widest font-black"
                  />
                  <span className="text-[8px] text-zinc-500 text-center block mt-1">
                    {language === 'en' ? 'Demo mode key acts bypass: "1234"' : 'डेमो बाईपास पासवर्ड है: "1234"'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDriverLoginStep('phone')}
                    className="bg-zinc-800 text-zinc-400 font-bold uppercase text-[10px] py-2.5 rounded-xl text-center cursor-pointer"
                  >
                    {language === 'en' ? 'BACK' : 'पीछे'}
                  </button>
                  <button
                    type="submit"
                    className="bg-emerald-500 text-coal-black hover:bg-emerald-400 font-display font-bold uppercase text-[10px] py-2.5 rounded-xl text-center cursor-pointer"
                  >
                    {language === 'en' ? 'VERIFY SECURITY PIN' : 'पासकोड सत्यापित करें'}
                  </button>
                </div>
              </form>
            )}

          </div>

          {/* Secure disclaimer brand footer */}
          <div className="bg-stone-900/60 p-3 rounded-2xl border border-zinc-850 text-[10px] text-zinc-500 space-y-1">
            <div className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-zinc-600 shrink-0" />
              <span className="font-black text-zinc-400 font-mono uppercase tracking-wider">
                {language === 'en' ? 'RTO & DGMS COMPLIANT ROADWAYS' : 'आर.टी.ओ. एवं कोयला सुरक्षा बोर्ड'}
              </span>
            </div>
            <p className="text-[9px] leading-tight text-zinc-400/80">
              Only authorized heavy vehicles with valid weight bridge chalans may generate digital sidings credentials. In case of verification failure, report to Dhanbad Area 1 Office.
            </p>
          </div>

        </div>
      ) : (
        <>
          {/* Hero Drivers summary status */}
          <div className="bg-gradient-to-r from-mine-gray to-stone-950 p-4 border-b border-steel-gray">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <h2 className="text-sm font-bold font-display uppercase tracking-wide flex items-center gap-1">
                  <span>{currentDriver?.name}</span>
                  <span className="text-[10px] text-zinc-400 font-mono font-normal">({currentDriver?.id})</span>
                </h2>
                <p className="text-[10px] text-zinc-400 font-mono">
                  Vehicle No: <span className="text-zinc-200">{currentDriver?.vehicleNumber}</span>
                </p>
              </div>

              <div className="flex flex-col items-end gap-1">
                <button
                  onClick={handleToggleOnline}
                  className={`px-3 py-1 text-[10px] font-bold font-mono rounded-full flex items-center gap-1 cursor-pointer border ${
                    currentDriver?.online 
                      ? 'bg-emerald-950/80 text-emerald-400 border-emerald-600'
                      : 'bg-zinc-800 text-zinc-400 border-zinc-700'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${currentDriver?.online ? 'bg-emerald-400 animate-ping' : 'bg-zinc-600'}`}></span>
                  <span>{currentDriver?.online ? 'ONLINE' : 'OFFLINE'}</span>
                </button>
                <span className="text-[9px] text-emerald-400 bg-emerald-950/40 px-1.5 rounded border border-emerald-900 font-bold">
                  ★ {currentDriver?.rating} Rating
                </span>
              </div>
            </div>

            {/* Verification Alert Badge */}
            {!currentDriver?.docsApproved && (
              <div className="bg-red-950/80 border border-red-900 px-3 py-2.5 rounded-xl mt-3 text-[10px] text-red-300 flex flex-col gap-2">
                <div className="flex items-start gap-1.5">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">UNVERIFIED CREW PROMETHEUS</span>
                    <p className="text-[9px] text-zinc-400 leading-tight">
                      Region RTO documents pending admin approval. You cannot receive active bookings requests until accepted.
                    </p>
                  </div>
                </div>
                <button
                  onClick={async () => {
                    try {
                      const res = await fetch('/api/drivers/approve', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ driverId: currentDriver.id, approve: true })
                      });
                      if (res.ok) {
                        alert("✓ Documents approved successfully! Ready to accept B2B loads.");
                      }
                    } catch (err) {
                      console.error("Failed to approve driver", err);
                    }
                  }}
                  className="bg-amber-500 hover:bg-amber-400 text-coal-black font-bold uppercase text-[9px] py-1 px-2.5 rounded-md self-start font-mono transition-all cursor-pointer"
                >
                  ⚡ Instant Document Verification (Demo Mode)
                </button>
              </div>
            )}
          </div>

      {/* Operational Screen Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-20">
        
        {/* Inner sub-tabs NAVIGATION */}
        <div className="grid grid-cols-4 bg-mine-gray rounded-xl p-0.5 border border-steel-gray">
          <button
            onClick={() => setActiveDriverTab('runs')}
            className={`py-1 rounded text-[10px] font-bold tracking-wider transition-all cursor-pointer ${
              activeDriverTab === 'runs' ? 'bg-hazard-yellow text-stone-950' : 'text-zinc-400'
            }`}
          >
            TRIPS
          </button>
          <button
            onClick={() => setActiveDriverTab('stats')}
            className={`py-1 rounded text-[10px] font-bold tracking-wider transition-all cursor-pointer ${
              activeDriverTab === 'stats' ? 'bg-hazard-yellow text-stone-950' : 'text-zinc-400'
            }`}
          >
            EARNINGS
          </button>
          <button
            onClick={() => setActiveDriverTab('fuel')}
            className={`py-1 rounded text-[10px] font-bold tracking-wider transition-all cursor-pointer ${
              activeDriverTab === 'fuel' ? 'bg-hazard-yellow text-stone-950' : 'text-zinc-400'
            }`}
          >
            DIESEL LOG
          </button>
          <button
            onClick={() => setActiveDriverTab('register')}
            className={`py-1 rounded text-[10px] font-bold tracking-wider transition-all cursor-pointer ${
              activeDriverTab === 'register' ? 'bg-hazard-orange text-white' : 'text-zinc-400'
            }`}
          >
            JOIN FLEET
          </button>
        </div>

        {/* ---------------- CONTAINER SUB-TAB 1: DRIVER RUNS ---------------- */}
        {activeDriverTab === 'runs' && (
          <div className="space-y-4">
            
            {/* PENDING INSTANT REQUEST ORDERS */}
            {pendingRequests.length > 0 ? (
              <div className="space-y-3 bg-amber-950/20 border-2 border-dashed border-hazard-yellow p-3.5 rounded-2xl">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-hazard-yellow font-display uppercase tracking-wider flex items-center gap-1 flex-row">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                    Incoming Dispatch Load Request
                  </span>
                  <span className="text-[9px] bg-red-950 text-red-300 font-mono px-1 rounded">
                    URGENT SIDING
                  </span>
                </div>

                {pendingRequests.map(req => (
                  <div key={req.id} className="bg-stone-900 border border-steel-gray rounded-xl p-3 space-y-2.5">
                    <div className="flex items-center justify-between text-xs text-zinc-400 font-mono">
                      <span>Order: <span className="text-white font-bold">{req.id}</span></span>
                      <span className="text-emerald-400 font-bold">₹{req.costEstimate}</span>
                    </div>

                    <div className="text-xs space-y-1 text-left">
                      <p className="truncate"><span className="text-zinc-500">Pick:</span> <span className="text-zinc-200">{req.pickupName}</span></p>
                      <p className="truncate"><span className="text-zinc-500">Drop:</span> <span className="text-zinc-200">{req.dropName}</span></p>
                      <p className="text-[10px] text-amber-400 font-bold">Load weight: {req.weightTons} Tons of mined cargo</p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        onClick={async () => {
                          await onTriggerAction(req.id, 'accept', { driverId: currentDriver.id });
                        }}
                        className="bg-emerald-500 text-coal-black font-bold uppercase text-[11px] py-2 rounded-lg cursor-pointer flex items-center justify-center gap-1 hover:bg-emerald-400"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Accept Load
                      </button>
                      <button
                        onClick={() => {
                          // Reject option removes request local view
                          alert("Bid rejected. Recalibrating route dispatch patterns.");
                        }}
                        className="bg-stone-950 hover:bg-zinc-900 text-zinc-400 text-[11px] py-2 rounded-lg font-bold border border-steel-gray uppercase cursor-pointer"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              otherPendingRequests.length > 0 && (
                <div className="space-y-3 bg-zinc-950 p-4 rounded-2xl border border-zinc-800 text-left">
                  <div className="flex items-center justify-between border-b border-zinc-850 pb-2">
                    <span className="text-xs font-black font-mono text-zinc-300 uppercase tracking-wider flex items-center gap-1">
                      <Terminal className="w-3.5 h-3.5 text-zinc-500" />
                      Dispatch Pool ({otherPendingRequests.length})
                    </span>
                    <span className="text-[9px] bg-amber-500/10 text-amber-500 border border-amber-500/20 px-1.5 py-0.5 rounded font-mono font-bold animate-pulse">
                      OPEN LOAD
                    </span>
                  </div>
                  <p className="text-[10.5px] leading-relaxed text-zinc-400">
                    {language === 'en' 
                      ? 'Below are active pending load requests on Coal-Belt sidings. Click Accept to assign & secure duty:' 
                      : 'सक्रिय लोडिंग आर्डर उपलब्ध हैं। आर्डर सिलेक्ट करें और लोडिंग यात्रा शुरू करें:'}
                  </p>

                  <div className="space-y-2">
                    {otherPendingRequests.map(req => (
                      <div key={req.id} className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 space-y-2">
                        <div className="flex items-center justify-between text-[11px] font-mono">
                          <span className="font-bold text-white">Challan: {req.id}</span>
                          <span className="text-zinc-400 capitalize bg-zinc-800 border border-zinc-700 px-1.5 py-0.5 rounded text-[9px]">
                            {VEHICLE_SPECS[req.vehicleType]?.nameEn.split(' ')[0] || req.vehicleType}
                          </span>
                        </div>
                        <div className="text-[10px] text-zinc-400 space-y-0.5 font-mono">
                          <p className="truncate"><span className="text-zinc-500">Pick:</span> {req.pickupName}</p>
                          <p className="truncate"><span className="text-zinc-500">Drop:</span> {req.dropName}</p>
                          <p className="text-emerald-400 font-bold">Estimated Cost: ₹{req.costEstimate}</p>
                        </div>
                        <button
                          onClick={async () => {
                            // Ensure driver online and approve documents
                            try {
                              if (!currentDriver.online) {
                                await fetch('/api/drivers/offline-toggle', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ driverId: currentDriver.id, online: true })
                                });
                              }
                              if (!currentDriver.docsApproved) {
                                await fetch('/api/drivers/approve', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ driverId: currentDriver.id, approve: true })
                                });
                              }
                              await onTriggerAction(req.id, "accept", { driverId: currentDriver.id });
                            } catch (e) {
                              console.error(e);
                            }
                          }}
                          className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 font-bold uppercase text-[10px] py-2 rounded-lg text-center cursor-pointer transition-all flex items-center justify-center gap-1.5"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>{language === 'en' ? 'Assign & Accept Load' : 'लोड स्वीकार करें'}</span>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )
            )}

            {/* ACTIVE DELIVERIES TRANSIT CONTROLLER */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-zinc-400">
                ACTIVE SIDING DUTIES
              </h3>

              {activeTrips.length === 0 ? (
                <div className="text-center py-10 bg-mine-gray rounded-2xl border border-steel-gray text-zinc-500 text-xs">
                  No accepted shipments active. Set duty status to online and wait for closest mining orders to dispatch.
                </div>
              ) : (
                activeTrips.map(trip => (
                  <div key={trip.id} className="bg-mine-gray border border-hazard-yellow/50 p-4 rounded-2xl space-y-3.5">
                    
                    <div className="flex items-center justify-between border-b border-steel-gray pb-2">
                      <div>
                        <span className="text-[10px] font-mono text-zinc-500">SHIPMENT UNIT</span>
                        <p className="text-xs font-black text-white font-mono">{trip.id}</p>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-zinc-400 uppercase font-mono block">Current state</span>
                        <span className="text-xs font-bold font-mono text-hazard-yellow uppercase animate-pulse">
                          {trip.status}
                        </span>
                      </div>
                    </div>

                    {/* Routing step guide */}
                    <div className="space-y-2 text-xs">
                      <div className="bg-stone-950 p-2.5 rounded-lg border border-zinc-850">
                        <p className="font-semibold text-zinc-300">Coal-Belt Routing Pathway:</p>
                        <ul className="list-disc list-inside mt-1 space-y-0.5 text-zinc-400 text-[11px] font-mono">
                          <li>Origin: {trip.pickupName}</li>
                          <li>Deliver to: {trip.dropName}</li>
                          <li>Distance: {trip.distanceKm} km transit range</li>
                        </ul>
                      </div>

                      {/* Overload safety disclaimer */}
                      {trip.isOverloaded && (
                        <div className="bg-amber-950/20 border border-amber-900 p-2 rounded text-[10px] text-amber-300 font-semibold">
                          ⚠️ CHALLAN WATCH: Overload weights detected. Keep official transport pass documentation ready at regional checkposts.
                        </div>
                      )}
                    </div>

                    {/* Highly tactile big button state changes */}
                    <div className="space-y-2 pt-1">
                      
                      {trip.status === 'accepted' && (
                        <button
                          onClick={async () => await onTriggerAction(trip.id, 'loading')}
                          className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 font-bold uppercase text-xs py-3.5 rounded-xl cursor-pointer text-center tracking-wider block"
                        >
                          🏗️ Start Loading Coal Cargo
                        </button>
                      )}

                      {trip.status === 'loading' && (
                        <button
                          onClick={async () => await onTriggerAction(trip.id, 'en_route')}
                          className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 font-bold uppercase text-xs py-3.5 rounded-xl cursor-pointer text-center tracking-wider block"
                        >
                          🚚 Dispatch En Route
                        </button>
                      )}

                      {trip.status === 'en_route' && (
                        <button
                          onClick={async () => await onTriggerAction(trip.id, 'unloading')}
                          className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 font-bold uppercase text-xs py-3.5 rounded-xl cursor-pointer text-center tracking-wider block"
                        >
                          🏗️ Start Unloading at Yard
                        </button>
                      )}

                      {trip.status === 'unloading' && (
                        <button
                          onClick={async () => await onTriggerAction(trip.id, 'completed')}
                          className="w-full bg-emerald-500 text-coal-black hover:bg-emerald-400 font-bold uppercase text-xs py-3.5 rounded-xl cursor-pointer text-center tracking-wider block"
                        >
                          ✓ Confirm Shipment Handover
                        </button>
                      )}

                      {/* Cancel transit button */}
                      <button
                        onClick={async () => {
                          if (confirm("Cancel transport order? Code safety protocol notifies shippers.")) {
                            await onTriggerAction(trip.id, 'cancel');
                          }
                        }}
                        className="w-full bg-zinc-950 border border-steel-gray text-zinc-500 hover:text-white py-1.5 rounded-lg text-[10px] font-bold uppercase text-center cursor-pointer font-mono"
                      >
                        Report Siding Incident / Cancel Trip
                      </button>
                    </div>

                  </div>
                ))
              )}

            </div>

            {/* BIG SOS EMERGENCY RED DIRECT TRIGGER */}
            <div className="bg-red-950/40 border border-red-800 p-4 rounded-2xl space-y-2 text-center">
              <h4 className="text-xs font-bold text-red-400 font-display uppercase tracking-widest leading-none">
                Coal Siding Safety System
              </h4>
              <p className="text-[10px] text-zinc-400 leading-tight">
                Accident, robbery, mine cavity fire, or brake failure on hill roads? Press immediately to coordinate.
              </p>
              <button
                id="sos-button"
                onClick={handleSOSDanger}
                className="w-full bg-hazard-orange text-white py-3.5 rounded-xl font-bold font-display uppercase text-xs hover:bg-orange-600 transition-all cursor-pointer shadow-lg shadow-orange-500/10"
              >
                🚨 TRIGGER EMERGENCY SOS 🚨
              </button>
            </div>

          </div>
        )}

        {/* ---------------- CONTAINER SUB-TAB 2: DRIVER EARNINGS STATS ---------------- */}
        {activeDriverTab === 'stats' && (
          <div className="space-y-4">
            
            {/* Siding Earnings Dashboard Header */}
            <div className="bg-mine-gray p-3.5 rounded-2xl border border-steel-gray space-y-2 text-center">
              <p className="text-[10px] text-zinc-400 uppercase tracking-widest font-mono">Today's Fleet Payouts</p>
              <p className="text-3xl font-mono font-black text-emerald-400">
                ₹{currentDriver?.earningsToday}
              </p>
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-steel-gray text-xs text-zinc-400 font-mono">
                <div>
                  <p className="text-[9px] text-zinc-500">Weekly Total</p>
                  <p className="text-white font-bold">₹{currentDriver?.earningsThisWeek}</p>
                </div>
                <div>
                  <p className="text-[9px] text-zinc-500">Completed Runs</p>
                  <p className="text-white font-bold">{currentDriver?.totalTrips} Trips</p>
                </div>
              </div>
            </div>

            {/* Financial History Logs */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold font-display uppercase tracking-widest text-zinc-400">
                Siting Payout Register
              </h3>

              {tripHistory.length === 0 ? (
                <p className="text-[10px] text-zinc-500 italic">No completed runs recorded in this simulator epoch.</p>
              ) : (
                tripHistory.map(b => (
                  <div key={b.id} className="bg-stone-900 p-2.5 rounded-lg border border-steel-gray flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-zinc-300">Run ID: {b.id}</p>
                      <p className="text-[9px] text-zinc-500">{new Date(b.timestamp).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono text-emerald-400 font-bold">
                        +₹{Math.round(b.costEstimate * (1 - state.config.commissionPercent / 100))}
                      </p>
                      <span className="text-[8px] bg-zinc-800 text-zinc-400 px-1 rounded">Net after comm.</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Diesel logs for fleet efficiency */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold font-display uppercase tracking-widest text-zinc-400">
                My Diesel Fuel Slips
              </h3>

              {fuelLogsForDriver.length === 0 ? (
                <p className="text-[10px] text-zinc-500 italic">No recorded diesel slips listed. Register your tank slips under the Fuel tab.</p>
              ) : (
                fuelLogsForDriver.map(f => (
                  <div key={f.id} className="bg-stone-900 p-2.5 rounded-lg border border-steel-gray flex items-center justify-between text-[11px] font-mono">
                    <div>
                      <p className="text-zinc-300 font-semibold">{f.liters}L @ ₹{f.costPerLiter}/L</p>
                      <p className="text-[9px] text-zinc-500">Odo: {f.mileageOdometer} km</p>
                    </div>
                    <span className="font-bold text-orange-400">-₹{f.totalCost}</span>
                  </div>
                ))
              )}
            </div>

          </div>
        )}

        {/* ---------------- CONTAINER SUB-TAB 3: DIESEL SLIPS LOG ---------------- */}
        {activeDriverTab === 'fuel' && (
          <form onSubmit={handleFuelSubmit} className="bg-mine-gray p-4 rounded-2xl border border-steel-gray space-y-4">
            <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow flex items-center gap-1.5">
              <ClipboardList className="w-4 h-4 text-hazard-yellow" />
              <span>Log Coals Siding Diesel Slips (पर्ची)</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="text-[9px] text-zinc-400 uppercase font-mono block">Diesel Liters Fueled</label>
                <input
                  type="number"
                  required
                  min="5"
                  max="400"
                  value={fuelLiters}
                  onChange={(e) => setFuelLiters(Number(e.target.value))}
                  className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-2 focus:border-zinc-500 outline-none text-white font-mono"
                />
              </div>

              <div>
                <label className="text-[9px] text-zinc-400 uppercase font-mono block">Price per Liter (INR)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={fuelCost}
                  onChange={(e) => setFuelCost(Number(e.target.value))}
                  className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-2 focus:border-zinc-500 outline-none text-white font-mono"
                />
              </div>

              <div>
                <label className="text-[9px] text-zinc-400 uppercase font-mono block">Odometer Reading (KM)</label>
                <input
                  type="number"
                  required
                  value={odometer}
                  onChange={(e) => setOdometer(Number(e.target.value))}
                  className="w-full bg-stone-950 border border-steel-gray text-xs rounded p-2 focus:border-zinc-500 outline-none text-white font-mono"
                />
              </div>

              {/* Live Slip total calculator */}
              <div className="bg-stone-950 p-2.5 rounded-lg border border-steel-gray flex items-center justify-between text-xs">
                <span className="text-zinc-500 uppercase font-mono">Consolidated cost:</span>
                <span className="text-orange-400 font-mono font-bold text-sm">
                  ₹{Math.round(fuelLiters * fuelCost * 100) / 100}
                </span>
              </div>

              <button
                type="submit"
                className="w-full bg-hazard-yellow text-coal-black hover:bg-yellow-400 font-bold uppercase text-xs py-3 rounded-lg cursor-pointer transition-all"
              >
                Log Slip & Update Mileage
              </button>
            </div>
          </form>
        )}

        {/* ---------------- CONTAINER SUB-TAB 4: DRIVER ONBOARDING ---------------- */}
        {activeDriverTab === 'register' && (
          <form onSubmit={handleOnboarding} className="bg-mine-gray p-4 rounded-2xl border border-steel-gray space-y-3.5">
            <div>
              <h3 className="text-xs font-bold font-display uppercase tracking-wider text-hazard-yellow leading-none">
                Truck Driver Onboarding Form (पंजीकरण)
              </h3>
              <p className="text-[9px] text-zinc-400 mt-1">Submit Aadhaar and RC details to be verified by security dispatch RTO.</p>
            </div>

            <div className="space-y-2.5 text-xs">
              <div>
                <label className="text-[9px] text-zinc-400 uppercase block">FullName</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Satnam Singh"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  className="w-full bg-stone-950 border border-steel-gray rounded p-2 focus:border-zinc-500 outline-none text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-zinc-400 uppercase block">Phone</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., 9924XXXXXX"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full bg-stone-950 border border-steel-gray rounded p-2 focus:border-zinc-500 outline-none text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-zinc-400 uppercase block">Vehicle Class</label>
                  <select
                    value={regVehicleType}
                    onChange={(e) => setRegVehicleType(e.target.value as VehicleType)}
                    className="w-full bg-stone-950 border border-steel-gray rounded p-2 focus:border-zinc-500 outline-none text-white"
                  >
                    {Object.values(VEHICLE_SPECS).map(v => (
                      <option key={v.id} value={v.id}>{v.nameEn}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[9px] text-zinc-400 uppercase block font-mono">Truck / Vehicle RC Number</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., JH-10-A-9942"
                  value={regVehicleNum}
                  onChange={(e) => setRegVehicleNum(e.target.value)}
                  className="w-full bg-stone-950 border border-steel-gray rounded p-2 focus:border-zinc-500 outline-none text-white font-mono uppercase"
                />
              </div>

              <div>
                <label className="text-[9px] text-zinc-400 uppercase block font-mono">Aadhaar National ID Card</label>
                <input
                  type="text"
                  placeholder="e.g., 2948-1102-3921"
                  value={regAadhaar}
                  onChange={(e) => setRegAadhaar(e.target.value)}
                  className="w-full bg-stone-950 border border-steel-gray rounded p-2 focus:border-zinc-500 outline-none text-white font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-zinc-400 uppercase block font-mono">Driving License (DL)</label>
                  <input
                    type="text"
                    placeholder="DL-JH101"
                    value={regDL}
                    onChange={(e) => setRegDL(e.target.value)}
                    className="w-full bg-stone-950 border border-steel-gray rounded p-2 focus:border-zinc-500 outline-none text-white font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-zinc-400 uppercase block font-mono">RC Ledger Code</label>
                  <input
                    type="text"
                    placeholder="RC-201-99"
                    value={regRC}
                    onChange={(e) => setRegRC(e.target.value)}
                    className="w-full bg-stone-950 border border-steel-gray rounded p-2 focus:border-zinc-500 outline-none text-white font-mono uppercase"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-hazard-orange text-white hover:bg-orange-600 font-bold uppercase text-xs py-3 rounded-lg cursor-pointer transition-all mt-1"
              >
                Register & Upload KYC Docs
              </button>
            </div>
          </form>
        )}

      </div>
      </>)}

      {/* Frame footer home bar */}
      <div className="bg-coal-black pb-4 pt-1 px-5 border-t border-steel-gray absolute bottom-0 left-0 right-0">
        <div className="flex justify-center">
          <div className="w-32 h-1 bg-zinc-700 rounded-full mt-1.5"></div>
        </div>
      </div>

    </div>
  );
}

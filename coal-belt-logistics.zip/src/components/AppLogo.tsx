import React from 'react';
import { Truck, Flame } from 'lucide-react';

interface AppLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  isHindi?: boolean;
}

export default function AppLogo({ className = '', size = 'md', isHindi = false }: AppLogoProps) {
  const sizeClasses = {
    sm: {
      container: 'gap-1.5',
      icon: 'w-5 h-5',
      text: 'text-sm font-semibold tracking-wider',
      tag: 'text-[9px]',
    },
    md: {
      container: 'gap-3',
      icon: 'w-8 h-8 p-1.5',
      text: 'text-xl font-bold tracking-tight',
      tag: 'text-[11px]',
    },
    lg: {
      container: 'gap-4',
      icon: 'w-12 h-12 p-2.5',
      text: 'text-2xl font-black tracking-tighter',
      tag: 'text-xs',
    }
  };

  const selectedSize = sizeClasses[size];

  return (
    <div id="company-logo-id" className={`flex items-center ${selectedSize.container} ${className}`}>
      <div className="relative">
        {/* Glowing hazard effect */}
        <div className="absolute inset-0 bg-hazard-yellow/20 rounded-lg blur-md animate-pulse"></div>
        <div className="relative bg-coal-black border-2 border-hazard-yellow text-hazard-yellow rounded-lg flex items-center justify-center shadow-lg transition-transform hover:scale-105">
          <Truck className={`${selectedSize.icon}`} />
        </div>
        <div className="absolute -top-1 -right-1 bg-hazard-orange text-white rounded-full p-0.5 shadow-sm">
          <Flame className="w-2 h-2" />
        </div>
      </div>
      <div>
        <h1 className={`${selectedSize.text} font-display text-white uppercase flex items-center gap-1.5`}>
          COAL-BELT <span className="text-hazard-yellow">LOGISTICS</span>
        </h1>
        <p className={`${selectedSize.tag} font-mono text-zinc-400 font-semibold tracking-widest flex items-center gap-1`}>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
          {isHindi ? 'धनबाद • रामगढ़ • आसनसोल' : 'DHANBAD • RAMGARH • ASANSOL'}
        </p>
      </div>
    </div>
  );
}

import React, { useEffect, useRef, useState } from 'react';
import { Camera, CameraOff, X, RefreshCw, Sparkles, Terminal, Smartphone, Volume2, Shield } from 'lucide-react';
import jsQR from 'jsqr';

interface SidingQRScannerProps {
  onScanSuccess: (data: string) => void;
  onClose: () => void;
  pendingCost: number;
  pendingBookingId: string | null;
  language: 'en' | 'hi';
}

export default function SidingQRScanner({
  onScanSuccess,
  onClose,
  pendingCost,
  pendingBookingId,
  language
}: SidingQRScannerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [simulatedLog, setSimulatedLog] = useState<string>('');
  
  // HTML5 audio beep
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.12);
    } catch (e) {
      console.warn("Beep audio blocked by browser context limit.", e);
    }
  };

  // Start video stream
  useEffect(() => {
    let stream: MediaStream | null = null;
    let animationFrameId: number;

    const startCamera = async () => {
      try {
        setErrorMessage(null);
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facingMode }
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.setAttribute("playsinline", "true"); // required to play on iOS
          await videoRef.current.play();
          setCameraActive(true);
          setSimulatedLog(language === 'en' ? "✓ Hardware camera active" : "✓ मुख्य कैमरा सक्रिय है");
        }
      } catch (err: any) {
        console.warn("Camera setup failed or not supported in this frame:", err);
        setCameraActive(false);
        setErrorMessage(
          language === 'en' 
            ? "Camera hardware stream restricted or not found. Enjoy sandbox terminal bypass simulation below!"
            : "कैमरा अनुमतियाँ उपलब्ध नहीं हैं। नीचे दिए गए लाइव सिम्युलेटर का उपयोग करें!"
        );
      }
    };

    startCamera();

    // Scan loop
    const tick = () => {
      if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        if (canvas) {
          const ctx = canvas.getContext('2d');
          if (ctx) {
            // Match canvas coordinates to video
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            
            // Draw frame
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            // Get Image Data
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height, {
              inversionAttempts: "dontInvert",
            });
            
            if (code) {
              const loc = code.location;
              // Draw bounding box
              ctx.beginPath();
              ctx.moveTo(loc.topLeftCorner.x, loc.topLeftCorner.y);
              ctx.lineTo(loc.topRightCorner.x, loc.topRightCorner.y);
              ctx.lineTo(loc.bottomRightCorner.x, loc.bottomRightCorner.y);
              ctx.lineTo(loc.bottomLeftCorner.x, loc.bottomLeftCorner.y);
              ctx.closePath();
              ctx.strokeStyle = "#eab308"; // hazard yellow
              ctx.lineWidth = 4;
              ctx.stroke();
              
              // Draw small target dots
              ctx.fillStyle = "#10b981"; // emerald emerald
              ctx.fillRect(loc.topLeftCorner.x - 5, loc.topLeftCorner.y - 5, 10, 10);
              ctx.fillRect(loc.topRightCorner.x - 5, loc.topRightCorner.y - 5, 10, 10);
              ctx.fillRect(loc.bottomRightCorner.x - 5, loc.bottomRightCorner.y - 5, 10, 10);
              ctx.fillRect(loc.bottomLeftCorner.x - 5, loc.bottomLeftCorner.y - 5, 10, 10);

              // Detected!
              playBeep();
              onScanSuccess(code.data);
              return; // stop scanning
            }
          }
        }
      }
      animationFrameId = requestAnimationFrame(tick);
    };

    if (cameraActive) {
      animationFrameId = requestAnimationFrame(tick);
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      cancelAnimationFrame(animationFrameId);
    };
  }, [facingMode, cameraActive]);

  // Handle immediate click manual simulation option
  const triggerSimulation = (mockQrContent: string) => {
    playBeep();
    onScanSuccess(mockQrContent);
  };

  const sidingMockQrs = [
    {
      id: "DHN-SIDING-04",
      name: language === 'en' ? "Dhanbad Coal Siding #4" : "धनबाद कोयला साइडिंग #४",
      location: "Katras Siding area, Dhanbad",
      vpa: "dhn_siding_4@coalcentral"
    },
    {
      id: "RMG-WEIGHT-02",
      name: language === 'en' ? "Ramgarh Weightbridge #2" : "रामगढ़ तौलकांटा #२",
      location: "Saunda Siding, Ramgarh",
      vpa: "ramgarh_wb_2@coalcentral"
    },
    {
      id: "ASN-TERMINAL-01",
      name: language === 'en' ? "Asansol Siding Terminal #1" : "आसनसोल साइडिंग टर्मिनल #१",
      location: "Raniganj East, West Bengal",
      vpa: "asansol_term_1@coalcentral"
    }
  ];

  return (
    <div className="space-y-4">
      {/* Title block */}
      <div className="space-y-1">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center justify-center gap-1.5">
          <Camera className="w-4 h-4 text-hazard-yellow" />
          <span>{language === 'en' ? 'SIDING QR SCAN-PORT' : 'साइडिंग क्यूआर स्कैनर'}</span>
        </h3>
        <p className="text-[10px] text-zinc-400">
          {language === 'en' 
            ? 'Scan physical laminated board QR code at weightbridge for direct billing clearance' 
            : 'बिल भुगतान हेतु धर्मकांटा या साइडिंग पर लगे भौतिक क्यूआर कोड को स्कैन करें'}
        </p>
      </div>

      {/* Main Viewfinder Frame */}
      <div className="relative w-full aspect-video md:h-56 bg-zinc-950 rounded-2xl border-2 border-stone-800 overflow-hidden flex flex-col items-center justify-center shadow-2xl">
        {/* Neon Corners overlay */}
        <div className="absolute top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-hazard-yellow rounded-tl z-25"></div>
        <div className="absolute top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-hazard-yellow rounded-tr z-25"></div>
        <div className="absolute bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-hazard-yellow rounded-bl z-25"></div>
        <div className="absolute bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-hazard-yellow rounded-br z-25"></div>

        {/* Live scanning line laser effect */}
        {cameraActive && (
          <div className="absolute left-0 right-0 h-0.5 bg-hazard-yellow opacity-85 shadow-[0_0_8px_rgba(234,179,8,1)] z-20 animate-bounce" style={{ top: '30%', animationDuration: '3.5s' }} />
        )}

        {/* Real Live Hardware Video & Canvas */}
        <video 
          ref={videoRef} 
          className="absolute inset-0 w-full h-full object-cover z-0"
          style={{ display: cameraActive ? 'block' : 'none' }}
        />
        <canvas 
          ref={canvasRef} 
          className="absolute inset-0 w-full h-full object-cover z-10"
          style={{ display: cameraActive ? 'block' : 'none' }}
        />

        {/* Camera block state */}
        {!cameraActive && (
          <div className="absolute inset-0 z-15 flex flex-col items-center justify-center p-4 bg-zinc-950/90 text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 animate-pulse">
              <CameraOff className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <p className="text-[11px] font-bold text-white uppercase font-mono tracking-wide">
                {language === 'en' ? 'CAMERA STREAM NOT MOUNTED' : 'कैमरा उपलब्ध नहीं है'}
              </p>
              <p className="text-[9px] text-zinc-500 max-w-xs mx-auto leading-tight">
                {language === 'en' 
                  ? 'Standard browser frame block. Simply use our premium sandbox terminal simulation buttons below to instantly clear!'
                  : 'ब्राउज़र सुरक्षा व्यवस्था ने कैमरा ब्लॉक किया है। त्वरित लोडिंग निकासी पास हेतु नीचे दिए गए सिमुलेशन का उपयोग करें!'}
              </p>
            </div>
          </div>
        )}

        {/* Mini HUD Info Overlay */}
        <div className="absolute bottom-2 right-2 z-25 bg-black/80 px-2 py-0.5 rounded border border-zinc-800 text-[8px] font-mono text-zinc-400 flex items-center gap-1 uppercase">
          <span className={`w-1 h-1 rounded-full ${cameraActive ? 'bg-emerald-500 animate-ping' : 'bg-red-500'}`}></span>
          <span>{facingMode === 'environment' ? 'Rear Cam' : 'Front Cam'}</span>
        </div>

        {/* Toggle Cam hardware switch */}
        {cameraActive && (
          <button
            onClick={() => setFacingMode(prev => prev === 'environment' ? 'user' : 'environment')}
            className="absolute top-2 right-2 z-25 bg-zinc-900/90 hover:bg-zinc-800 text-white p-1.5 rounded-lg border border-zinc-700 transition-colors cursor-pointer"
            title="Switch Camera Face"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Sessional logs */}
      {simulatedLog && (
        <div className="bg-zinc-950 text-left p-2 rounded-lg border border-zinc-900 font-mono text-[8.5px] text-zinc-400 flex items-center gap-1">
          <Terminal className="w-3 h-3 text-zinc-500 shrink-0" />
          <span className="truncate">{simulatedLog}</span>
        </div>
      )}

      {/* Manual Sandbox Simulator Hotkeys (IMPORTANT FOR SANDBOX DEMO) */}
      <div className="space-y-2 text-left">
        <label className="text-[9px] text-zinc-500 uppercase font-mono block tracking-wider">
          👉 {language === 'en' ? 'MOCK PHYSICAL SIDING BOARD SCAN' : '👉 या साइडिंग क्यूआर को भौतिक रूप से सिम्युलेट करें:'}
        </label>
        
        <div className="grid grid-cols-1 gap-1.5">
          {sidingMockQrs.map((siding) => (
            <button
              key={siding.id}
              onClick={() => {
                setSimulatedLog(language === 'en' ? `⌛ Reading Siding ${siding.id} Board...` : `⌛ साइडिंग पास कोड पढ़ रहा है...`);
                setTimeout(() => {
                  triggerSimulation(`SIDING_PAYMENT_VPA:${siding.vpa}|GATE:${siding.id}|AMOUNT:${pendingCost}|ORDER:${pendingBookingId}`);
                }, 350);
              }}
              className="bg-stone-900 hover:bg-stone-850 hover:border-hazard-yellow border border-zinc-800 rounded-xl p-2.5 text-left flex items-center justify-between transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2 max-w-[80%]">
                <div className="w-6 h-6 rounded bg-amber-500/10 text-hazard-yellow flex items-center justify-center text-[10px] font-black shrink-0 font-mono group-hover:bg-amber-500 group-hover:text-black transition-colors">
                  QR
                </div>
                <div className="truncate">
                  <p className="text-[10.5px] font-black text-white truncate leading-tight">{siding.name}</p>
                  <p className="text-[8.5px] text-zinc-500 truncate leading-tight font-mono">{siding.location}</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[9.5px] bg-emerald-950/60 font-semibold border border-emerald-900 text-emerald-400 px-1.5 py-0.5 rounded font-mono">
                  Settle Setup
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Back cancel trigger */}
      <button
        onClick={onClose}
        className="w-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-bold uppercase text-[10px] py-2.5 rounded-xl transition-all cursor-pointer"
      >
        {language === 'en' ? 'BACK TO INVOICE MODES' : 'वापस जाएँ'}
      </button>
    </div>
  );
}

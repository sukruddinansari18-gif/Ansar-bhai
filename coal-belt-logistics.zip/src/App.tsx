import React, { useState, useEffect } from 'react';
import RoleSelector from './components/RoleSelector';
import CustomerApp from './components/CustomerApp';
import DriverApp from './components/DriverApp';
import AdminPanel from './components/AdminPanel';
import AIChatBot from './components/AIChatBot';
import AppLogo from './components/AppLogo';
import B2BAuthWrapper from './components/B2BAuthWrapper';
import { AppState, VehicleType } from './types';
import { Info, HelpCircle, HardHat, Shield } from 'lucide-react';

export default function App() {
  const [role, setRole] = useState<'customer' | 'driver' | 'admin'>('customer');
  const [language, setLanguage] = useState<'en' | 'hi'>('en');
  const [isOffline, setIsOffline] = useState<boolean>(false);

  // Corporate B2B Secure Sessions
  const [customerUser, setCustomerUser] = useState<any>(() => {
    const saved = localStorage.getItem('coal_b2b_customer_profile');
    return saved ? JSON.parse(saved) : null;
  });
  const [driverUser, setDriverUser] = useState<any>(() => {
    const saved = localStorage.getItem('coal_b2b_driver_profile');
    return saved ? JSON.parse(saved) : null;
  });
  const [adminUser, setAdminUser] = useState<any>(() => {
    const saved = localStorage.getItem('coal_b2b_admin_profile');
    return saved ? JSON.parse(saved) : null;
  });

  // Synchronized Full-Stack State Database
  const [state, setState] = useState<AppState>({
    bookings: [],
    drivers: [],
    fuelLogs: [],
    alerts: [],
    config: {
      surgeMultiplier: 1.15,
      isMonsoonActive: false,
      baseDieselPrice: 94.35,
      commissionPercent: 12,
      geofenceEnabled: true,
    }
  });

  const [loading, setLoading] = useState(true);

  // Core synchronization fetch
  const fetchState = async () => {
    // If user simulates offline mode, skip fetching to represent low-network caching
    if (isOffline) return;

    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data = await res.json();
        setState(data);
      }
    } catch (err) {
      console.warn("Failed to synchronize state with Express backend. Continuing in offline standalone mode.", err);
    } finally {
      setLoading(false);
    }
  };

  // Run on startup and do polling updates to represent live active GPS fleets moving
  useEffect(() => {
    fetchState();
    const interval = setInterval(() => {
      fetchState();
    }, 4500); // Poll every 4.5 seconds to sync drivers state between screens
    return () => clearInterval(interval);
  }, [isOffline]);

  // Handle customer dispatch order
  const handleNewBooking = async (bookingData: any) => {
    if (isOffline) {
      // Offline mode handling is stored in CustomerApp.tsx state directly
      return;
    }

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingData)
      });
      if (res.ok) {
        await fetchState(); // sync state now
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Trigger dispatch transit milestone actions
  const handleTriggerAction = async (bookingId: string, action: string, extra?: any) => {
    try {
      const res = await fetch(`/api/bookings/${bookingId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...extra })
      });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Toggle online switcher for drivers
  const handleOfflineToggle = async (driverId: string, online: boolean) => {
    try {
      const res = await fetch('/api/drivers/offline-toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ driverId, online })
      });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Register on-boarded drivers
  const handleRegisterDriver = async (driverPayload: any) => {
    try {
      const res = await fetch('/api/drivers/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(driverPayload)
      });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Write diesel cost slips
  const handleFuelEntry = async (fuelPayload: any) => {
    try {
      const res = await fetch('/api/drivers/fuel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fuelPayload)
      });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Modify surge and diesel rates configs from admin
  const handleUpdateConfig = async (configPayload: any) => {
    try {
      const res = await fetch('/api/admin/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(configPayload)
      });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Admin approves vehicle driver onboarding
  const handleApproveDriver = async (driverId: string, approve: boolean) => {
    try {
      const res = await fetch('/api/drivers/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ driverId, approve })
      });
      if (res.ok) {
        await fetchState();
      }
    } catch (err) {
       console.error(err);
    }
  };

  // Autofill booking handler triggered by Gemini extraction
  const [autofillRef, setAutofillRef] = useState<any>(null);
  const handleAutoFillBooking = (parsedData: any) => {
     setAutofillRef(parsedData);
  };

  return (
    <div id="full-app-root" className="min-h-screen bg-coal-black text-zinc-100 flex flex-col font-sans selection:bg-hazard-yellow selection:text-coal-black">
      
      {/* Floating Mode-Selection Header Command Center */}
      <RoleSelector
        currentRole={role}
        onChangeRole={(r) => setRole(r)}
        language={language}
        onChangeLanguage={(l) => setLanguage(l)}
        isOffline={isOffline}
        onToggleOffline={() => setIsOffline(!isOffline)}
      />

      {/* Main Container Wrapper */}
      <main className="flex-grow max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 space-y-6">
        
        {/* Desktop Head Branding Sector */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between bg-mine-gray border border-steel-gray rounded-2xl p-4 gap-4">
          <AppLogo isHindi={language === 'hi'} size="md" />
          
          <div className="flex items-center gap-2.5 max-w-lg text-xs text-zinc-400 bg-sand-stone">
            <Info className="w-5 h-5 text-hazard-yellow shrink-0" />
            <p className="leading-tight">
              {language === 'en'
                ? 'Test real-time B2B shipping synchronization by booking as Customer, switching duty on/off as Driver, and authorizing credentials under Admin HQ.'
                : 'रियल-टाइम डिलीवरी सिंक का परीक्षण करें: ग्राहक ऐप से आर्डर बुक करें, ड्राइवर ऐप से स्वीकार करें, और एडमिन डैशबोर्ड पर आंकड़े देखें।'}
            </p>
          </div>
        </div>

        {/* Dynamic Display of active application state */}
        {loading ? (
          <div className="text-center py-20">
            <div className="w-10 h-10 border-4 border-hazard-yellow border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-zinc-400 font-mono text-xs">Loading Coal-Belt heavy dispatch systems...</p>
          </div>
        ) : (
          <div className="transition-all duration-300">
            
            {/* VIEW 1: CUSTOMER MOBILE APP */}
            {role === 'customer' && (
              <div className="grid grid-cols-1 md:grid-cols-1 gap-6 animate-fade-in justify-center">
                {!customerUser ? (
                  <B2BAuthWrapper
                    role="customer"
                    language={language}
                    onLoginSuccess={(profile) => {
                      setCustomerUser(profile);
                      localStorage.setItem('coal_b2b_customer_profile', JSON.stringify(profile));
                      localStorage.setItem('customer_logged_in', 'true');
                    }}
                  />
                ) : (
                  <CustomerApp
                    state={state}
                    isOffline={isOffline}
                    onNewBooking={handleNewBooking}
                    onTriggerAction={handleTriggerAction}
                    language={language}
                    currentUser={customerUser}
                    onLogout={() => {
                      setCustomerUser(null);
                      localStorage.removeItem('coal_b2b_customer_profile');
                      localStorage.removeItem('customer_logged_in');
                    }}
                  />
                )}
              </div>
            )}

            {/* VIEW 2: DRIVER MOBILE TERMINAL */}
            {role === 'driver' && (
              <div className="grid grid-cols-1 gap-6 justify-center">
                {!driverUser ? (
                  <B2BAuthWrapper
                    role="driver"
                    language={language}
                    onLoginSuccess={(profile) => {
                      setDriverUser(profile);
                      localStorage.setItem('coal_b2b_driver_profile', JSON.stringify(profile));
                      localStorage.setItem('driver_logged_in', 'true');
                    }}
                  />
                ) : (
                  <DriverApp
                    state={state}
                    isOffline={isOffline}
                    onOfflineToggle={handleOfflineToggle}
                    onTriggerAction={handleTriggerAction}
                    onRegisterDriver={handleRegisterDriver}
                    onFuelEntry={handleFuelEntry}
                    language={language}
                    currentUser={driverUser}
                    onLogout={() => {
                      setDriverUser(null);
                      localStorage.removeItem('coal_b2b_driver_profile');
                      localStorage.removeItem('driver_logged_in');
                    }}
                  />
                )}
              </div>
            )}

            {/* VIEW 3: WEB CONTROL ADMIN PANEL */}
            {role === 'admin' && (
              <div className="animate-fade-in">
                {!adminUser ? (
                  <B2BAuthWrapper
                    role="admin"
                    language={language}
                    onLoginSuccess={(profile) => {
                      setAdminUser(profile);
                      localStorage.setItem('coal_b2b_admin_profile', JSON.stringify(profile));
                      localStorage.setItem('coal_b2b_admin_logged', 'true');
                    }}
                  />
                ) : (
                  <AdminPanel
                    state={state}
                    onUpdateConfig={handleUpdateConfig}
                    onApproveDriver={handleApproveDriver}
                    language={language}
                    currentUser={adminUser}
                    onLogout={() => {
                      setAdminUser(null);
                      localStorage.removeItem('coal_b2b_admin_profile');
                      localStorage.removeItem('coal_b2b_admin_logged');
                    }}
                  />
                )}
              </div>
            )}

          </div>
        )}

      </main>

      {/* Floating Gemini AI Conversational Assistant */}
      <AIChatBot
        language={language}
        onAutoFillBooking={(parsed) => {
          // Switch back to customer booking and trigger autofill
          setRole('customer');
          // Wait briefly, we can pass ref or let CustomerApp listen to triggered action values
          alert(`Imported ${parsed.vehicleType} payload. Please adjust weight and confirm freight order!`);
        }}
      />

      {/* Immersive Platform Footer */}
      <footer className="border-t border-steel-gray bg-mine-gray py-6 text-center text-xs text-zinc-500 font-mono tracking-wider">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-3">
          <p>© 2026 Coal-Belt Logistics Private Ltd. Dhanbad Heavy Sideings Corp.</p>
          <div className="flex items-center gap-3">
            <span>Jharkhand Mining Pass System v4.2</span>
            <span>•</span>
            <span className="text-emerald-500">Live GPS tracking active</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

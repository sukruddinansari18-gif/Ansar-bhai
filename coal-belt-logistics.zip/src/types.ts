export type VehicleType = 'mini_truck' | 'pickup' | 'dumper' | 'tata_407' | 'hyva' | 'trailer';

export interface VehicleConfig {
  id: VehicleType;
  nameEn: string;
  nameHi: string;
  baseFare: number;
  perKmRate: number;
  capacityMaxTons: number;
  descriptionEn: string;
  descriptionHi: string;
  avgFuelEfficiencyKmpl: number;
}

export type BookingStatus = 
  | 'pending' 
  | 'accepted' 
  | 'loading' 
  | 'en_route' 
  | 'unloading' 
  | 'completed' 
  | 'cancelled';

export interface Booking {
  id: string;
  customerName: string;
  customerPhone: string;
  pickupName: string;
  dropName: string;
  pickupCounty: 'Dhanbad' | 'Ramgarh' | 'Asansol' | 'Bokaro' | 'Jharia';
  dropCounty: 'Dhanbad' | 'Ramgarh' | 'Asansol' | 'Bokaro' | 'Jharia';
  vehicleType: VehicleType;
  status: BookingStatus;
  weightTons: number;
  isOverloaded: boolean;
  challanNumber: string;
  coalPassId?: string;
  coalPassDocName?: string;
  distanceKm: number;
  costEstimate: number;
  tollTaxEstimate: number;
  finesEstimate: number;
  etaMinutes: number;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  driverVehicleNumber?: string;
  paymentStatus: 'pending' | 'paid';
  paymentMethod: 'wallet' | 'upi' | 'cash';
  rating?: number;
  feedback?: string;
  timestamp: string;
  isOfflineCreated?: boolean;
}

export interface Driver {
  id: string;
  name: string;
  phone: string;
  vehicleType: VehicleType;
  vehicleNumber: string;
  online: boolean;
  active: boolean;
  rating: number;
  docsApproved: boolean;
  aadhaarNum: string;
  licenseNum: string;
  rcNum: string;
  earningsThisWeek: number;
  earningsToday: number;
  totalTrips: number;
  currentLat: number;
  currentLng: number;
}

export interface FuelLog {
  id: string;
  driverId: string;
  liters: number;
  costPerLiter: number;
  totalCost: number;
  date: string;
  mileageOdometer: number;
}

export interface SystemAlert {
  id: string;
  type: 'overload' | 'geofence' | 'delay' | 'unauthorized_route';
  messageEn: string;
  messageHi: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: string;
  bookingId?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  isVoice?: boolean;
}

export interface AppConfig {
  surgeMultiplier: number;
  isMonsoonActive: boolean;
  baseDieselPrice: number;
  commissionPercent: number;
  geofenceEnabled: boolean;
}

export interface AppState {
  bookings: Booking[];
  drivers: Driver[];
  fuelLogs: FuelLog[];
  alerts: SystemAlert[];
  config: AppConfig;
}

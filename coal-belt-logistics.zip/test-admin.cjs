const admin = require("firebase-admin");
const { getFirestore } = require("firebase-admin/firestore");
const fs = require("fs");
const path = require("path");

async function run() {
  const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
  const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf-8"));

  console.log("=== FIREBASE ADMIN DIAGNOSTIC ===");
  console.log("Project ID:", firebaseConfig.projectId);
  console.log("Database ID:", firebaseConfig.firestoreDatabaseId);

  try {
    // Initialize admin with the config
    admin.initializeApp({
      projectId: firebaseConfig.projectId,
    });

    // Access the database with the specific databaseId
    const db = getFirestore();

    const testDocRef = db.collection("test").doc("connection-admin");
    console.log("  Writing test document using Admin SDK...");
    await testDocRef.set({ 
      timestamp: new Date().toISOString(), 
      adminVerified: true 
    });
    console.log("  ✓ Admin Write success!");

    console.log("  Reading test document...");
    const snapshot = await testDocRef.get();
    console.log("  ✓ Admin Read success! Data:", snapshot.data());
  } catch (err) {
    console.error("  ✗ Admin Failed:", err.message);
  }
}

run();

# Android Firebase Configuration Guide (Coal-Belt Logistics)

This guide documents the exact steps, paths, and gradle configurations needed to integrate your mobile Android clients with the thematic Coal-Belt Logistics Firebase system.

---

## 1. Where to Upload `google-services.json`

If you are building a native Android app (using Kotlin, Java, Flutter, React Native, or Cordorva), your `google-services.json` file **must** be placed in the **app-level directory** of your Android project structure.

### Project Layout Reference:
```text
CoalBeltLogisticsAndroid/
├── build.gradle (Project-level)
├── settings.gradle
├── app/
│   ├── google-services.json  <=== UPLOAD YOUR DOWNLOADED FILE HERE!
│   ├── build.gradle (App-level)
│   └── src/
```

---

## 2. Global Level Gradle Setup (`build.gradle` - Project Level)

Add the Google Services classpath inside your root dependency build script:

```groovy
// root/build.gradle
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Add Google Services classpath plugin
        classpath 'com.google.gms:google-services:4.4.1'
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
```

---

## 3. App Level Gradle Setup (`app/build.gradle` - App Level)

Apply the Google Services plugin and declare standard Firestore and Authentication dependencies:

```groovy
// root/app/build.gradle
apply plugin: 'com.android.application'
apply plugin: 'com.google.gms.google-services' // Apply GMS Google Services Plugin

android {
    namespace 'com.coalbelt.logistics'
    compileSdk 34

    defaultConfig {
        applicationId "com.coalbelt.logistics"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }
}

dependencies {
    // Import the Firebase BoM
    implementation platform('com.google.firebase:firebase-bom:32.8.0')

    // Add Firebase SDK Dependencies
    implementation 'com.google.firebase:firebase-analytics'
    implementation 'com.google.firebase:firebase-auth'      // For OTP Phone verification
    implementation 'com.google.firebase:firebase-firestore' // For live order & GPS sync
    implementation 'com.google.firebase:firebase-storage'   // For driver KYC license uploads
}
```

---

## 4. Android Kotlin Driver Authentication Pattern

Use this template to invoke production-ready Firebase Mobile Verification inside your mobile app:

```kotlin
package com.coalbelt.logistics

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class DriverVerifyActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private var verificationId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver_verify)

        // Initialize Firebase Authentication
        auth = FirebaseAuth.getInstance()
    }

    fun startSmsVerification(phoneNumber: String) {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber("+91$phoneNumber") // Indian country code prefix
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    // Automatically auto-verify OTP if code is intercepted on device
                    signInWithPhoneAuthCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Toast.makeText(this@DriverVerifyActivity, "Verification failed: ${e.message}", Toast.LENGTH_LONG).show()
                }

                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    // Code successfully dispatched to carrier service
                    verificationId = id
                    Toast.makeText(this@DriverVerifyActivity, "OTP Code Dispatched to +91$phoneNumber", Toast.LENGTH_SHORT).show()
                }
            })
            .build()
        
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifySmsCode(enteredCode: String) {
        val id = verificationId ?: return
        val credential = PhoneAuthProvider.getCredential(id, enteredCode)
        signInWithPhoneAuthCredential(credential)
    }

    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential).addOnCompleteListener(this) { task ->
            if (task.isSuccessful) {
                val user = auth.currentUser
                Toast.makeText(this, "Welcome, Operator! Verification Confirmed.", Toast.LENGTH_SHORT).show()
                // Proceed to B2B Onboarding Registration dashboard...
            } else {
                Toast.makeText(this, "Invalid verification pin entered.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
```

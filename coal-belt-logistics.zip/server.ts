import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { AppState, Booking, Driver, FuelLog, SystemAlert, VehicleType } from "./src/types";

// Initialize Firebase for persistent storage
import { initializeApp as initializeClientApp } from "firebase/app";
import { 
  getFirestore as getClientFirestore, 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  addDoc, 
  deleteDoc, 
  query, 
  where,
  orderBy,
  limit
} from "firebase/firestore";

// Load environment variables configured in workspace secrets or .env.example
dotenv.config();

// Direct synchronous file trace to verify execution CWD and environment
try {
  fs.writeFileSync(
    path.join(process.cwd(), "startup-trace.json"),
    JSON.stringify({
      timestamp: new Date().toISOString(),
      cwd: process.cwd(),
      env: Object.keys(process.env).filter(k => !k.includes("KEY") && !k.includes("SECRET") && !k.includes("PASSWORD")),
    }, null, 2)
  );
} catch (traceErr: any) {
  console.error("Trace write failed:", traceErr);
}

const app = express();
const PORT = 3000;

app.use(express.json());

// Temporary Firebase Debug Verification Route
app.get("/api/debug-firebase", async (req, res) => {
  const results: any[] = [];
  try {
    const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
    if (!fs.existsSync(firebaseConfigPath)) {
      return res.json({ error: "firebase-applet-config.json does not exist." });
    }
    const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf-8"));
    const firebaseApp = initializeClientApp(firebaseConfig);

    const databases = [
      { name: "Custom Database", id: firebaseConfig.firestoreDatabaseId },
      { name: "Default Database", id: "(default)" },
      { name: "No Database ID Specified", id: undefined }
    ];

    for (const dbInfo of databases) {
      const dbRes: any = { name: dbInfo.name, id: dbInfo.id };
      try {
        const testDb = getClientFirestore(firebaseApp, dbInfo.id);
        const testDocRef = doc(testDb, "test", "connection");
        
        dbRes.writeAttempt = "started";
        await setDoc(testDocRef, { timestamp: new Date().toISOString(), serverVerified: true });
        dbRes.writeSuccess = true;

        dbRes.readAttempt = "started";
        const snapshot = await getDoc(testDocRef);
        dbRes.readSuccess = true;
        dbRes.readData = snapshot.data();
      } catch (err: any) {
        dbRes.error = err.message || String(err);
        dbRes.code = err.code || null;
      }
      results.push(dbRes);
    }
  } catch (globalErr: any) {
    return res.json({ globalError: globalErr.message || String(globalErr) });
  }
  res.json({ results });
});

// Load Firebase configuration
let firestoreDb: any = null;
try {
  fs.writeFileSync(path.join(process.cwd(), "firebase-step.json"), "1: Entered try block");
  const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(firebaseConfigPath)) {
    fs.writeFileSync(path.join(process.cwd(), "firebase-step.json"), "2: Config exists");
    const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf-8"));
    fs.writeFileSync(path.join(process.cwd(), "firebase-step.json"), "3: Config parsed");
    const firebaseApp = initializeClientApp(firebaseConfig);
    fs.writeFileSync(path.join(process.cwd(), "firebase-step.json"), "4: Client app initialized");
    firestoreDb = getClientFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);
    fs.writeFileSync(path.join(process.cwd(), "firebase-step.json"), "5: Client firestore initialized");
    console.log("✓ Live Firestore securely connected from Express backend.");

    // Run custom startup diagnostics and write to a shared file
    (async () => {
      console.log("Running background Firestore diagnostics check...");
      fs.writeFileSync(
        path.join(process.cwd(), "firebase-init-status.json"),
        JSON.stringify({ timestamp: new Date().toISOString(), status: "initializing" }, null, 2)
      );
      const withTimeout = async (promise: Promise<any>, ms: number, label: string) => {
        let timeoutId: any;
        const timeoutPromise = new Promise((_, reject) => {
          timeoutId = setTimeout(() => {
            reject(new Error(`Timeout of ${ms}ms exceeded for ${label}`));
          }, ms);
        });
        return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timeoutId));
      };

      const diagResults: any[] = [];
      const databases = [
        { name: "Custom Database", id: firebaseConfig.firestoreDatabaseId },
        { name: "Default Database", id: "(default)" },
        { name: "Undefined/Implicit Database", id: undefined }
      ];
      for (const dbInfo of databases) {
        const dbRes: any = { name: dbInfo.name, id: dbInfo.id };
        try {
          const testDb = getClientFirestore(firebaseApp, dbInfo.id);
          const docRef = doc(testDb, "test", "connection");
          
          dbRes.writeAttempt = "started";
          await withTimeout(setDoc(docRef, { timestamp: new Date().toISOString(), startupDiagnostic: true }), 3000, "setDoc");
          dbRes.writeSuccess = true;
          
          dbRes.readAttempt = "started";
          const snap = await withTimeout(getDoc(docRef), 3000, "getDoc");
          dbRes.readSuccess = true;
          dbRes.readData = snap.data();
        } catch (err: any) {
          dbRes.writeSuccess = dbRes.writeSuccess || false;
          dbRes.error = err.message || String(err);
          dbRes.code = err.code || null;
        }
        diagResults.push(dbRes);
      }
      fs.writeFileSync(
        path.join(process.cwd(), "firebase-diagnosis.json"),
        JSON.stringify({ timestamp: new Date().toISOString(), results: diagResults }, null, 2)
      );
      fs.writeFileSync(
        path.join(process.cwd(), "firebase-init-status.json"),
        JSON.stringify({ timestamp: new Date().toISOString(), status: "success", count: diagResults.length }, null, 2)
      );
      console.log("✓ Firestore diagnostics written of firebase-diagnosis.json.");
    })();

  } else {
    fs.writeFileSync(path.join(process.cwd(), "firebase-step.json"), "2e: Config does not exist");
    console.log("⚠ firebase-applet-config.json not found. Run set_up_firebase first.");
    fs.writeFileSync(
      path.join(process.cwd(), "firebase-init-status.json"),
      JSON.stringify({ timestamp: new Date().toISOString(), status: "config_not_found" }, null, 2)
    );
  }
} catch (error: any) {
  fs.writeFileSync(path.join(process.cwd(), "firebase-step.json"), "Err: Catch block: " + String(error.message || error));
  console.error("✗ Failed to initialize Firestore on Express:", error);
  fs.writeFileSync(
    path.join(process.cwd(), "firebase-init-error.json"),
    JSON.stringify({ timestamp: new Date().toISOString(), error: error.message || String(error) }, null, 2)
  );
}

// Initialize Gemini SDK with named parameter and correct headers.
let ai: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey && apiKey !== "MY_GEMINI_API_KEY" && apiKey !== "") {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("✓ Google GenAI successfully initialized server-side.");
  } catch (error) {
    console.error("✗ Failed to initialize Google GenAI SDK:", error);
  }
} else {
  console.log("⚠ GEMINI_API_KEY not configured. Running AI in simulation mode.");
}

// -----------------------------------------------------------------------------
// IN-MEMORY SHARED LOGISTICS STATE (Synchronized DB Simulator)
// -----------------------------------------------------------------------------
const state: AppState = {
  bookings: [
    {
      id: "BK-1002",
      customerName: "Rungta Coal Traders Ltd.",
      customerPhone: "9830412354",
      pickupName: "Bastacolla Coal Pit, Katras",
      dropName: "Lodna Siding Yard, Jharia",
      pickupCounty: "Dhanbad",
      dropCounty: "Jharia",
      vehicleType: "hyva",
      status: "completed",
      weightTons: 24,
      isOverloaded: false,
      challanNumber: "CH-DND-992182",
      coalPassId: "PASS-D812",
      coalPassDocName: "dhanbad_pass_2026.pdf",
      distanceKm: 12,
      costEstimate: 4500,
      tollTaxEstimate: 0,
      finesEstimate: 0,
      etaMinutes: 0,
      driverId: "drv_01",
      driverName: "Rajinder Yadav",
      driverPhone: "98734XXXXX",
      driverVehicleNumber: "JH-10-AT-4782",
      paymentStatus: "paid",
      paymentMethod: "wallet",
      rating: 5,
      feedback: "Fast loading at site. No congestion.",
      timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    },
    {
      id: "BK-1003",
      customerName: "Radhe Gobind Brick Kilns",
      customerPhone: "7029144821",
      pickupName: "Gola Sponge Iron Yard",
      dropName: "Bhurkunda Pit, Ramgarh",
      pickupCounty: "Ramgarh",
      dropCounty: "Ramgarh",
      vehicleType: "pickup",
      status: "en_route",
      weightTons: 2.4, // Overloaded for a 2.0-ton pickup
      isOverloaded: true,
      challanNumber: "CH-RM-884920",
      coalPassId: "PASS-R110",
      coalPassDocName: "ramgarh_coke_permit.png",
      distanceKm: 28,
      costEstimate: 1250,
      tollTaxEstimate: 120,
      finesEstimate: 500, // Overload fine computed
      etaMinutes: 18,
      driverId: "drv_02",
      driverName: "Manpreet Singh",
      driverPhone: "98361XXXXX",
      driverVehicleNumber: "JH-02-B-9912",
      paymentStatus: "pending",
      paymentMethod: "upi",
      timestamp: new Date(Date.now() - 1800000).toISOString(),
    }
  ],
  drivers: [
    {
      id: "drv_01",
      name: "Rajinder Yadav",
      phone: "98734XXXXX",
      vehicleType: "hyva",
      vehicleNumber: "JH-10-AT-4782",
      online: true,
      active: false,
      rating: 4.8,
      docsApproved: true,
      aadhaarNum: "3948-2849-1029",
      licenseNum: "DL-IND-JH1011",
      rcNum: "RC-JH10-9938294",
      earningsThisWeek: 18450,
      earningsToday: 3200,
      totalTrips: 142,
      currentLat: 23.7912,
      currentLng: 86.4250,
    },
    {
      id: "drv_02",
      name: "Manpreet Singh",
      phone: "98361XXXXX",
      vehicleType: "pickup",
      vehicleNumber: "JH-02-B-9912",
      online: true,
      active: true, // Currently tracking on BK-1003
      rating: 4.7,
      docsApproved: true,
      aadhaarNum: "1029-4829-5928",
      licenseNum: "DL-IND-JH0202",
      rcNum: "RC-JH02-1102948",
      earningsThisWeek: 14200,
      earningsToday: 1250,
      totalTrips: 98,
      currentLat: 23.6350,
      currentLng: 85.5180,
    },
    {
      id: "drv_03",
      name: "Sunil Marandi",
      phone: "82940XXXXX",
      vehicleType: "mini_truck",
      vehicleNumber: "WB-38-K-1928",
      online: true,
      active: false,
      rating: 4.9,
      docsApproved: true,
      aadhaarNum: "4829-1029-4482",
      licenseNum: "DL-IND-WB3844",
      rcNum: "RC-WB38-1294833",
      earningsThisWeek: 7800,
      earningsToday: 1350,
      totalTrips: 210,
      currentLat: 23.6800,
      currentLng: 86.9500,
    },
    {
      id: "drv_04",
      name: "Manoj Mahto",
      phone: "70281XXXXX",
      vehicleType: "tata_407",
      vehicleNumber: "JH-09-E-5512",
      online: false,
      active: false,
      rating: 4.5,
      docsApproved: true,
      aadhaarNum: "5561-2831-7783",
      licenseNum: "DL-IND-JH0992",
      rcNum: "RC-JH09-382948",
      earningsThisWeek: 11300,
      earningsToday: 0,
      totalTrips: 74,
      currentLat: 23.7431,
      currentLng: 86.4111,
    },
    {
      id: "drv_05",
      name: "Sanjeev Besra",
      phone: "93041XXXXX",
      vehicleType: "pickup",
      vehicleNumber: "JH-10-M-3211",
      online: true,
      active: false,
      rating: 4.3,
      docsApproved: false, // Starts as pending to demonstrate admin approval
      aadhaarNum: "8827-1129-3849",
      licenseNum: "DL-IND-JH1092",
      rcNum: "RC-JH10-384928",
      earningsThisWeek: 0,
      earningsToday: 0,
      totalTrips: 0,
      currentLat: 23.7922,
      currentLng: 86.4404,
    }
  ],
  fuelLogs: [
    {
      id: "FL-501",
      driverId: "drv_01",
      liters: 62,
      costPerLiter: 94.20,
      totalCost: 5840.40,
      date: "2026-06-01",
      mileageOdometer: 44210,
    }
  ],
  alerts: [
    {
      id: "ALT-901",
      type: "overload",
      messageEn: "Booking BK-1003 is flagged! Recirculation fine applied due to 2.4 Tons load on Bolero Pickup (Max 2.0 Tons limit).",
      messageHi: "बुकिंग BK-1003 चिह्नित है! बोलेरो पिकअप (अधिकतम 2.0 टन) पर 2.4 टन लोड के कारण जुर्माना लगाया गया।",
      severity: "medium",
      timestamp: new Date(Date.now() - 1800000).toISOString(),
      bookingId: "BK-1003"
    }
  ],
  config: {
    surgeMultiplier: 1.15,
    isMonsoonActive: false,
    baseDieselPrice: 94.35,
    commissionPercent: 12,
    geofenceEnabled: true,
  }
};

// Vehicle rates preset config
const VEHICLE_RATES: Record<VehicleType, { base: number; perKm: number; limit: number }> = {
  mini_truck: { base: 350, perKm: 15, limit: 1.2 },
  pickup: { base: 500, perKm: 18, limit: 2.0 },
  tata_407: { base: 800, perKm: 24, limit: 4.5 },
  dumper: { base: 1500, perKm: 40, limit: 10.0 },
  hyva: { base: 3200, perKm: 65, limit: 25.0 },
  trailer: { base: 5500, perKm: 95, limit: 40.0 },
};

// -----------------------------------------------------------------------------
// B2B ENTERPRISE AUTHENTICATION & SECURITY STATE
// -----------------------------------------------------------------------------

export interface BusinessVerification {
  id: string;
  companyName: string;
  ownerName: string;
  mobile: string;
  email: string;
  gstNumber: string;
  address: string;
  aadhaarNum: string;
  panNum: string;
  companyLicense: string;
  coalPermit: string;
  profilePhoto: string;
  status: 'Pending' | 'Verified' | 'Rejected' | 'Suspended';
  ocrVerifiedLog: string;
  aiAuditResult: string;
  registeredAt: string;
  kycAutofilled: boolean;
}

export interface DriverVerification {
  id: string;
  driverName: string;
  mobile: string;
  aadhaarNum: string;
  licenseNum: string;
  licenseExpiry: string;
  rcNum: string;
  insuranceNum: string;
  insuranceExpiry: string;
  fitnessCertNum: string;
  vehicleType: string;
  vehicleNumber: string;
  truckPhoto: string;
  selfiePhoto: string;
  faceMatchPercent: number;
  status: 'Pending' | 'Verified' | 'Rejected' | 'Suspended';
  registeredAt: string;
}

export interface SecuritySessionLog {
  id: string;
  phone: string;
  role: 'customer' | 'driver' | 'admin';
  action: 'OTP_REQUEST' | 'OTP_VERIFY_SUCCESS' | 'OTP_VERIFY_LOCKOUT' | 'GEO_FENCE_LOGIN_DENIED' | 'DEVICE_BIND_CONFLICT' | 'SESSION_TIMEOUT' | 'SUSPENDED_ACCESS_ATTEMPT';
  ipAddress: string;
  deviceId: string;
  gpsCoords: string;
  timestamp: string;
  severity: 'low' | 'medium' | 'high';
  fraudFlags: string[];
}

// In-Memory Database for Security & Verification Systems
const businessDb: BusinessVerification[] = [
  {
    id: "BIZ-6481",
    companyName: "Rungta Coal Traders Ltd.",
    ownerName: "Ramesh Rungta",
    mobile: "9830412354",
    email: "ramesh@rungtacoal.in",
    gstNumber: "20AABCR1293J1Z4",
    address: "Rungta House, Jharia Coal Road, Dhanbad, JH, 826001",
    aadhaarNum: "4532-1192-3849",
    panNum: "ABCPR1293J",
    companyLicense: "LIC-COAL-DHN-2022-839",
    coalPermit: "PERMIT-MINING-D812",
    profilePhoto: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=120",
    status: "Verified",
    ocrVerifiedLog: "GST Reg verified via Govt Portal API. PAN matching owner photo signature checks.",
    aiAuditResult: "MATCH 100% - Normal Enterprise Activity. Low credit delinquency check.",
    registeredAt: "2026-05-10T11:20:00Z",
    kycAutofilled: true,
  },
  {
    id: "BIZ-3142",
    companyName: "Patratu Thermal Coal Supply",
    ownerName: "Arpit Verma",
    mobile: "9007218311",
    email: "supply@patratupower.com",
    gstNumber: "20KKKJD4192V1ZD",
    address: "Block-D, Thermal Siding, Patratu, Ramgarh, JH, 829118",
    aadhaarNum: "5671-1029-4112",
    panNum: "KKKJD4192V",
    companyLicense: "LIC-THERM-RMG-4819",
    coalPermit: "PERMIT-COAL-9938",
    profilePhoto: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120",
    status: "Pending",
    ocrVerifiedLog: "GST extraction successful. Permit document upload OCR checks completed. System awaiting manual physical challan corroboration.",
    aiAuditResult: "MATCH 92% - Valid coal permits flagged on state borders. Risk profile: Normal.",
    registeredAt: "2026-06-01T15:40:00Z",
    kycAutofilled: true,
  },
  {
    id: "BIZ-1942",
    companyName: "Dhanbad Fuel Corp",
    ownerName: "Sunil Mahto",
    mobile: "7004123589",
    email: "sunil@dhnfuel.co.in",
    gstNumber: "20AAADF5518M2ZS",
    address: "Lodna Colliery Gate No. 3, Dhanbad, JH, 828111",
    aadhaarNum: "8827-3112-9849",
    panNum: "AAADF5518M",
    companyLicense: "LIC-FUEL-DHN-110",
    coalPermit: "EXPIRED-PERMIT-441-A",
    profilePhoto: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120",
    status: "Suspended",
    ocrVerifiedLog: "GST Status: ACTIVE. Alert: Local transport permit has expired on 2026-05-15.",
    aiAuditResult: "SUSPICIOUS - Identified 3 fake booking dispatch cancellations using mismatched mobile numbers. Route anomalies reported by GPS checkpoints.",
    registeredAt: "2026-05-18T08:12:00Z",
    kycAutofilled: false,
  }
];

const driverVerificationDb: DriverVerification[] = [
  {
    id: "DRV-1024",
    driverName: "Rajinder Yadav",
    mobile: "98734XXXXX",
    aadhaarNum: "3948-2849-1029",
    licenseNum: "DL-IND-JH1011",
    licenseExpiry: "2029-12-15",
    rcNum: "RC-JH10-9938294",
    insuranceNum: "INS-BHARTI-9921",
    insuranceExpiry: "2026-11-20",
    fitnessCertNum: "FIT-RTO-992",
    vehicleType: "hyva",
    vehicleNumber: "JH-10-AT-4782",
    truckPhoto: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=120",
    selfiePhoto: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120",
    faceMatchPercent: 98.4,
    status: "Verified",
    registeredAt: "2026-04-12T10:00:00Z",
  },
  {
    id: "DRV-1025",
    driverName: "Manpreet Singh",
    mobile: "98361XXXXX",
    aadhaarNum: "1029-4829-5928",
    licenseNum: "DL-IND-JH0202",
    licenseExpiry: "2028-08-11",
    rcNum: "RC-JH02-1102948",
    insuranceNum: "INS-NATIONAL-4821",
    insuranceExpiry: "2026-09-05",
    fitnessCertNum: "FIT-RTO-881",
    vehicleType: "pickup",
    vehicleNumber: "JH-02-B-9912",
    truckPhoto: "https://images.unsplash.com/photo-1532581291347-9c39cf10a73c?w=120",
    selfiePhoto: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120",
    faceMatchPercent: 96.1,
    status: "Verified",
    registeredAt: "2026-04-18T14:30:00Z",
  },
  {
    id: "DRV-1026",
    driverName: "Sanjeev Besra",
    mobile: "93041XXXXX",
    aadhaarNum: "8827-1129-3849",
    licenseNum: "DL-IND-JH1092",
    licenseExpiry: "2027-02-28",
    rcNum: "RC-JH10-384928",
    insuranceNum: "INS-RELIANCE-9102",
    insuranceExpiry: "2026-07-15",
    fitnessCertNum: "FIT-RTO-12948",
    vehicleType: "pickup",
    vehicleNumber: "JH-10-M-3211",
    truckPhoto: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=120",
    selfiePhoto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120",
    faceMatchPercent: 95.5,
    status: "Pending",
    registeredAt: "2026-06-01T09:15:00Z",
  },
  {
    id: "DRV-1027",
    driverName: "Karan Murmu",
    mobile: "8210492150",
    aadhaarNum: "4412-8821-4920",
    licenseNum: "DL-IND-JH10996",
    licenseExpiry: "2026-05-31", // EXPIRED Alert!
    rcNum: "RC-JH10-4492910",
    insuranceNum: "INS-CHOLA-8831",
    insuranceExpiry: "2026-05-20", // EXPIRED Alert!
    fitnessCertNum: "FIT-RTO-expired",
    vehicleType: "dumper",
    vehicleNumber: "JH-10-XY-9993",
    truckPhoto: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=120",
    selfiePhoto: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?w=120",
    faceMatchPercent: 41.2, // BAD face match matching threshold! Fraud alert!
    status: "Rejected",
    registeredAt: "2026-05-29T11:45:00Z",
  }
];

const securityLogsDb: SecuritySessionLog[] = [
  {
    id: "LOG-55102",
    phone: "9830412354",
    role: "customer",
    action: "OTP_VERIFY_SUCCESS",
    ipAddress: "103.241.12.83 (Dhanbad BroadBand)",
    deviceId: "Samsung Galaxy S23 Ultra (ONE-UI 6.0)",
    gpsCoords: "Lat: 23.7915, Lng: 86.4253 (Dhanbad Mine Siding)",
    timestamp: "2026-06-02T00:54:12Z",
    severity: "low",
    fraudFlags: []
  },
  {
    id: "LOG-55103",
    phone: "98361XXXXX",
    role: "driver",
    action: "OTP_VERIFY_SUCCESS",
    ipAddress: "223.109.43.12 (Jio 5G Cellnet)",
    deviceId: "Redmi Note 12 Pro (Android 13)",
    gpsCoords: "Lat: 23.6351, Lng: 85.5182 (Patratu Valley Highway)",
    timestamp: "2026-06-02T01:02:15Z",
    severity: "low",
    fraudFlags: []
  },
  {
    id: "LOG-55104",
    phone: "8210492150",
    role: "driver",
    action: "DEVICE_BIND_CONFLICT",
    ipAddress: "192.168.1.100 (DHN Cyber Cafe)",
    deviceId: "Unknown Chrome/Darwin Browser",
    gpsCoords: "Lat: 22.8427, Lng: 88.3610 (Kolkata Siding Border - Out of Range!)",
    timestamp: "2026-06-01T11:48:00Z",
    severity: "high",
    fraudFlags: ["SUSPICIOUS_GPS_RESTRICTION", "DEVICE_MIGRATION_BREACH"]
  },
  {
    id: "LOG-55105",
    phone: "7004123589",
    role: "customer",
    action: "OTP_VERIFY_LOCKOUT",
    ipAddress: "103.250.15.11 (Jharkhand VPN Provider)",
    deviceId: "Virtual Sandbox Client (Emulator)",
    gpsCoords: "Lat: 0.0, Lng: 0.0 (Anti-GPS Spoof Triggered)",
    timestamp: "2026-05-31T17:22:15Z",
    severity: "high",
    fraudFlags: ["VPN_DETECTED", "LOCKOUT_EXCEEDED", "GEOLOCATION_SPOOFING"]
  }
];

// OTP active validation cache
const activeOtpsMemoryStore: Record<string, { code: string; expiresAt: number; attempts: number }> = {};
const phoneLocksMemoryStore: Record<string, { lockedUntil: number; attemptsCount: number }> = {};

// -----------------------------------------------------------------------------
// EXPORTING APIS FOR SYNCHRONIZATION
// -----------------------------------------------------------------------------


// Helper to write initial collection data if empty
async function initializeCollectionIfEmpty<T extends { id: string }>(colName: string, defaultList: T[]) {
  if (!firestoreDb) return;
  try {
    const colRef = collection(firestoreDb, colName);
    const snap = await getDocs(query(colRef, limit(1)));
    if (snap.empty) {
      console.log(` -> Populating initial B2B fleet data for '${colName}' in firestore...`);
      for (const item of defaultList) {
        await setDoc(doc(firestoreDb, colName, item.id), item);
      }
    }
  } catch (error) {
    console.warn(`Could not sync initializer collection '${colName}':`, error);
  }
}

// Seeding helper execution on startup
async function seedFirestoreCollections() {
  if (!firestoreDb) return;
  console.log("✓ Seeding Firestore data collections if they do not exist...");
  await initializeCollectionIfEmpty("bookings", state.bookings);
  await initializeCollectionIfEmpty("drivers", state.drivers);
  await initializeCollectionIfEmpty("fuelLogs", state.fuelLogs);
  await initializeCollectionIfEmpty("alerts", state.alerts);
  await initializeCollectionIfEmpty("businesses", businessDb);
  await initializeCollectionIfEmpty("securityLogs", securityLogsDb);
  
  try {
    const configDoc = await getDoc(doc(firestoreDb, "config", "global"));
    if (!configDoc.exists()) {
      await setDoc(doc(firestoreDb, "config", "global"), state.config);
    }
  } catch (err) {
    console.warn("Could not seed global config doc in Firestore:", err);
  }
}

// Kick off async seeding
seedFirestoreCollections();

// -----------------------------------------------------------------------------
// EXPORTING APIS FOR SYNCHRONIZATION
// -----------------------------------------------------------------------------


// Fetch state
app.get("/api/state", async (req, res) => {
  if (!firestoreDb) {
    return res.json(state);
  }
  try {
    const bookingsSnap = await getDocs(collection(firestoreDb, "bookings"));
    const driversSnap = await getDocs(collection(firestoreDb, "drivers"));
    const fuelLogsSnap = await getDocs(collection(firestoreDb, "fuelLogs"));
    const alertsSnap = await getDocs(collection(firestoreDb, "alerts"));
    
    const bookings = bookingsSnap.docs.map(d => d.data()) as Booking[];
    const drivers = driversSnap.docs.map(d => d.data()) as Driver[];
    const fuelLogs = fuelLogsSnap.docs.map(d => d.data()) as FuelLog[];
    const alerts = alertsSnap.docs.map(d => d.data()) as SystemAlert[];
    
    // Sort descending by timestamp/date for the lists
    bookings.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    drivers.sort((a, b) => b.rating - a.rating);
    fuelLogs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    alerts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // Fetch config
    const configDoc = await getDoc(doc(firestoreDb, "config", "global"));
    let config = state.config;
    if (configDoc.exists()) {
      config = { ...config, ...configDoc.data() };
    } else {
      await setDoc(doc(firestoreDb, "config", "global"), config);
    }
    
    // Keep in-memory state updated for chatbot referencing compatibility
    state.bookings = bookings;
    state.drivers = drivers;
    state.fuelLogs = fuelLogs;
    state.alerts = alerts;
    state.config = config;

    res.json({ bookings, drivers, fuelLogs, alerts, config });
  } catch (err) {
    console.warn("Firestore state grab warning (falling back to in-memory):", err);
    res.json(state);
  }
});

// Update global config (Admin Surge or Diesel Control)
app.post("/api/admin/config", async (req, res) => {
  const { surgeMultiplier, isMonsoonActive, baseDieselPrice, commissionPercent, geofenceEnabled } = req.body;
  
  if (surgeMultiplier !== undefined) state.config.surgeMultiplier = Number(surgeMultiplier);
  if (isMonsoonActive !== undefined) state.config.isMonsoonActive = !!isMonsoonActive;
  if (baseDieselPrice !== undefined) state.config.baseDieselPrice = Number(baseDieselPrice);
  if (commissionPercent !== undefined) state.config.commissionPercent = Number(commissionPercent);
  if (geofenceEnabled !== undefined) state.config.geofenceEnabled = !!geofenceEnabled;

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, "config", "global"), state.config);
    } catch (err) {
      console.warn("Failed to write updated config to Firestore:", err);
    }
  }

  res.json({ message: "Admin configuration updated.", config: state.config });
});

// Create brand new booking (Customer)
app.post("/api/bookings", async (req, res) => {
  const {
    customerName,
    customerPhone,
    pickupName,
    dropName,
    pickupCounty,
    dropCounty,
    vehicleType,
    weightTons,
    challanNumber,
    coalPassId,
    coalPassDocName,
    paymentMethod,
    distanceKm
  } = req.body;

  if (!customerName || !pickupName || !dropName || !vehicleType) {
    return res.status(400).json({ error: "Required fields are missing." });
  }

  const rates = VEHICLE_RATES[vehicleType as VehicleType] || VEHICLE_RATES["mini_truck"];
  const finalDistance = Number(distanceKm) || 15;
  
  // High-fidelity calculation engine
  let rawCost = rates.base + (rates.perKm * finalDistance);
  rawCost = rawCost * state.config.surgeMultiplier;
  if (state.config.isMonsoonActive) rawCost *= 1.1; // monsoon hill surge

  const tons = Number(weightTons) || 1;
  const isOverloaded = tons > rates.limit;
  
  // Calculate overload fines & tolls
  let finesEstimate = 0;
  if (isOverloaded) {
    finesEstimate = Math.ceil((tons - rates.limit) * 1200); // INR 1200 per extra ton
  }

  // Siding toll estimate based on counties
  let tollTaxEstimate = 0;
  if (pickupCounty === "Asansol" || dropCounty === "Asansol") {
    tollTaxEstimate = 140; // border crossing tax
  } else if (pickupCounty !== dropCounty) {
    tollTaxEstimate = 80;
  }

  const costEstimate = Math.round(rawCost);
  const newBookingId = `BK-${Math.floor(1000 + Math.random() * 9000)}`;

  // Smart dispatching: Auto find first online & matching driver that is not busy
  const matchedDriver = state.drivers.find(
    d => d.online && !d.active && d.docsApproved && d.vehicleType === vehicleType
  );

  const newBooking: Booking = {
    id: newBookingId,
    customerName,
    customerPhone: customerPhone || "993415XXXX",
    pickupName,
    dropName,
    pickupCounty: pickupCounty || "Dhanbad",
    dropCounty: dropCounty || "Dhanbad",
    vehicleType: vehicleType as VehicleType,
    status: matchedDriver ? "accepted" : "pending",
    weightTons: tons,
    isOverloaded,
    challanNumber: challanNumber || `CH-${Math.floor(100000 + Math.random() * 900000)}`,
    coalPassId: coalPassId || undefined,
    coalPassDocName: coalPassDocName || undefined,
    distanceKm: finalDistance,
    costEstimate,
    tollTaxEstimate,
    finesEstimate,
    etaMinutes: matchedDriver ? 12 : 25,
    driverId: matchedDriver?.id,
    driverName: matchedDriver?.name,
    driverPhone: matchedDriver?.phone,
    driverVehicleNumber: matchedDriver?.vehicleNumber,
    paymentStatus: "pending",
    paymentMethod: paymentMethod || "wallet",
    timestamp: new Date().toISOString(),
  };

  // Persist
  state.bookings.unshift(newBooking);

  if (matchedDriver) {
    // Lock driver
    matchedDriver.active = true;
  }

  // Generate real-time system alerts to keep the admin dashboard highly active
  let alert1: any = null;
  let alert2: any = null;

  if (isOverloaded) {
    const alertId = `ALT-${Math.floor(100 + Math.random() * 900)}`;
    alert1 = {
      id: alertId,
      type: "overload",
      messageEn: `Overload alert for ${newBookingId}: ${tons} Tons on ${vehicleType} (Limit: ${rates.limit} Tons). Automatic safety warning sent to driver.`,
      messageHi: `${newBookingId} के लिए ओवरलोड चेतावनी: ${vehicleType} पर ${tons} टन लोड किया गया (सीमा: ${rates.limit} टन)।`,
      severity: "high",
      timestamp: new Date().toISOString(),
      bookingId: newBookingId
    };
    state.alerts.unshift(alert1);
  }

  if (pickupCounty === "Asansol" || dropCounty === "Asansol") {
    const alertId = `ALT-${Math.floor(100 + Math.random() * 900)}`;
    alert2 = {
      id: alertId,
      type: "geofence",
      messageEn: `Cargo unit ${newBookingId} selected Border Transit route. Mandatory checking active at Chirkunda Gate.`,
      messageHi: `कार्गो यूनिट ${newBookingId} ने बाहरी सीमा मार्ग चुना। चिरकुंडा चेकपोस्ट पर अनिवार्य जांच सक्रिय।`,
      severity: "low",
      timestamp: new Date().toISOString(),
      bookingId: newBookingId
    };
    state.alerts.unshift(alert2);
  }

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, "bookings", newBookingId), newBooking);
      if (matchedDriver) {
        await updateDoc(doc(firestoreDb, "drivers", matchedDriver.id), { active: true });
      }
      if (alert1) {
        await setDoc(doc(firestoreDb, "alerts", alert1.id), alert1);
      }
      if (alert2) {
        await setDoc(doc(firestoreDb, "alerts", alert2.id), alert2);
      }
    } catch (err) {
      console.warn("Failed to write booking state to Firestore:", err);
    }
  }

  res.json({ message: "Booking registered successfully", booking: newBooking });
});

// Update booking action (Accept, Unload, Pay, Rate, cancel)
app.post("/api/bookings/:id/action", async (req, res) => {
  const { id } = req.params;
  const { action, driverId, rating, feedback } = req.body;

  let booking = state.bookings.find(b => b.id === id);
  if (firestoreDb) {
    try {
      const bDoc = await getDoc(doc(firestoreDb, "bookings", id));
      if (bDoc.exists()) {
        booking = bDoc.data() as Booking;
      }
    } catch (err) {
      console.warn("Could not fetch booking from firestore, using in-memory:", err);
    }
  }

  if (!booking) {
    return res.status(404).json({ error: "Booking not found." });
  }

  let matchedDriverToUpdate: any = null;

  switch (action) {
    case "accept": {
      const driver = state.drivers.find(d => d.id === driverId);
      if (driver) {
        driver.active = true;
        booking.driverId = driver.id;
        booking.driverName = driver.name;
        booking.driverPhone = driver.phone;
        booking.driverVehicleNumber = driver.vehicleNumber;
        booking.status = "accepted";
        booking.etaMinutes = 10;
        matchedDriverToUpdate = driver;
      }
      break;
    }
    case "loading":
      booking.status = "loading";
      break;
    case "en_route":
      booking.status = "en_route";
      booking.etaMinutes = Math.ceil(booking.distanceKm * 1.5);
      break;
    case "unloading":
      booking.status = "unloading";
      break;
    case "completed": {
      booking.status = "completed";
      booking.etaMinutes = 0;
      // Credit driver earnings
      const driver = state.drivers.find(d => d.id === booking.driverId);
      if (driver) {
        driver.active = false;
        driver.totalTrips += 1;
        const commission = Math.round(booking.costEstimate * (state.config.commissionPercent / 100));
        const netDriverEarnings = booking.costEstimate - commission;
        driver.earningsToday += netDriverEarnings;
        driver.earningsThisWeek += netDriverEarnings;
        matchedDriverToUpdate = driver;
      }
      break;
    }
    case "pay":
      booking.paymentStatus = "paid";
      break;
    case "cancel": {
      booking.status = "cancelled";
      const driver = state.drivers.find(d => d.id === booking.driverId);
      if (driver) {
        driver.active = false;
        matchedDriverToUpdate = driver;
      }
      break;
    }
    case "rate":
      booking.rating = Number(rating) || 5;
      booking.feedback = feedback || "";
      // adjust driver rating
      const drv = state.drivers.find(d => d.id === booking.driverId);
      if (drv) {
         drv.rating = Number(((drv.rating * 9 + booking.rating) / 10).toFixed(1));
         matchedDriverToUpdate = drv;
      }
      break;
  }

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, "bookings", id), booking);
      if (matchedDriverToUpdate) {
        await setDoc(doc(firestoreDb, "drivers", matchedDriverToUpdate.id), matchedDriverToUpdate);
      }
    } catch (err) {
      console.warn("Failed to update booking action in Firestore:", err);
    }
  }

  res.json({ message: "Booking action updated successfully.", booking });
});

// Toggle driver duty status
app.post("/api/drivers/offline-toggle", async (req, res) => {
  const { driverId, online } = req.body;
  const driver = state.drivers.find(d => d.id === driverId);
  if (!driver) {
    return res.status(404).json({ error: "Driver not found." });
  }

  driver.online = !!online;
  // If driver goes offline, unlock active trips safely
  if (!driver.online) {
    driver.active = false;
  }

  if (firestoreDb) {
    try {
      await updateDoc(doc(firestoreDb, "drivers", driverId), {
        online: driver.online,
        active: driver.active
      });
    } catch (err) {
      console.warn("Failed to write duty status to Firestore driver:", err);
    }
  }

  res.json({ message: `Driver status switched to ${driver.online ? 'Online' : 'Offline'}`, driver });
});

// Driver registration approval by Admin
app.post("/api/drivers/approve", (req, res) => {
  const { driverId, approve } = req.body;
  const driver = state.drivers.find(d => d.id === driverId);
  if (!driver) return res.status(404).json({ error: "Driver not found." });

  driver.docsApproved = !!approve;
  res.json({ message: `Driver verification status set to ${driver.docsApproved}`, driver });
});

// Create new driver onboarding account
app.post("/api/drivers/register", (req, res) => {
  const { name, phone, vehicleType, vehicleNumber, aadhaarNum, licenseNum, rcNum } = req.body;

  if (!name || !phone || !vehicleType || !vehicleNumber) {
    return res.status(400).json({ error: "Required fields are missing." });
  }

  const newDriverId = `drv_${Math.floor(10 + Math.random() * 90)}`;
  const newDriver: Driver = {
    id: newDriverId,
    name,
    phone,
    vehicleType: vehicleType as VehicleType,
    vehicleNumber,
    online: true,
    active: false,
    rating: 5.0,
    docsApproved: false, // Must be approved by manual admin checks to begin working
    aadhaarNum: aadhaarNum || "Pending Upload",
    licenseNum: licenseNum || "Pending",
    rcNum: rcNum || "Pending RC",
    earningsThisWeek: 0,
    earningsToday: 0,
    totalTrips: 0,
    currentLat: 23.795,
    currentLng: 86.430,
  };

  state.drivers.push(newDriver);
  
  // Admin alert
  state.alerts.unshift({
    id: `ALT-${Math.floor(100 + Math.random() * 900)}`,
    type: "delay",
    messageEn: `New driver registration pending approval: ${name} (${vehicleNumber})`,
    messageHi: `नया ड्राइवर पंजीकरण सत्यापन प्रक्रिया में है: ${name} (${vehicleNumber})`,
    severity: "medium",
    timestamp: new Date().toISOString()
  });

  res.json({ message: "Registration submitted successfully. Pending admin review.", driver: newDriver });
});

// Logging fuel details (Driver)
app.post("/api/drivers/fuel", (req, res) => {
  const { driverId, liters, costPerLiter, mileageOdometer } = req.body;
  
  const finalLiters = Number(liters) || 10;
  const finalPrice = Number(costPerLiter) || state.config.baseDieselPrice;
  const totalCost = Math.round(finalLiters * finalPrice * 100) / 100;

  const newFuelLog: FuelLog = {
    id: `FL-${Math.floor(100 + Math.random() * 900)}`,
    driverId: driverId || "drv_01",
    liters: finalLiters,
    costPerLiter: finalPrice,
    totalCost,
    date: new Date().toISOString().split('T')[0],
    mileageOdometer: Number(mileageOdometer) || 20500
  };

  state.fuelLogs.unshift(newFuelLog);
  res.json({ message: "Fuel cost registered successfully.", log: newFuelLog });
});

// -----------------------------------------------------------------------------
// SERVER-SIDE GEMINI API INTEGRATIONS
// -----------------------------------------------------------------------------

// Interactive chatbot & voice-booking converter (Customer support, route suggestion)
app.post("/api/ai/chatbot", async (req, res) => {
  const { prompt, chatHistory, language } = req.body;
  const isHindi = language === "hi";

  if (!prompt) {
    return res.status(400).json({ error: "Prompt is required." });
  }

  // System instructions explaining the geography, role of Coal-Belt Logistics and expected output schema
  const systemInstruction = 
    `You are the Coal-Belt Logistics AI Dispatching Assistant, an expert in heavy mining transport around Dhanbad (Katras, Jharia, Bastacolla Siding), Ramgarh (Patratu), Asansol (Jharkhand border gate), and Bokaro Steel City.\n` +
    `Your goal is to answer client queries, route status questions, pricing advice, overload safety tips, and crucially support CONVERSATIONAL BOOKING.\n\n` +
    `Rules:\n` +
    `1. Be helpful, professional, and use a friendly, confident tone. Write in ${isHindi ? "Hindi (with slate-latin terms)" : "English with subtle regional terms like 'Siding', 'Challan', 'Pass', 'Rungta', 'Pit' where friendly"}.\n` +
    `2. If the user intention looks like they want to BOOK a truck (e.g., 'Book a dumper', 'Chota Hathi for 4 tons', 'Dhanbad to Patratu Jharia road with coke load'), format your guidance beautifully and end your response with a parsed JSON payload wrapper. Do NOT use markdown brackets for the JSON; write it as a clean standard code block.\n` +
    `Let's extract: pickupCounty, dropCounty, vehicleType (must be 'mini_truck', 'pickup', 'tata_407', 'dumper', 'hyva', 'trailer'), weightTons, loadDescription, and challanNumber.\n\n` +
    `Example of parsed booking wrapper at the end of your response text if appropriate:\n` +
    `[BOOK_DATA]\n` +
    `{\n` +
    `  "pickupCounty": "Dhanbad",\n` +
    `  "dropCounty": "Ramgarh",\n` +
    `  "vehicleType": "dumper",\n` +
    `  "weightTons": 8.5\n` +
    `}\n` +
    `[/BOOK_DATA]\n\n` +
    `Ensure you speak clearly. Keep response size under 200 words.`;

  // Fallback simulator if no Gemini API Key is loaded
  if (!ai) {
    let mockResult = "";
    const p = prompt.toLowerCase();
    
    if (p.includes("book") || p.includes("बुकिंग") || p.includes("भेजें") || p.includes("चाहिए")) {
      // Suggest automatic parsing
      if (isHindi) {
        mockResult = `जी हाँ! मैंने आपका बुकिंग अनुरोध समझ लिया है। कोयला-बेल्ट बुकिंग प्रणाली सक्रिय है। मैं धनबाद से रामगढ़ या आसनसोल के लिए उचित व्यवस्था देख रहा हूँ।\n\n[BOOK_DATA]\n{\n  "pickupCounty": "Dhanbad",\n  "dropCounty": "Ramgarh",\n  "vehicleType": "dumper",\n  "weightTons": 10\n}\n[/BOOK_DATA]`;
      } else {
        mockResult = `Sure! I have captured your transport order request. I will coordinate with available siding dumpers coordinates for your delivery.\n\n[BOOK_DATA]\n{\n  "pickupCounty": "Dhanbad",\n  "dropCounty": "Ramgarh",\n  "vehicleType": "dumper",\n  "weightTons": 10\n}\n[/BOOK_DATA]`;
      }
    } else if (p.includes("price") || p.includes("किराया") || p.includes("डीजल")) {
      mockResult = isHindi 
        ? "कोयला बेल्ट मुख्य सड़कों पर टोल टैक्स और ओवरलोड के आधार पर किराया तय होता है। वर्तमान डीजल मूल्य ₹94.35 प्रति लीटर संकलित है। ओवरलोड वहन करने पर सरकारी आरटीओ चेकिंग जुर्माना लग सकता है।"
        : "Rates are based around diesel levels (currently ₹94.35/L) and monsoon mountain surges. Overloading vehicles beyond recommended safe tonnage causes heavy fines of ₹1200 per extra ton.";
    } else {
       mockResult = isHindi
        ? "कीमती ग्राहक, धनबाद और रामगढ़ कोयला खान क्षेत्रों में आपकी सेवा करने के लिए कोयला-बेल्ट लॉजिस्टिक्स सहायक हाजिर है। मार्ग अवरोध, चालान की स्थिति, या वाहन बुक करने के बारे में पूछें।"
        : "Welcome to Coal-Belt Logistics Support. How can I assist you with your Jharia Washery transits, Patratu Power siding, or Chirkunda checkpost border crossings today?";
    }
    
    return res.json({ text: mockResult });
  }

  // Real Gemini Call
  try {
    const formattedHistory = (chatHistory || []).map((m: any) => ({
      role: m.sender === "user" ? "user" : "model",
      parts: [{ text: m.text }]
    }));

    // Add current query
    formattedHistory.push({
      role: "user",
      parts: [{ text: prompt }]
    });

    // Query generative model
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedHistory.map((h: any) => h.parts[0].text).join("\n"),
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini chatbot API error:", error);
    res.status(500).json({ error: "Gemini server response failed.", details: error.message });
  }
});

// Price predict and seasonal smart routing route
app.post("/api/ai/price-predict", async (req, res) => {
  const { pickup, drop, vehicleType, tons } = req.body;

  const systemInstruction = 
    `You are the Coal-Belt B2B Pricing Analytics Engine. Calculate seasonal price, monsoon risk level, transport delays (on Ghat/siding areas), and official checking probability. Return a short, punchy advice of 3 sentences.`;

  const prompt = `Formulate shipping prediction for a ${vehicleType} transporting ${tons} Tons of cargo from ${pickup} to ${drop}.`;

  if (!ai) {
    return res.json({
      prediction: `Weather conditions are normal. Siding transit time is estimated at 45 minutes. Toll checking risk is average. Surcharge multiplier active at 1.15x.`
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: { systemInstruction },
    });
    res.json({ prediction: response.text });
  } catch (err: any) {
    res.json({ prediction: "Normal weather coordinates. Transit flow estimated at 55 minutes." });
  }
});


// -----------------------------------------------------------------------------
// B2B ENTERPRISE AUTHENTICATION & SECURITY ENDPOINTS
// -----------------------------------------------------------------------------

// 1. Get security logs and verification DBs
app.get("/api/security/records", async (req, res) => {
  if (!firestoreDb) {
    return res.json({
      businesses: businessDb,
      drivers: driverVerificationDb,
      logs: securityLogsDb,
    });
  }

  try {
    const bizSnap = await getDocs(collection(firestoreDb, "businesses"));
    const driversSnap = await getDocs(collection(firestoreDb, "drivers"));
    const logsSnap = await getDocs(collection(firestoreDb, "securityLogs"));
    
    const businesses = bizSnap.docs.map(d => d.data());
    const drivers = driversSnap.docs.map(d => d.data());
    const logs = logsSnap.docs.map(d => d.data());

    // Sort appropriately
    try {
      businesses.sort((a: any, b: any) => new Date(b.registeredAt || b.timestamp || 0).getTime() - new Date(a.registeredAt || a.timestamp || 0).getTime());
      drivers.sort((a: any, b: any) => new Date(b.registeredAt || b.timestamp || 0).getTime() - new Date(a.registeredAt || a.timestamp || 0).getTime());
      logs.sort((a: any, b: any) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
    } catch (e) {
      // safe bypass if dates parse badly
    }

    res.json({
      businesses,
      drivers,
      logs,
    });
  } catch (err) {
    console.warn("Failed to retrieve security records from Firestore, using memory:", err);
    res.json({
      businesses: businessDb,
      drivers: driverVerificationDb,
      logs: securityLogsDb,
    });
  }
});

// 2. Request OTP Code
app.post("/api/security/otp/request", (req, res) => {
  const { phone, role } = req.body;
  if (!phone) {
    return res.status(400).json({ error: "Mobile number is required." });
  }

  // Check locks
  const lock = phoneLocksMemoryStore[phone];
  if (lock && lock.lockedUntil > Date.now()) {
    const remains = Math.ceil((lock.lockedUntil - Date.now()) / 1000);
    return res.status(423).json({ error: `Account locked after too many failed attempts. Try again in ${remains} seconds.` });
  }

  // Generate 5-digit security code
  const code = Math.floor(10000 + Math.random() * 90000).toString();
  activeOtpsMemoryStore[phone] = {
    code,
    expiresAt: Date.now() + 180000, // 3 minutes expiration
    attempts: 0
  };

  // Log Security Activity
  const logId = `LOG-${Math.floor(10000 + Math.random() * 90000)}`;
  securityLogsDb.unshift({
    id: logId,
    phone,
    role: role || 'customer',
    action: 'OTP_REQUEST',
    ipAddress: req.headers['x-forwarded-for'] as string || req.ip || '103.250.21.84',
    deviceId: req.headers['user-agent'] || 'Unspecified Mobile Browser',
    gpsCoords: "Lat: 23.791, Lng: 86.425 (Mining Area Geo-Restrict Validated)",
    timestamp: new Date().toISOString(),
    severity: 'low',
    fraudFlags: []
  });

  res.json({
    message: "OTP sent successfully.",
    code, // returned so simulator GUI can show SMS interceptor
  });
});

// 3. Verify OTP Code
app.post("/api/security/otp/verify", (req, res) => {
  const { phone, code, role, deviceId, gpsCoords } = req.body;
  
  if (!phone || !code) {
    return res.status(400).json({ error: "Phone and verification code are required." });
  }

  // Check locks
  const lock = phoneLocksMemoryStore[phone];
  if (lock && lock.lockedUntil > Date.now()) {
    return res.status(423).json({ error: "This mobile line is suspended for security." });
  }

  const activeOtp = activeOtpsMemoryStore[phone];
  if (!activeOtp || activeOtp.expiresAt < Date.now()) {
    return res.status(400).json({ error: "OTP expired or not requested. Please try again." });
  }

  if (activeOtp.code !== code) {
    activeOtp.attempts += 1;
    if (activeOtp.attempts >= 4) {
      phoneLocksMemoryStore[phone] = {
        lockedUntil: Date.now() + 300000, // 5 minutes lock
        attemptsCount: activeOtp.attempts
      };
      
      securityLogsDb.unshift({
        id: `LOG-${Math.floor(10000 + Math.random() * 90000)}`,
        phone,
        role: role || 'customer',
        action: 'OTP_VERIFY_LOCKOUT',
        ipAddress: req.ip || '103.250.21.84',
        deviceId: deviceId || 'Suspicious Hardware Emulator',
        gpsCoords: gpsCoords || 'Lat: 0.0, Lng: 0.0',
        timestamp: new Date().toISOString(),
        severity: 'high',
        fraudFlags: ['OTP_BRUTEFORCE_ATTEMPT', 'ACCOUNT_LOCKOUT']
      });

      return res.status(423).json({ error: "Maximum attempts reached. Account locked for 5 minutes." });
    }
    return res.status(400).json({ error: `Incorrect verification code. Attempts left: ${4 - activeOtp.attempts}` });
  }

  // Clear OTP on success
  delete activeOtpsMemoryStore[phone];

  // IP Geofence Restriction check (Mining district validator)
  const isSpoofedGPS = gpsCoords && (gpsCoords.includes("0.0") || gpsCoords.includes("999"));
  const fraudFlags: string[] = [];
  if (isSpoofedGPS) {
    fraudFlags.push("GEOLOCATION_SPOOFING");
  }

  // Sign mock JWT session token
  const token = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.coal_session_${phone}_${Date.now()}`;

  // Log Successful Audit
  securityLogsDb.unshift({
    id: `LOG-${Math.floor(10000 + Math.random() * 90000)}`,
    phone,
    role: role || 'customer',
    action: 'OTP_VERIFY_SUCCESS',
    ipAddress: req.ip || '103.241.12.83',
    deviceId: deviceId || 'Chrome Mobile (Android)',
    gpsCoords: gpsCoords || 'Lat: 23.7915, Lng: 86.4253',
    timestamp: new Date().toISOString(),
    severity: isSpoofedGPS ? 'high' : 'low',
    fraudFlags
  });

  // Fetch or create customer/driver record matching this phone
  let profile: any = null;
  if (role === 'customer') {
    profile = businessDb.find(b => b.mobile === phone);
    if (!profile) {
      // Return a blank template for registration onboarding
      return res.json({
        message: "OTP Verified. Account is unregistered. Proceeding to B2B business KYC.",
        token,
        needRegistration: true,
        phone,
      });
    }
  } else if (role === 'driver') {
    profile = driverVerificationDb.find(d => d.mobile === phone || d.mobile.replace(/\D/g, '').endsWith(phone.replace(/\D/g, '')));
    if (!profile) {
      // Find in global state.drivers array in case it was created by legacy register API
      const stateDrv = state.drivers.find(d => d.phone.replace(/\D/g, '').endsWith(phone.replace(/\D/g, '')));
      if (stateDrv) {
        // Map it
        profile = {
          id: `DRV-${Math.floor(1000 + Math.random() * 9000)}`,
          driverName: stateDrv.name,
          mobile: phone,
          aadhaarNum: stateDrv.aadhaarNum,
          licenseNum: stateDrv.licenseNum,
          licenseExpiry: "2028-11-20",
          rcNum: stateDrv.rcNum,
          insuranceNum: "INS-NATIONAL-3312",
          insuranceExpiry: "2026-12-05",
          fitnessCertNum: "FIT-RTO-2319",
          vehicleType: stateDrv.vehicleType,
          vehicleNumber: stateDrv.vehicleNumber,
          truckPhoto: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=120",
          selfiePhoto: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120",
          faceMatchPercent: 97.5,
          status: stateDrv.docsApproved ? "Verified" : "Pending",
          registeredAt: new Date().toISOString()
        };
        driverVerificationDb.push(profile);
      } else {
        return res.json({
          message: "OTP Verified. Driver unregistered. Proceeding to KYC onboarding.",
          token,
          needRegistration: true,
          phone,
        });
      }
    }
  }

  // For Suspended Check
  if (profile && profile.status === 'Suspended') {
    securityLogsDb.unshift({
      id: `LOG-${Math.floor(10000 + Math.random() * 90000)}`,
      phone,
      role,
      action: 'SUSPENDED_ACCESS_ATTEMPT',
      ipAddress: req.ip || '103.250.21.84',
      deviceId: deviceId || 'Banned Terminal Machine',
      gpsCoords: gpsCoords || 'Lat: 23.7915, Lng: 86.4253',
      timestamp: new Date().toISOString(),
      severity: 'high',
      fraudFlags: ['TEMPER_WITH_SUSPENDED_SESSION']
    });
    return res.status(403).json({ error: "Access Denied. Your B2B operator account has been suspended by Haldia-Dhanbad Siding safety admin." });
  }

  res.json({
    message: "OTP Authentication success.",
    token,
    profile,
    needRegistration: false
  });
});

// 4. Register corporate business KYC with AI OCR parser
app.post("/api/security/business/register", async (req, res) => {
  const {
    companyName, ownerName, mobile, email, gstNumber,
    address, aadhaarNum, panNum, companyLicense, coalPermit, profilePhoto
  } = req.body;

  if (!companyName || !ownerName || !mobile || !gstNumber || !aadhaarNum) {
    return res.status(400).json({ error: "Compulsory registration data is missing." });
  }

  // Simulate automated document AI checks and OCR reading logs
  const isGstRealistic = gstNumber.length === 15;
  const isPanRealistic = panNum ? panNum.length === 10 : false;
  
  const ocrLog = `[DOCUMENT AI ENGINE OCR REPORT]
- GSTIN ${gstNumber}: CONFIRMED ACTIVE on Jharkhand GST portal under Class 'Coal Wholesale Trading'.
- PAN ${panNum || 'N/A'}: MATCHED owner '${ownerName}' via credit checks.
- Aadhaar ${aadhaarNum}: Verified via simulated biometrics.
- Coal Pass Permit: Verified via Coal Controller General state directory.`;

  const aiCheckReport = `OCR MATCH: 98.7% - Approved for automatic provisional B2B trading credentials. License and permit verified. No state tax defaults found.`;

  const newBizId = `BIZ-${Math.floor(1000 + Math.random() * 9000)}`;
  const newBizRecord: BusinessVerification = {
    id: newBizId,
    companyName,
    ownerName,
    mobile,
    email: email || `${ownerName.toLowerCase().replace(/ /g, '')}@coalsiding.in`,
    gstNumber,
    address: address || "Dhanbad Coal Belt Siding Zone, Jharkhand",
    aadhaarNum,
    panNum: panNum || "",
    companyLicense: companyLicense || "LIC-DHN-PROV-11",
    coalPermit: coalPermit || "PERMIT-GEN-COAL",
    profilePhoto: profilePhoto || "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=120",
    status: 'Pending', // Starts as pending, awaiting admin approval
    ocrVerifiedLog: ocrLog,
    aiAuditResult: aiCheckReport,
    registeredAt: new Date().toISOString(),
    kycAutofilled: true
  };

  businessDb.unshift(newBizRecord);

  // Add a state.alerts
  const alertId = `ALT-${Math.floor(100 + Math.random() * 900)}`;
  const alert: SystemAlert = {
    id: alertId,
    type: "delay",
    messageEn: `New Business B2B KYC pending approval: ${companyName} (${ownerName})`,
    messageHi: `नई व्यापार केवाईसी पंजीकरण सत्यापन प्रक्रिया: ${companyName} (${ownerName})`,
    severity: "medium",
    timestamp: new Date().toISOString()
  };
  state.alerts.unshift(alert);

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, "businesses", newBizId), newBizRecord);
      await setDoc(doc(firestoreDb, "alerts", alertId), alert);
    } catch (err) {
      console.warn("Failed to write business KYC record to Firestore:", err);
    }
  }

  res.json({
    message: "B2B Onboarding docs submitted successfully. Awaiting Admin Approval.",
    record: newBizRecord
  });
});

// 5. Register driver verification
app.post("/api/security/driver/register", async (req, res) => {
  const {
    driverName, mobile, aadhaarNum, licenseNum, licenseExpiry,
    rcNum, insuranceNum, insuranceExpiry, fitnessCertNum, vehicleType, vehicleNumber, truckPhoto, selfiePhoto
  } = req.body;

  if (!driverName || !mobile || !licenseNum || !vehicleNumber) {
    return res.status(400).json({ error: "Compulsory driver registration data is missing." });
  }

  // Face match and license expiration checks
  const isLicenseExpiredActive = licenseExpiry && new Date(licenseExpiry) < new Date();
  const faceMatchPercent = Math.round(92 + Math.random() * 7 * 10) / 10; // high confidence simulation

  const newDriverVerId = `DRV-${Math.floor(1000 + Math.random() * 9000)}`;
  const newDriverVer: DriverVerification = {
    id: newDriverVerId,
    driverName,
    mobile,
    aadhaarNum: aadhaarNum || "Pending Input",
    licenseNum,
    licenseExpiry: licenseExpiry || "2029-01-01",
    rcNum: rcNum || "Pending RC Entry",
    insuranceNum: insuranceNum || "Pending INS",
    insuranceExpiry: insuranceExpiry || "2027-01-01",
    fitnessCertNum: fitnessCertNum || "FIT-OK-904",
    vehicleType: vehicleType || "dumper",
    vehicleNumber,
    truckPhoto: truckPhoto || "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=120",
    selfiePhoto: selfiePhoto || "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120",
    faceMatchPercent,
    status: isLicenseExpiredActive ? 'Rejected' : 'Pending', // directly reject if expired
    registeredAt: new Date().toISOString()
  };

  driverVerificationDb.unshift(newDriverVer);

  // Sync with main state drivers list so driver app recognizes it
  const mainDriverId = `drv_${Math.floor(10 + Math.random() * 90)}`;
  const mainDriver: Driver = {
    id: mainDriverId,
    name: driverName,
    phone: mobile,
    vehicleType: (vehicleType || "dumper") as VehicleType,
    vehicleNumber,
    online: true,
    active: false,
    rating: 5.0,
    docsApproved: false, // Must wait for admin approve
    aadhaarNum: aadhaarNum || "Awaiting Verification",
    licenseNum,
    rcNum: rcNum || "Awaiting RC",
    earningsThisWeek: 0,
    earningsToday: 0,
    totalTrips: 0,
    currentLat: 23.785,
    currentLng: 86.432
  };
  state.drivers.push(mainDriver);

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, "drivers", mainDriverId), mainDriver);
    } catch (err) {
      console.warn("Failed to write driver record to Firestore:", err);
    }
  }

  res.json({
    message: "Driver KYC onboarding documents submitted.",
    record: newDriverVer
  });
});

// 6. Secure Admin Action (Verify/Reject/Suspend/Blacklist)
app.post("/api/security/admin/action", async (req, res) => {
  const { id, type, target, remarks } = req.body; // target: 'business' | 'driver'
  
  if (!id || !type || !target) {
    return res.status(400).json({ error: "Missing action details." });
  }

  if (target === 'business') {
    const biz = businessDb.find(b => b.id === id);
    if (!biz) return res.status(404).json({ error: "Business record not found." });

    if (type === 'approve') {
      biz.status = 'Verified';
      biz.ocrVerifiedLog += `\n[RESOLVED] Approved by coal controller admin on ${new Date().toISOString()}`;
    } else if (type === 'reject') {
      biz.status = 'Rejected';
    } else if (type === 'suspend') {
      biz.status = 'Suspended';
    }

    if (firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, "businesses", id), biz);
      } catch (err) {
        console.warn("Failed to update business status in Firestore:", err);
      }
    }

    return res.json({ message: `Business ${biz.companyName} set to status ${biz.status}`, record: biz });
  } else if (target === 'driver') {
    const drv = driverVerificationDb.find(d => d.id === id);
    if (!drv) return res.status(404).json({ error: "Driver verification record not found." });

    let stateDrv = state.drivers.find(d => d.phone.endsWith(drv.mobile.substring(drv.mobile.length - 5)) || d.name === drv.driverName);

    if (type === 'approve') {
      drv.status = 'Verified';
      if (stateDrv) stateDrv.docsApproved = true;
    } else if (type === 'reject') {
      drv.status = 'Rejected';
    } else if (type === 'suspend') {
      drv.status = 'Suspended';
      if (stateDrv) stateDrv.docsApproved = false;
    }

    if (firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, "drivers", drv.id), drv);
        if (stateDrv) {
          await setDoc(doc(firestoreDb, "drivers", stateDrv.id), stateDrv);
        }
      } catch (err) {
        console.warn("Failed to sync driver action to Firestore:", err);
      }
    }

    return res.json({ message: `Driver ${drv.driverName} set to status ${drv.status}`, record: drv });
  }

  res.status(400).json({ error: "Invalid Action Target." });
});


// -----------------------------------------------------------------------------
// VITE AND ASSETS MIDDLEWARE ROUTING
// -----------------------------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // SPA fallback
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`📡 Full-Stack Coal-Belt Logistics Server starts on http://localhost:${PORT}`);
  });
}

startServer();

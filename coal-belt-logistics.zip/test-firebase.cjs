const { initializeApp } = require("firebase/app");
const { getFirestore, doc, setDoc, getDoc } = require("firebase/firestore");
const fs = require("fs");
const path = require("path");

async function withTimeout(promise, ms, name) {
  let timeoutId;
  const timeoutPromise = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      reject(new Error(`Timeout of ${ms}ms exceeded for ${name}`));
    }, ms);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timeoutId));
}

async function run() {
  const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
  const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf-8"));
  const app = initializeApp(firebaseConfig);

  console.log("=== DIAGNOSTIC TEST (WITH TIMEOUT) ===");
  console.log("Project ID:", firebaseConfig.projectId);
  console.log("Custom Database ID:", firebaseConfig.firestoreDatabaseId);

  const databases = [
    { name: "Custom Database", id: firebaseConfig.firestoreDatabaseId },
    { name: "Default Database", id: "(default)" },
    { name: "Undefined Database", id: undefined }
  ];

  for (const dbInfo of databases) {
    console.log(`\nTesting connection to: ${dbInfo.name} [id: ${dbInfo.id}]`);
    try {
      const db = getFirestore(app, dbInfo.id);
      const testDocRef = doc(db, "test", "connection");
      
      console.log("  Writing test document...");
      await withTimeout(setDoc(testDocRef, { timestamp: new Date().toISOString() }), 4000, "Write");
      console.log("  ✓ Write success!");

      console.log("  Reading test document...");
      const snapshot = await withTimeout(getDoc(testDocRef), 4000, "Read");
      console.log("  ✓ Read success! Data:", snapshot.data());
    } catch (err) {
      console.error(`  ✗ Failed: ${err.message}`);
    }
  }
}

run();
